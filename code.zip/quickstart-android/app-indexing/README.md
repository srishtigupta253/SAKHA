Firebase App Indexing Quickstart
==============================

Firebase App Indexing is no longer the recommended way of indexing content for display as suggested results in Google Search App.

Please check the [App Indexing Documentation](https://firebase.google.com/docs/app-indexing) for more details.

