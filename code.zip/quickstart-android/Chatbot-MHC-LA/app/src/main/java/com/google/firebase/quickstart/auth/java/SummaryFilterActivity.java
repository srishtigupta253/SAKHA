package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;

public class SummaryFilterActivity extends AppCompatActivity {
    private static final String TAG = "SummaryFilterActivity";

    // private
    private Button apply;

    private CheckBox depression_normal;
    private CheckBox depression_mild;
    private CheckBox depression_moderate;
    private CheckBox depression_severe;
    private CheckBox depression_severe_2;

    private CheckBox anxiety_normal;
    private CheckBox anxiety_mild;
    private CheckBox anxiety_moderate;
    private CheckBox anxiety_severe;
    private CheckBox anxiety_severe_2;

    private CheckBox stress_normal;
    private CheckBox stress_mild;
    private CheckBox stress_moderate;
    private CheckBox stress_severe;
    private CheckBox stress_severe_2;

    private CheckBox cyber_stalking;
    private CheckBox information_theft;
    private CheckBox money_theft;
    private CheckBox non_consensual_pornography;
    private CheckBox online_abuse;
    private CheckBox financial_scam;
    private CheckBox job_scam;
    private CheckBox matrimonial_or_dating_scam;
    private CheckBox offer_and_coupon_scam;
    private CheckBox ordering_product;
    private CheckBox photo_morphing;
    private CheckBox revenge_porn;
    private CheckBox sexting_scam;
    private CheckBox travel_scam;
    private CheckBox cyber_bullying;
    private CheckBox trolling;
    private CheckBox flaming;

    private CheckBox below_10;
    private CheckBox range_10_20;
    private CheckBox range_20_30;
    private CheckBox range_30_40;
    private CheckBox range_40_50;
    private CheckBox range_50_60;
    private CheckBox above_60;

    public static ArrayList<String> depression_filter = new ArrayList<>();
    public static ArrayList<String> anxiety_filter = new ArrayList<>();
    public static ArrayList<String> stress_filter = new ArrayList<>();
    public static ArrayList<String> cybercrime_filter = new ArrayList<>();
    public static ArrayList<String> age_filter = new ArrayList<>();

    public static ArrayList<String> usersList = new ArrayList<>();

    FirebaseAuth firebaseAuth;
    FirebaseDatabase mFirebaseDatabase;
    public static DatabaseReference mUserDatabaseReference;
    public static DatabaseReference mUsersListDatabaseReference;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_filter);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mUserDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
        mUsersListDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Role");

        apply = (Button) findViewById(R.id.applyButton);

        depression_normal = (CheckBox) findViewById(R.id.depression_normal);
        depression_mild = (CheckBox) findViewById(R.id.depression_mild);
        depression_moderate = (CheckBox) findViewById(R.id.depression_moderate);
        depression_severe = (CheckBox) findViewById(R.id.depression_severe);
        depression_severe_2 = (CheckBox) findViewById(R.id.depression_severe_2);

        anxiety_normal = (CheckBox) findViewById(R.id.anxiety_normal);
        anxiety_mild = (CheckBox) findViewById(R.id.anxiety_mild);
        anxiety_moderate = (CheckBox) findViewById(R.id.anxiety_moderate);
        anxiety_severe = (CheckBox) findViewById(R.id.anxiety_severe);
        anxiety_severe_2 = (CheckBox) findViewById(R.id.anxiety_severe_2);

        stress_normal = (CheckBox) findViewById(R.id.stress_normal);
        stress_mild = (CheckBox) findViewById(R.id.stress_mild);
        stress_moderate = (CheckBox) findViewById(R.id.stress_moderate);
        stress_severe = (CheckBox) findViewById(R.id.stress_severe);
        stress_severe_2 = (CheckBox) findViewById(R.id.stress_severe_2);

        cyber_stalking = (CheckBox) findViewById(R.id.cyber_stalking);
        information_theft = (CheckBox) findViewById(R.id.information_theft);
        money_theft = (CheckBox) findViewById(R.id.money_theft);
        non_consensual_pornography = (CheckBox) findViewById(R.id.non_consensual_pornography);
        online_abuse = (CheckBox) findViewById(R.id.online_abuse);
        financial_scam = (CheckBox) findViewById(R.id.financial_scam);
        job_scam = (CheckBox) findViewById(R.id.job_scam);
        matrimonial_or_dating_scam = (CheckBox) findViewById(R.id.matrimonial_or_dating_scam);
        offer_and_coupon_scam = (CheckBox) findViewById(R.id.offer_and_coupon_scam);
        ordering_product = (CheckBox) findViewById(R.id.ordering_product);
        photo_morphing = (CheckBox) findViewById(R.id.photo_morphing);
        revenge_porn = (CheckBox) findViewById(R.id.revenge_porn);
        sexting_scam = (CheckBox) findViewById(R.id.sexting_scam);
        travel_scam = (CheckBox) findViewById(R.id.travel_scam);
        cyber_bullying = (CheckBox) findViewById(R.id.cyber_bullying);
        trolling = (CheckBox) findViewById(R.id.trolling);
        flaming = (CheckBox) findViewById(R.id.flaming);

        below_10 = (CheckBox) findViewById(R.id.below_10);
        range_10_20 = (CheckBox) findViewById(R.id.range_10_20);
        range_20_30 = (CheckBox) findViewById(R.id.range_20_30);
        range_30_40 = (CheckBox) findViewById(R.id.range_30_40);
        range_40_50 = (CheckBox) findViewById(R.id.range_40_50);
        range_50_60 = (CheckBox) findViewById(R.id.range_50_60);
        above_60 = (CheckBox) findViewById(R.id.above_60);

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // store selected checkbox from ui for dass filter and cybercrime filter
                if(!depression_normal.isChecked() && !depression_mild.isChecked() && !depression_moderate.isChecked() && !depression_severe.isChecked() && !depression_severe_2.isChecked()) {
                    depression_filter.add("normal");
                    depression_filter.add("mild");
                    depression_filter.add("moderate");
                    depression_filter.add("severe");
                    depression_filter.add("extremely severe");
                }

                if(depression_normal.isChecked()) {
                    depression_filter.add("normal");
                }
                if(depression_mild.isChecked()) {
                    depression_filter.add("mild");
                }
                if(depression_moderate.isChecked()) {
                    depression_filter.add("moderate");
                }
                if(depression_severe.isChecked()) {
                    depression_filter.add("severe");
                }
                if(depression_severe_2.isChecked()) {
                    depression_filter.add("extremely severe");
                }

                // anxiety checkboxes
                if(!anxiety_normal.isChecked() && !anxiety_mild.isChecked() && !anxiety_moderate.isChecked() && !anxiety_severe.isChecked() && !anxiety_severe_2.isChecked()) {
                    anxiety_filter.add("normal");
                    anxiety_filter.add("mild");
                    anxiety_filter.add("moderate");
                    anxiety_filter.add("severe");
                    anxiety_filter.add("extremely severe");
                }

                if(anxiety_normal.isChecked()) {
                    anxiety_filter.add("normal");
                }
                if(anxiety_mild.isChecked()) {
                    anxiety_filter.add("mild");
                }
                if(anxiety_moderate.isChecked()) {
                    anxiety_filter.add("moderate");
                }
                if(anxiety_severe.isChecked()) {
                    anxiety_filter.add("severe");
                }
                if(anxiety_severe_2.isChecked()) {
                    anxiety_filter.add("extremely severe");
                }

                // stress checkboxes
                if(!stress_normal.isChecked() && !stress_mild.isChecked() && !stress_moderate.isChecked() && !stress_severe.isChecked() && !stress_severe_2.isChecked()) {
                    stress_filter.add("normal");
                    stress_filter.add("mild");
                    stress_filter.add("moderate");
                    stress_filter.add("severe");
                    stress_filter.add("extremely severe");
                }

                if(stress_normal.isChecked()) {
                    stress_filter.add("normal");
                }
                if(stress_mild.isChecked()) {
                    stress_filter.add("mild");
                }
                if(stress_moderate.isChecked()) {
                    stress_filter.add("moderate");
                }
                if(stress_severe.isChecked()) {
                    stress_filter.add("severe");
                }
                if(stress_severe_2.isChecked()) {
                    stress_filter.add("extremely severe");
                }

                // cybercrime checkboxes
                if(cyber_stalking.isChecked()) {
                    cybercrime_filter.add("cyber_stalking");
                }
                if(information_theft.isChecked()) {
                    cybercrime_filter.add("information_theft");
                }
                if(money_theft.isChecked()) {
                    cybercrime_filter.add("money_theft");
                }
                if(non_consensual_pornography.isChecked()) {
                    cybercrime_filter.add("non_consensual_pornography");
                }
                if(online_abuse.isChecked()) {
                    cybercrime_filter.add("online_abuse");
                }
                if(financial_scam.isChecked()) {
                    cybercrime_filter.add("financial_scam");
                }
                if(job_scam.isChecked()) {
                    cybercrime_filter.add("job_scam");
                }
                if(matrimonial_or_dating_scam.isChecked()) {
                    cybercrime_filter.add("matrimonial_or_dating_scam");
                }
                if(offer_and_coupon_scam.isChecked()) {
                    cybercrime_filter.add("offer_and_coupon_scam");
                }
                if(ordering_product.isChecked()) {
                    cybercrime_filter.add("ordering_product");
                }
                if(photo_morphing.isChecked()) {
                    cybercrime_filter.add("photo_morphing");
                }
                if(revenge_porn.isChecked()) {
                    cybercrime_filter.add("revenge_porn");
                }
                if(sexting_scam.isChecked()) {
                    cybercrime_filter.add("sexting_scam");
                }
                if(travel_scam.isChecked()) {
                    cybercrime_filter.add("travel_scam");
                }
                if(cyber_bullying.isChecked()) {
                    cybercrime_filter.add("cyber_bullying");
                }
                if(trolling.isChecked()) {
                    cybercrime_filter.add("trolling");
                }
                if(flaming.isChecked()) {
                    cybercrime_filter.add("flaming");
                }

                // age checkboxes
                if(!below_10.isChecked() && !range_10_20.isChecked() && !range_20_30.isChecked() && !range_30_40.isChecked() && !range_40_50.isChecked() && !range_50_60.isChecked() && !above_60.isChecked()) {
                    age_filter.add("below 10");
                    age_filter.add("10-20");
                    age_filter.add("20-30");
                    age_filter.add("30-40");
                    age_filter.add("40-50");
                    age_filter.add("50-60");
                    age_filter.add("above 60");
                }

                if(below_10.isChecked()) {
                    age_filter.add("below 10");
                }
                if(range_10_20.isChecked()) {
                    age_filter.add("10-20");
                }
                if(range_20_30.isChecked()) {
                    age_filter.add("20-30");
                }
                if(range_30_40.isChecked()) {
                    age_filter.add("30-40");
                }
                if(range_40_50.isChecked()) {
                    age_filter.add("40-50");
                }
                if(range_50_60.isChecked()) {
                    age_filter.add("50-60");
                }
                if(above_60.isChecked()) {
                    age_filter.add("above 60");
                }

                Intent i = new Intent(getApplicationContext(),ViewSummariesActivity.class);
                startActivity(i);
            }
        });

        getUsersList();
    }

    void getUsersList() {

        usersList.clear();

        mUserDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot uidSnapshot: dataSnapshot.getChildren()) {
                        String uid = uidSnapshot.getKey();
                        usersList.add(uid);
                    }
                } else {
                    Log.d("getUsersList:","users list doesn't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
