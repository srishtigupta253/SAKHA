package com.google.firebase.quickstart.auth.java.requests;

import android.widget.EditText;

import java.io.Serializable;

public class RequestModel implements Serializable {
    private String uid;
    private String name;
    private String empId;
    private String phoneNo;
    private Long timestamp;

    public RequestModel() {
        this.uid = "NULL";
        this.name = "NULL";
        this.empId = "NULL";
        this.phoneNo = "NULL";
        this.timestamp = 0L;
    }

    public RequestModel(String uid, String name, String empId, String phoneNo, Long timestamp) {
        this.uid = uid;
        this.name = name;
        this.empId = empId;
        this.phoneNo = phoneNo;
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
