package com.google.firebase.quickstart.auth.java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;


import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;

//import static com.google.firebase.quickstart.auth.java.LegalAid.mMessageAdapter2;
import static com.google.firebase.quickstart.auth.java.LegalAid.intentAPI;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.MY_SOCKET_TIMEOUT_MS;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;

import org.json.JSONObject;

public class LegalAid2 extends AppCompatActivity {

    private static final String TAG = "IntroActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;
    public static String evidences = "<b>Here are some evidences you can gather</b>:";

    //  public static String Summary="";

    static Vector<Integer> intentCheck=new Vector<Integer>();

    private ListView mMessageListView;
    //public  static MessageAdapter mMessageAdapter2;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    //private EditText mMessageEditText;
    // private Button mSendButton;
    // public static String mUsername=ANONYMOUS;

    public int introVar=0;
    // public static UserIntro introMap=new UserIntro();
    public int endActivity=0;


    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<String>(Arrays.asList("Yes","No"));
    static IntentItem[] intent_cyber_crime = {
            new IntentItem("private part", false, 0),
            new IntentItem("genitals", false, 0),
            new IntentItem("photo", false, 0),
            new IntentItem("video", false, 0),
            new IntentItem("consent", false, 0),
            new IntentItem("share", false, 0),
            new IntentItem("pornography", false, 1),
            new IntentItem("obscene", false, 1),
            new IntentItem("child", false, 2),
            new IntentItem("offensive", false, 3),
            new IntentItem("threaten", false, 4),
            new IntentItem("defame", false, 5),
            new IntentItem("blackmailing", false, 6),
            new IntentItem("extortion", false, 7),
            new IntentItem("illegal", false, 8),
            new IntentItem("sex", false, 8),
            new IntentItem("stalking", false, 9),
            new IntentItem("insulting", false, 12),
            new IntentItem("modesty", false, 12),
            new IntentItem("dating", false, 10),
            new IntentItem("matrimonial", false, 11),
            new IntentItem("cheat", false, 16),
            new IntentItem("message", false, 3),
            new IntentItem("troll", false, 19),
            new IntentItem("harass", false, 19),
            new IntentItem("money", false, 20),
            new IntentItem("job", false, 13),
            new IntentItem("fraud", false, 13),
            new IntentItem("holiday", false, 15),
            new IntentItem("travel", false, 15),
            new IntentItem("offer", false, 14),
            new IntentItem("coupon", false, 14),
            new IntentItem("Financial", false, 16),
            new IntentItem("profile", false, 17),
            new IntentItem("fake", false, 17),
            new IntentItem("pretend", false, 17),
            new IntentItem("attack", false, 18),
            new IntentItem("anonymous", false, 21),
            new IntentItem("card", false, 16)
    };

    static SectionsItem[] sections_cyber_crime = {
            new SectionsItem("IPC Section 504 2 years jail or fine or both", false),
            new SectionsItem("IPC Section 292 fine 2000-5000 jail 2-5 years", false),
            new SectionsItem("IPC Section 384 upto 3 years jail or fine or both", false),
            new SectionsItem("IPC Section 354A upto 3 years jail or fine or both", false),
            new SectionsItem("IPC Section 354D: First time-3 years jail or fine or both, Second time onwards-upto 5 years jail or fine or both", false),
            new SectionsItem("IPC Section 417 1 year jail or fine or both ", false),
            new SectionsItem("IPC Section 509 1 year jail or fine or both", false),
            new SectionsItem("IPC Section 508 2 years jail or fine or both", false),
            new SectionsItem("Section 66E of IT Act 2000: fine 2 lakhs, 3 years jail or both", false),
            new SectionsItem("Section 67 of IT Act 2000 – first conviction up to 3 years and 5 lakhs Second and subsequent conviction – upto 5 years and upto 10 lakhs", false),
            new SectionsItem("Section 66D of IT Act 2000: upto 3 years jail and fine upto 1 lakh", false),
            new SectionsItem("IPC Section 507 2 years jail with Section 506", false),
            new SectionsItem("Section 79(3)(A) of IT Act 2000", false),
            new SectionsItem("IPC Section 506 2 years jail or fine or both", false),
            new SectionsItem("IPC Section 503 2-4 years jail or fine or both", false),
            new SectionsItem("IPC Section 500 2 years jail or fine or both", false),
            new SectionsItem("IPC Section 419 3 years jail or fine or both", false),
            new SectionsItem("IPC Section 416", false),
            new SectionsItem("section 67 B of IT act 2000 - first conviction upto 5 years and upto 10 lakhs fine  second conviction upto 7 year and upto 10 lakhs", false),
            new SectionsItem("IPC Section 354C: First time-1 to 3 years jail and fine, Second time onwards 3 to 7 years jail and fine", false),
            new SectionsItem("IPC Section 421: Imprisonment for 2 years, or fine, or both", false),
            new SectionsItem("IPC section 14, 15 POCSO", false),
            new SectionsItem("IPC section 499", false),
            new SectionsItem("Section 66C of IT Act 2000 imprisonment for 3 years and fine upto to rupees 1 lakh", false),
            new SectionsItem("IPC section 378  imprisonment for a period of time up to 10 years along with a fine.", false),
            new SectionsItem("IPC section 43", false)
    };

    static QuestionsItem[] questions_cyber_crime = {
            new QuestionsItem("Did anyone click or share your private pictures/videos without your consent?",false,false,new ArrayList<>(Arrays.asList(1,8,9,19))),
            new QuestionsItem("Did anyone send any obscene pictures or videos to disturb you?",false,false,new ArrayList<>(Arrays.asList(8,9))),
            new QuestionsItem("Did obscene content have any child involved?",false,false,new ArrayList<>(Arrays.asList(1,9,18,21))),
            new QuestionsItem("Did anyone send offensive messages to you?",false,false,new ArrayList<>(Arrays.asList(0,6,7,11,13,15))),
            new QuestionsItem("Did anyone send threatening messages to you?",false,false,new ArrayList<>(Arrays.asList(0))),
            new QuestionsItem("Did anyone try to defame you on social media or any other platform?",false,false,new ArrayList<>(Arrays.asList(15))),
            new QuestionsItem("Did someone blackmail you on social media or any other platform?",false,false,new ArrayList<>(Arrays.asList(14))),
            new QuestionsItem("Did they demand money or any property while blackmailing?",false,false,new ArrayList<>(Arrays.asList(14))),
            new QuestionsItem("Have anyone ever approached you and demand for illegal sex?",false,false,new ArrayList<>(Arrays.asList(3))),
            new QuestionsItem("Have you ever undergone the unpleasant experience of being stalked?",false,false,new ArrayList<>(Arrays.asList(4))),
            new QuestionsItem("In the world of social media online dating as well as scam related to it is on a rise. Have you ever been victim of online dating?",false,false,new ArrayList<>(Arrays.asList(6,10,12,16,17))),
            new QuestionsItem("Did someone dupe you for money on matrimonial websites?",false,false,new ArrayList<>(Arrays.asList(12))),
            new QuestionsItem("Did someone try to insult your modesty with some kind of act, word or gesture?",false,false,new ArrayList<>(Arrays.asList(6))),
            new QuestionsItem("Did someone took money from you in a job scam?",false,false,new ArrayList<>(Arrays.asList(10,23,24))),
            new QuestionsItem("Did someone dupe you for money in a coupon or offer scam?",false,false,new ArrayList<>(Arrays.asList(10,23,24))),
            new QuestionsItem("Did anyone offer you a holiday package and deceive you?",false,false,new ArrayList<>(Arrays.asList(10,23,24))),
            new QuestionsItem("Did anyone steal your debit/credit card or dupe you for money?",false,false,new ArrayList<>(Arrays.asList(10))),
            new QuestionsItem("Did anyone used your identity in social media?",false,false,new ArrayList<>(Arrays.asList(10))),
            new QuestionsItem("Did someone directly callout you and attack you online?",false,false,new ArrayList<>(Arrays.asList(0,6,8))),
            new QuestionsItem("Did someone troll you or diss you online?",false,false,new ArrayList<>(Arrays.asList(0,8,15,22))),
            new QuestionsItem("Did you lose any money in a scam?",false,false,new ArrayList<>(Arrays.asList(24))),
            new QuestionsItem("Did the person do that annonymously?",false,false,new ArrayList<>(Arrays.asList(22)))
    };

    static EvidencesItem[] evidences_cyber_crime = {
            /*0*/new EvidencesItem("Statement of Bank Account",false),
            /*1*/new EvidencesItem("Email of Job offer, Interview Call recordings.", false),
            /*2*/new EvidencesItem("Messages, Transaction Details, call recordings, Photographs that were sent.",false),
            /*3*/new EvidencesItem("Site URL, Malicious Apps, Text Message, Email, Product details.",false),
            /*4*/new EvidencesItem("Text Message, Call Recordings.",false),
            /*5*/new EvidencesItem("Credit/Debit card Details.",false),
            /*6*/new EvidencesItem("Recordings of unusual calls, URL of new website, response to unusual email, new software, Malicious e-commerce site, Credit Card Details.",false),
            /*7*/new EvidencesItem("Messages from any messaging app or public forum",false),
            /*8*/new EvidencesItem("Messages from SMS/WhatsApp/other instant messaging Application, URL of Portal.",false),
            /*9*/new EvidencesItem("Emails, Tweets, Messages/Comments in public forums, YouTube/Facebook video links.",false),
            /*10*/new EvidencesItem("Transaction receipts, Order Details.",false),
            /*11*/new EvidencesItem("Emails, chats from Internet discussion groups.", false)
    };

    static int[][] evidence_index_intent = {
            {7,8,10},
            {10},
            {8, 11},
            {8},
            {},
            {6, 7, 8, 9, 11},
            {},
            {7},
            {},
            {7},
            {6},    // threaten
            {6, 9}, // defame
            {11, 8, 6}, //blackmailing
            {0, 6}, // extortion
            {0, 2, 6}, //illegal
            {11, 7}, //sex
            {8, }, //stalking
            {6, 7, 9}, //insulting
            {7, 6}, //modesty
            {4}, //dating
            {4}, //matrimonial
            {0}, //cheat
            {11, 9, 7, 6}, //message
            {9}, //troll
            {7}, //harass
            {0}, //money
            {1},//job
            {0}, //fraud
            {2}, //holiday
            {2}, //travel
            {1,2,3}, //offer
            {2,3}, //coupon
            {5,0},//Financial
            {0,6,7}, //profile
            {0,6,7}, //fake
            {0,6,7}, //pretend
            {7}, //attack
            {0,6,7}, //anonymous
            {0} //card
    };

    static int[][] order_cyber_crime = {
            {2,4,7},
            {2,4,7},
            {0,4,6},
            {0,4,6},
            {0,3,7},
            {0,2,4,7},
            {8,0},
            {8,0},
            {6},
            {10,11},
            {9,11,16},
            {9,10},
            {13,14,15},
            {14,15},
            {15},
            {14},
            {12,10},
            {18,7,11},
            {},
            {20},
            {},
            {19,20,32,27,28,30,31},
            {9,10,11},
            {9,10,11,16,24,37},
            {23,9,10,16,11,37},
            {},
            {27},
            {26},
            {29},
            {28},
            {31},
            {30},
            {38},
            {34,33},
            {34},
            {32,33},
            {37},
            {36},
            {32}
    };

    int prevQues = -1;
    String reply = "null";

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legal_aid);


        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages-1).setOpt1("null");
                mMessageAdapter.getItem(messages-1).setOpt2("null");
                mMessageAdapter.getItem(messages-1).setOpt3("null");
                mMessageAdapter.getItem(messages-1).setOpt4("null");
                mMessageAdapter.getItem(messages-1).setOpt5("null");
                mMessageAdapter.getItem(messages-1).setOpt6("null");
                mMessageAdapter.getItem(messages-1).setOpt7("null");
                mMessageAdapter.getItem(messages-1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp=mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage=new FriendlyMessage(temp,mUsername,null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");

                introVar+=1;
                //introFun(temp);

                if(introVar > intentCheck.size()) {
                    //introStart1();
                    temp = temp.toLowerCase();
                    if (temp.equalsIgnoreCase("no")) {
                        finalDisplay();
                    } else {
                        Log.d("anythingElse:","came here");
                        introVar = 0;
                        // reply = "This is Meena Pant. From few months a man is threatening me with obscene messages 4 and harassing me. A few week ago he also circulated my personal number to some random guys a nd they are annoying me with cheap talks. I want some harsh actions towards this. I also hav e his messages and contact no";
                        // (new Handler()).postDelayed(this::funLegal, 3000);
                        funLegal();
                        extractKeywords();
                        furtherIntentDetection();
                        // introVar--;
                        introStart();
                    }
                } else {
                    temp = temp.toLowerCase();
                    int x = introVar-1;
                    int y = intentCheck.get(x);
                    int signal = temp.equals("yes") ? 1 : 0;
                    if(signal == 1) {
                        // int x = introVar-1;
                        // int y = intentCheck.get(x);
                        intent_cyber_crime[y].isTrue = true;
                        questions_cyber_crime[prevQues].isYes = true;

                        update_cyber_crime();
                        related_intent_cyber(y,signal);
                        furtherIntentDetection();
                    }

                    Log.d("prevQues="+questions_cyber_crime[prevQues].question," Ans="+temp+" _ans="+questions_cyber_crime[prevQues].isYes);
                    introStart();
                }
            }

            public void funLegal() {
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
//                String url = "http://imash.pythonanywhere.com/legal";
                String url = "http://sdandapat.pythonanywhere.com/legal";

                StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(),response,Toast.LENGTH_SHORT).show();
                        Log.d("response2:",response);
                        intentAPI=response;
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
                        String temp="apierror";
                        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Content-Type", "text/html");
                        return params;
                    }

                    @Override
                    public byte[] getBody() throws AuthFailureError {
                        HashMap<String, String> params2 = new HashMap<String, String>();
                        params2.put("text",reply);
                        return new JSONObject(params2).toString().getBytes();
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };
                sr.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                queue.add(sr);



            }
        });

        initialize_cyber();
        extractKeywords();
        // furtherIntentDetection();
        introStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public void introStart() {
        Log.d("introStart:","introVar = "+introVar);
        update_cyber_crime();

        String temp="empty";
        FriendlyMessage friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
        friendlyMessage.setOpt1("Yes");
        friendlyMessage.setOpt2("No");

        if(introVar == intentCheck.size()) {
            // temp="You can share anything else you want to, or click \"No\" below";
            // friendlyMessage.setOpt1("No");
            // friendlyMessage.setOpt2("null");
            // friendlyMessage.setText(temp);
            // mMessageAdapter.add(friendlyMessage);
            // mMessageAdapter.notifyDataSetChanged();
            newChatbotMessage("You can share anything else you want to, or click \"No\" below",new ArrayList<>(Arrays.asList("No")));
            // newDebugMessage("Please click <b>No</b> for now. This thing is a work in progress. Will finish asap.");
        } else {
            int x = intentCheck.get(introVar);
            if (intent_cyber_crime[x].id == -1) {
                introVar=introVar+1;
                introStart();
            } else {
                int y = intent_cyber_crime[x].id;
                if(questions_cyber_crime[y].isAsked) {
                    introVar=introVar+1;
                    introStart();
                } else {
                    questions_cyber_crime[y].isAsked=true;
                    prevQues = y;
                    temp=questions_cyber_crime[y].question;
                    friendlyMessage.setText(temp);
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                }
            }
        }
    }

    void update_cyber_crime() {
        intent_cyber_crime[0].isTrue = intent_cyber_crime[0].isTrue || intent_cyber_crime[1].isTrue;
        intent_cyber_crime[1].isTrue = intent_cyber_crime[0].isTrue;
        intent_cyber_crime[2].isTrue = intent_cyber_crime[2].isTrue || intent_cyber_crime[3].isTrue;
        intent_cyber_crime[3].isTrue = intent_cyber_crime[2].isTrue;
        intent_cyber_crime[6].isTrue = intent_cyber_crime[6].isTrue || intent_cyber_crime[7].isTrue;
        intent_cyber_crime[7].isTrue = intent_cyber_crime[6].isTrue;

        int id = intent_cyber_crime[7].id;
        if (!intent_cyber_crime[7].isTrue && questions_cyber_crime[id].isAsked) {
            questions_cyber_crime[id+1].isAsked=true;
        }

        id = intent_cyber_crime[12].id;
        if (!intent_cyber_crime[12].isTrue && questions_cyber_crime[id].isAsked) {
            questions_cyber_crime[id+1].isAsked=true;
        }

        id = intent_cyber_crime[19].id;
        if (!intent_cyber_crime[19].isTrue && questions_cyber_crime[id].isAsked) {
            questions_cyber_crime[id+1].isAsked=true;
        }

        id = intent_cyber_crime[36].id;
        if (intent_cyber_crime[36].isTrue && questions_cyber_crime[id].isAsked) {
            intent_cyber_crime[37].isTrue=true;
        }
        id = intent_cyber_crime[37].id;
        if (intent_cyber_crime[37].isTrue && questions_cyber_crime[id].isAsked) {
            intent_cyber_crime[36].isTrue=true;
        }

        id = intent_cyber_crime[26].id;
        if (intent_cyber_crime[26].isTrue && questions_cyber_crime[id].isAsked) {
            // intent_cyber_crime[27].isTrue==true;
        }
        id = intent_cyber_crime[27].id;
        if (intent_cyber_crime[27].isTrue && questions_cyber_crime[id].isAsked) {
            // intent_cyber_crime[26].isTrue==true;
        }

        id = intent_cyber_crime[23].id;
        if (intent_cyber_crime[23].isTrue && questions_cyber_crime[id].isAsked) {
            // intent_cyber_crime[24].isTrue==true;
        }

        id = intent_cyber_crime[33].id;
        if (intent_cyber_crime[34].isTrue && questions_cyber_crime[id].isAsked) {
            // intent_cyber_crime[34].isTrue==true;
        }
    }

    void related_intent_cyber(int id, int signal) {
        Integer[] related = {0, 1, 2, 3, 4};
        if (Arrays.asList(related).contains(id) && signal == 1) {
            for (int _id : related) {
                intent_cyber_crime[_id].isTrue = true;
            }
        }

        related = new Integer[]{14, 15};
        if (Arrays.asList(related).contains(id) && signal == 1) {
            for (int _id : related) {
                intent_cyber_crime[_id].isTrue = true;
            }
        }
    }

    // find cyber crime intent index
    int find_cyber_intent_index(String intent) {
        int l = intent_cyber_crime.length;
        for (int i = 0; i < l; i++)
            if (intent.equals(intent_cyber_crime[i].intent))
                return i;
        return -1;
    }

    // push all the sections associated with each Ticked questions
    ArrayList<String> section_cyber() {
        Set<Integer> ans_cyber_set = new HashSet<>();
        // int n = questions_cyber_crime.length;
        for (QuestionsItem questionsItem : questions_cyber_crime) {
            if (questionsItem.isYes) {
                ans_cyber_set.addAll(questionsItem.sections);
            }
        }
        ArrayList<String> ans_cyber = new ArrayList<>();
        for (int i : ans_cyber_set) {
            ans_cyber.add(sections_cyber_crime[i].section);
        }
        return ans_cyber;
    }

    void initialize_cyber() {
        for (int i = 0; i < intent_cyber_crime.length; i++) intent_cyber_crime[i].isTrue = false;
        for (int i = 0; i < sections_cyber_crime.length; i++) sections_cyber_crime[i].isTrue = false;
        for (int i = 0; i < questions_cyber_crime.length; i++) questions_cyber_crime[i].isAsked = false;
    }

    ArrayList<String> get_sections() {
        return section_cyber();
    }

    public void furtherIntentDetection() {
        String temp = "null";

        for (int i = 0; i < intent_cyber_crime.length; i++) {
            if (intent_cyber_crime[i].isTrue) {
                for(int j = 0; j < order_cyber_crime[i].length; j++) {
                    int x = order_cyber_crime[i][j];
                    if (x != -1) {
                        if (!intent_cyber_crime[x].isTrue) {
                            intentCheck.add(x);
                            Log.d("pushToIntentCheck:", "question "+intent_cyber_crime[x].id+" = "+questions_cyber_crime[intent_cyber_crime[x].id].question);
                        }
                    }
                }
            }
        }

        LinkedHashSet<Integer> lhSet = new LinkedHashSet<>(intentCheck);

        intentCheck.clear();
        intentCheck.addAll(lhSet);

        for(int i = 0; i < intent_cyber_crime.length; i++) {
            IntentItem item = intent_cyber_crime[i];
            Log.d("intent_cyber_crime:","("+i+"). intent="+item.intent+","+item.isTrue+", id="+item.id);
        }

        String x = "";
        for (int id : intentCheck) x += (id+",");
        Log.d("intentCheck:", x);
        Log.d("intentCheck.size:", String.valueOf(intentCheck.size()));

        //  FriendlyMessage friendlyMessage = new FriendlyMessage(intentCheck.toString(),"SAKHA",null);
        //
        //  mMessageAdapter.add(friendlyMessage);
        //  mMessageAdapter.notifyDataSetChanged();
    }

    public void extractKeywords() {
        String s = intentAPI;
        Log.d("intentAPI_LegalAid2: ",intentAPI);
        int f = 0;
        String intent = "";
        char ch;

        Vector<Integer> order = new Vector<>();

        for (int i = 0; i < s.length(); i++) {
            ch = s.charAt(i);
            if (ch == '"') {
                if (f == 1) {
                    int x = find_cyber_intent_index(intent);
                    if (x != -1) {
                        order.add(x);
                    }
                }
                f = (f + 1) % 2;
            } else {
                if (f == 1)
                    intent = intent + ch;
                else
                    intent = "";
            }
        }

        Collections.sort(order);
        for(Integer x : order) {
            intent_cyber_crime[x].isTrue = true;
            intentCheck.add(x);
            furtherIntentDetection();
            // LinkedHashSet<Integer> lhSet = new LinkedHashSet<>(intentCheck);
            //
            // intentCheck.clear();
            // intentCheck.addAll(lhSet);
            Log.d("extractKeywords:","intent="+intent+" intent_index="+x);
        }

        StringBuilder logMsg = new StringBuilder();
        for (IntentItem intentItem : intent_cyber_crime) {
            if (intentItem.isTrue) {
                logMsg.append(intentItem.intent).append(",");
            }
        }
        Log.d("intent_cyber_crimes:", logMsg.toString());
    }


    public void finalDisplay() {
        // // finalSuggestion();

        // String temp = "<b>You may file a case under the following sections:</b>";
        // FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        // mMessageAdapter.add(friendlyMessage);
        // mMessageAdapter.notifyDataSetChanged();

        ArrayList<String> sectionsList = get_sections();
        String sections = "<b>You may file a case under the following sections</b>:";
        int index1 = 1;
        for (String s : sectionsList) {
            // FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
            // friendlyMessage1.setText(s);
            // mMessageAdapter.add(friendlyMessage1);
            sections += ("<br><b>"+index1+")</b> "+s);
            index1++;
        }
        FriendlyMessage friendlyMessage = new FriendlyMessage(sections, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();

        String true_intents="";
        Set<Integer> hashSet = new HashSet<>();
        for(int i=0; i<intent_cyber_crime.length; i++) {
            if(intent_cyber_crime[i].isTrue) {
                true_intents += intent_cyber_crime[i].intent+", ";
                for(int index: evidence_index_intent[i]) {
                    hashSet.add(index);
                }
            }
        }
        Log.d("legalaid2:true-intents:",true_intents);

        // String temp = "<b>Here are some evidences you can gather:</b>";
        // FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);
        // mMessageAdapter.add(friendlyMessage2);
        int index2 = 1;
        for(Integer x: hashSet) {
            String evidence = evidences_cyber_crime[x].evidence;
            // FriendlyMessage friendlyMessage1 = new FriendlyMessage(evidence, "SAKHA", null);
            // mMessageAdapter.add(friendlyMessage1);

            evidences += ("<br><b>"+index2+")</b> "+evidence);
            index2++;
        }
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(evidences, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage2);
        mMessageAdapter.notifyDataSetChanged();

        Intent i = new Intent(getApplicationContext(), LegalAidSuggestionsActivity.class);
        startActivity(i);
    }

//    public void introFun(String uinput)
//    {
//        String temp="empty";
//
//        switch (introVar)
//        {
//            case 1:
//                temp="Are you married ?";
//                break;
//            case 2:
//                temp="Do you do some kind of work for living?";
//                break;
//            case 3:
//                temp="What brings you here. How can I help you?";
//                break;
//            case 4:
//                temp="Did your family members evicted you from home anytime?";
//                break;
//            case 5:
//                temp="Do you face any restrictions on taking jobs or working outside home from your family members?";
//                break;
//            case 6:
//                temp="Do you face any other restrictions on using household items from your family members?";
//                break;
//            case 7:
//                temp="Does any of your family members trying to threaten you by any action or gesture?";
//                break;
//            case 8:
//                temp="Did your family members abuse you mentally or emotionally?";
//                break;
//            case 9:
//                temp="Do you want to share anything else?";
//                break;
//            case 10:
//                temp="You may file a case under the following sections:";
//                FriendlyMessage friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
//                temp=" *  Section 3 of Domestic violence Act under economic abuse";
//                FriendlyMessage friendlyMessage1= new FriendlyMessage(temp,"SAKHA",null);
//                mMessageAdapter.add(friendlyMessage1);
//                mMessageAdapter.notifyDataSetChanged();
//                temp="  *  Section 3 of Domestic violence Act under verbal abuse\n";
//                FriendlyMessage friendlyMessage2= new FriendlyMessage(temp,"SAKHA",null);
//                mMessageAdapter.add(friendlyMessage2);
//                mMessageAdapter.notifyDataSetChanged();
//                temp=" *  Section 3 of Domestic violence Act under emotional abuse";
//                FriendlyMessage friendlyMessage3= new FriendlyMessage(temp,"SAKHA",null);
//                mMessageAdapter.add(friendlyMessage3);
//                mMessageAdapter.notifyDataSetChanged();
//                temp=" *  Section 3 of Domestic violence Act under physical abuse\n";
////                FriendlyMessage friendlyMessage4= new FriendlyMessage(temp,"SAKHA",null);
////                mMessageAdapter.add(friendlyMessage4);
////                mMessageAdapter.notifyDataSetChanged();
//                break;
//            default:
//                temp="defaultLegalAid";
//
//
//
//
//        }
//
//        if(endActivity!=1) {
//            FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//            mMessageAdapter.add(friendlyMessage);
//            mMessageAdapter.notifyDataSetChanged();
//        }
//
//
//    }
//
//    public void introStart1()
//    {
//        String temp;
//        temp="You may file a case under the following sections:";
//        FriendlyMessage friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage);
//        mMessageAdapter.notifyDataSetChanged();
//        temp=" *  IPC Section 504 2 years jail or fine or both";
//        FriendlyMessage friendlyMessage1= new FriendlyMessage(temp,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage1);
//        mMessageAdapter.notifyDataSetChanged();
//        temp="  *  IPC Section 417 1 year jail or fine or both\n";
//        FriendlyMessage friendlyMessage2= new FriendlyMessage(temp,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage2);
//        mMessageAdapter.notifyDataSetChanged();
//        temp=" *  IPC Section 354D: First time-3 years jail or fine or both, Second time onwards-upto 5 years jail or fine or both";
//        FriendlyMessage friendlyMessage3= new FriendlyMessage(temp,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage3);
//        mMessageAdapter.notifyDataSetChanged();
//        temp=" *  Section 79(3)(A) of IT Act 2000\n";
//        FriendlyMessage friendlyMessage4= new FriendlyMessage(temp,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage4);
//        mMessageAdapter.notifyDataSetChanged();
//
//    }

    public String retInt(String str)
    {

        String[] splited = str.split("\\s+");
        for (String s : splited) {
            int n = s.length();

            if (onlyDigits(s, n)) {
                return s;
            }
        }

        return "null";
    }

    public static boolean onlyDigits(String str, int n)
    {
        // Traverse the string from start to end
        for (int i = 0; i < n; i++) {

            // Check if character is digit from 0-9 then return true else false
            if (!((str.charAt(i) >= '0' && str.charAt(i) <= '9') || str.charAt(i)=='.') ) {
                return false;
            }
            // else {
            //     return false;
            // }
        }
        return true;
    }

//    void updateToFirebase()
//    {
//        String currentUserId=firebaseAuth.getCurrentUser().getUid();
//        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();
//
////            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
////            //HashMap<String ,String> profileMap = new HashMap<>();
//////                    profileMap.put("device_token",deviceToken);
//////                    profileMap.put("uid",currentUserId);
//////                    profileMap.put("name",Username);
//////                    profileMap.put("phone_number",PhoneNo);
//////                    profileMap.put("address",Address);
////            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);
//        mMessageDatabaseReference.child(currentUserId).child("intro").setValue(introMap)
//                .addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//
//                        if(task.isSuccessful())
//                        {
//
//                            Toast.makeText(getApplicationContext(),"Profile Updated",Toast.LENGTH_SHORT).show();
//                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
//                            //startActivity(i);
//                        }
//                        else
//                        {
//                            String Error = task.getException().toString();
//                            Toast.makeText(getApplicationContext(),"Error "+Error,Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
//    }

    public boolean funYes(String uinput)
    {
        uinput=uinput.toLowerCase();
        String[] splited= uinput.split(" ");
        for (String s : splited) {
            if (s.equals("yes"))
                return true;
        }
        return false;

    }

    void newChatbotMessage(String message, ArrayList<String> options) {
        while (options.size() < 8) {
            options.add("null");
        }

        FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
        chatbotMsg.setOpt1(options.get(0));
        chatbotMsg.setOpt2(options.get(1));
        chatbotMsg.setOpt3(options.get(2));
        chatbotMsg.setOpt4(options.get(3));
        chatbotMsg.setOpt5(options.get(4));
        chatbotMsg.setOpt6(options.get(5));
        chatbotMsg.setOpt7(options.get(6));
        chatbotMsg.setOpt8(options.get(7));

        mMessageAdapter.add(chatbotMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    @Override
    public void finish() {
        evidences = "<b>Here are some evidences you can gather</b>:";
        super.finish();
    }
}

class IntentItem {
    String intent;
    boolean isTrue;
    int id;

    IntentItem() {
        this.intent = "null";
        this.isTrue = false;
        this.id = -1;
    }

    IntentItem(String intent, boolean isTrue, int id) {
        this.intent = intent;
        this.isTrue = isTrue;
        this.id = id;
    }
}

class SectionsItem {
    String section;
    boolean isTrue;

    SectionsItem() {
        this.section = "null";
        this.isTrue = false;
    }

    SectionsItem(String str, boolean isTrue) {
        this.section = str;
        this.isTrue = isTrue;
    }
}

class EvidencesItem {
    String evidence;
    boolean isTrue;

    EvidencesItem() {
        this.evidence = "null";
        this.isTrue = false;
    }

    EvidencesItem(String str, boolean isTrue) {
        this.evidence = str;
        this.isTrue = isTrue;
    }
}

class QuestionsItem {
    String question;
    boolean isAsked;
    boolean isYes;
    ArrayList<Integer> sections;

    QuestionsItem() {
        this.question = "null";
        this.isAsked = false;
        this.isYes = false;
        this.sections = new ArrayList<>();
    }

    QuestionsItem(String question, boolean isAsked, boolean isYes, ArrayList<Integer> sections) {
        this.question = question;
        this.isAsked = isAsked;
        this.isYes = isYes;
        this.sections = sections;
    }
}