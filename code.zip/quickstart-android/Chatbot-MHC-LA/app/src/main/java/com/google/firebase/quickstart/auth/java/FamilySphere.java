package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.childCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.childrenCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.husbandCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.isSentiment;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.subSphere;

public class FamilySphere {
    public int boyCnt=0; // count for boy (child)
    public String marriageStatus; // marriage status

// strings for sentiment check by api for different sub categories
    public String sentChk1;
    public String sentChk2;
    public String sentChk3;
    public String sentChk4;
    public String sentChk5;

    public int sphereDetected; // flag for checking whether the sphere is detected by api through open ended question
    public String totalSentCheck; // final string for sentiment check
    public String finalCause; // answer for final quesstion

    FamilySphere()
    {
        this.boyCnt=0;
        this.marriageStatus="null";

       this.sentChk1="";
       this.sentChk2="";
       this.sentChk3="";
        this.sentChk4="";
        this.sentChk5="";

        this.sphereDetected=0;
        this.totalSentCheck="";
        this.finalCause="null";

    }
// asked question based on the sub classification into 5 categories
    public String funFamily(int i,String uinput)
    {
      String temp="null";
      switch(i)
      {
          case 0:
              temp="I understand that your family life is stressful. Am I right?";
              isSentiment=1;
              break;
          case 1:
              isSentiment=0;
              if(uinput.equals("positive"))
                  temp="doneNotFound";
              else
              {
                  if(husbandCnt==1)
                  {
                      marriageStatus="married";
                      temp="skip";
                  }
                  else
                  {
                      temp="Have you ever been married?";

                  }

              }
              break;
          case 2:
              if(!uinput.equals("skipped"))
              {
                  if(uinput.equals("yes"))
                      marriageStatus="divorce";
                  else
                      marriageStatus="single";
              }
              if(childCnt==1)
              {
                  temp="You mentioned having a child, Do you have a son or a daughter?";

              }
              else if(childrenCnt==1)
              {
                  temp="You mentioned having children, How many boys and girls do you have?";

              }
              else
              {
                  boyCnt=0;
                  temp="skip";
              }
              break;

          case 3:
              if(!uinput.equals("skipped"))
              {
                  updateBoysCnt(uinput);
              }
              findSubSphere();
              switch(subSphere)
              {
                  case 1:
                      temp=f1(uinput,i);
                      break;
                  case 2:
                      temp=f2(uinput,i);
                      break;
                  case 3:
                      temp=f3(uinput,i);
                      break;
                  case 4:
                      temp=f4(uinput,i);
                      break;
                  case 5:
                      temp=f5(uinput,i);
                      break;
                  default:
                      temp="default";


              }
              break;
          default:
              switch(subSphere)
              {
                  case 1:
                      temp=f1(uinput,i);
                      break;
                  case 2:
                      temp=f2(uinput,i);
                      break;
                  case 3:
                      temp=f3(uinput,i);
                      break;
                  case 4:
                      temp=f4(uinput,i);
                      break;
                  case 5:
                      temp=f5(uinput,i);
                      break;
                  default:
                      temp="default";


              }







      }

      return temp;
    }
// function for updating boys count
    public void updateBoysCnt(String uinput)
    {
        int number=1;
        String[] splited = uinput.split("\\s+");
        for(int i=0;i<splited.length;i++)
        {
            if(splited[i].equals("son"))
            {
                boyCnt=number;
                break;
            }
            else
            {
                if(onlyDigits(splited[i],splited[i].length())==true)
                    number=Integer.parseInt(splited[i]);
            }
        }


    }

//  to check whether the entered string is a digit
    public static boolean
    onlyDigits(String str, int n)
    {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if ((str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i)=='.' ) {
                return true;
            }
            else {
                return false;
            }
        }
        return false;
    }

 // function for finding subsphere
    void findSubSphere()
    {
        String profession=introMap.getProfession();
        //    1. Divorce/Unfortunately seperated from husband
        //    2. status= single, student=yes
        //    3. status=Married, Working=no,  members:husband(no children)
        //    4. status=Married, Working=no, members:husband+ children
        //    5. status=married,Working=yes,members=husband

        if(marriageStatus.equals("divorce"))
            subSphere=1;
        else if(marriageStatus.equals("single"))
        {
            if(profession.equals("studying"))
                subSphere=2;
        }
        else
        {
            if(profession.equals("working"))
            {
                if(husbandCnt==1 && childCnt==0 && childrenCnt==0)
                    subSphere=5;


            }
            else
            {
                if(profession.equals("none"))
                {
                    if(husbandCnt==1 && childCnt==0 && childrenCnt==0)
                        subSphere=3;
                    if(husbandCnt==1 && (childCnt==0 || childrenCnt==0))
                        subSphere=4;

                }
            }

        }

    }


// questions for subcat 1
  public String f1(String uinput,int i)
  {
      String temp="null1";
      switch(i)
      {
          case 3:
              temp="I hope everyone around you is doing fine.";
              break;
          case 4:
              sentChk1+=uinput;
              temp="Guessing by your previous answers, there must be a reason you don’t live with your husband. Would you like to elaborate the reason?";
              break;
          case 5:
              sentChk1+=uinput;
              temp="How are you coping with this separation?";
              break;
          case 6:
              sentChk1+=uinput;
              temp="checksentiment";
              break;
          case 7:
              finalCause=uinput;sphereDetected=1;
              temp="doneFound";
              break;
          default:
              temp = "default";


      }
      return temp;

  }

 // question for subcat 2
    public String f2(String uinput,int i)
    {
        String temp="null2";
        switch(i)
        {
            case 3:
                temp="I hope everyone is doing good, health wise! ";
                break;
            case 4:
                sentChk2+=uinput;
                temp="Has your life outside home been giving you any problems?";
                break;
            case 5:
                sentChk2+=uinput;
                temp="checksentiment";
            case 6:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default";

        }

        return temp;

    }

// question for sub cat 3
    public String f3(String uinput,int i)
    {
        String temp="null3";
        switch(i)
        {
            case 3:
                temp="Looks like you are financially dependent on your husband. How do you find living with him?";
                break;
            case 4:
                sentChk3+=uinput;
                temp="Do you ever notice him getting aggressive or restless in behaviour when he doesn’t get what he wants? ";
                break;
            case 5:
                sentChk3+=uinput;
                temp="Have you planned on having kids yet?";
                break;
            case 6:
                sentChk3+=uinput;
                if(uinput.equals("yes"))
                {
                    temp="Have you faced any problems in having kids? ";
                }


        }


    return temp;
    }

// questions for sub category 4
    public String f4(String uinput,int i)
    {
        String temp="null4";
        switch(i)
        {
            case 3:
                temp="how has the environment in the house been recently";
                break;
            case 4:
                sentChk4+=uinput;
                if(boyCnt==0)
                {
                    temp="You have mentioned that you have children around, Do you wish to have any more?  ";

                }
                else
                {
                    temp="Did you face any problems when you were getting married? Like a cultural mismatch, maybe!  ";
                }
                break;
            case 5:
                sentChk4+=uinput;
                temp="Do you ever notice him passing sarcastic comments about anything when he doesn’t get what he wants? ";
                break;
            case 6:
                sentChk4+=uinput;
                temp="You mentioned living with in-laws! how is your relationship with them?";
                break;
            case 7:
                sentChk4+=uinput;
                temp="How is the health of your family members? ";
                break;
            case 8:
                sentChk4+=uinput;
                temp="checksentiment";
            case 9:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default";


        }
        return temp;

    }
// questions for sub category 5
    public String f5(String uinput,int i)
    {
        String temp="null5";
        switch(i)
        {
            case 3:
                temp="Freedom to do anything does not mean he is not going to comment about it! Have you noticed any indirect comments about any of your actions? ";
                break;
            case 4:
                sentChk5+=uinput;
                temp="You are a financially independent woman. Has your husband said anything about your life choices? ";
                break;
            case 5:
                sentChk5+=uinput;
                temp="Have you faced any problems in having kids or have you not planned on kids yet? ";
                break;
            case 6:
                sentChk5+=uinput;
                temp="checksentiment";
            case 7:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default";


        }

        return temp;
    }

// return final question
    public String finalQues()
    {
        String temp="finalnull";
        switch(subSphere)
        {
            case 1:
                temp="From what I understand, it looks like husband separation is an issue in your life. Is there any other thing related to him that you want to talk about?  ";
                break;
            case 2:
                temp="Looks like there could be some tension within you about this issue. Do you wish to tell us in detail about what is bothering you? ";
                break;
            case 3:
                temp="You don’t sound very happy in your marriage. I am here to listen to any more things you wish to talk about. ";
                break;
            case 4:
                temp="You sound stressed about your family and also the relationships. Is there anything else I should know? ";
                break;
            case 5:
                temp="You don’t sound very happy in your marriage. I am here to listen to any other things you wish to talk about. ";
                break;
            default:
                temp="defaultfinalque";

        }
        return temp;
    }




}
