package com.google.firebase.quickstart.auth.java;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isCounsellor;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isLegal;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.mCounsellorDatabaseReference;
import static com.google.firebase.quickstart.auth.java.ManageLegalAidContactsActivity.mLegalDatabaseReference;

public class ContactAdapter extends ArrayAdapter<Contact> {
    public ContactAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.item_contact, parent, false);
        }

        // RelativeLayout contactRelativeLayout = convertView.findViewById(R.id.contactRelativeLayout);
        TextView contactTextView = convertView.findViewById(R.id.contactTextView);
        // contactTextView.setClickable(true);
        // contactTextView.setMovementMethod(LinkMovementMethod.getInstance());

        TextView phoneTextView = convertView.findViewById(R.id.phoneTextView);
        ImageButton deleteContactButton = convertView.findViewById(R.id.deleteContactButton);

        Contact contact = getItem(position);
        contactTextView.setText(contact.getName());
        String phoneNum = "+"+contact.getPhone();
        phoneTextView.setText(phoneNum);

        AlertDialog diaBox = AskOption(contact);

        deleteContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"deleting contact: "+contact.getName()+", "+phoneNum,Toast.LENGTH_SHORT).show();
                // remove(contact);
                // notifyDataSetChanged();
                diaBox.show();
            }
        });

        return convertView;
    }

    private AlertDialog AskOption(Contact contact) {
        AlertDialog alertDialog = null;
        if(isCounsellor) {
            alertDialog = new AlertDialog.Builder(this.getContext())
                    // set message, title, and icon
                    .setTitle("Delete")
                    // .setMessage("Are you sure you want to delete this contact?\n\n"+contact.toString())
                    .setMessage(Html.fromHtml("Are you sure you want to delete this contact?\n\n<b><i>" + contact.toString() + "</b></i>"))
                    .setIcon(android.R.drawable.ic_menu_delete)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // deleting code
                            remove(contact);
                            notifyDataSetChanged();

                            FirebaseDatabase mFirebaseDatabase = FirebaseDatabase.getInstance();
                            mCounsellorDatabaseReference = mFirebaseDatabase.getReference().child("CounsellorContacts");
                            Query phoneQuery = mCounsellorDatabaseReference.orderByChild("phone").equalTo(contact.getPhone());
                            phoneQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot phoneSnapshot : dataSnapshot.getChildren()) {
                                        phoneSnapshot.getRef().removeValue();
                                    }
                                }

                                @Override
                                public void onCancelled(@NotNull DatabaseError databaseError) {
                                    Log.e("ContactAdapter", "onCancelled", databaseError.toException());
                                }
                            });

                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create();
        } else if (isLegal) {
            alertDialog = new AlertDialog.Builder(this.getContext())
                    // set message, title, and icon
                    .setTitle("Delete")
                    // .setMessage("Are you sure you want to delete this contact?\n\n"+contact.toString())
                    .setMessage(Html.fromHtml("Are you sure you want to delete this contact?\n\n<b><i>" + contact.toString() + "</b></i>"))
                    .setIcon(android.R.drawable.ic_menu_delete)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // deleting code
                            remove(contact);
                            notifyDataSetChanged();

                            FirebaseDatabase mFirebaseDatabase = FirebaseDatabase.getInstance();
                            mLegalDatabaseReference = mFirebaseDatabase.getReference().child("LegalContacts");
                            Query phoneQuery = mLegalDatabaseReference.orderByChild("phone").equalTo(contact.getPhone());
                            phoneQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot phoneSnapshot : dataSnapshot.getChildren()) {
                                        phoneSnapshot.getRef().removeValue();
                                    }
                                }

                                @Override
                                public void onCancelled(@NotNull DatabaseError databaseError) {
                                    Log.e("ContactAdapter", "onCancelled", databaseError.toException());
                                }
                            });

                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create();

        }
        return alertDialog;
    }
}
