package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

public class UpdateIntroActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    EditText age;
    EditText height;
    EditText weight;
    EditText locality;
    EditText members;
    EditText profession;
    EditText religion;
    EditText student;
    EditText studying;
    EditText work_life_balance;
    EditText working;

    String Mood = introMap.getMood();
    String Age = introMap.getAge();
    String Height = introMap.getHeight();
    String Weight = introMap.getWeight();
    String Locality = introMap.getLocality();
    String Members = introMap.getMembers();
    String Profession = introMap.getProfession();
    String Religion = introMap.getReligion();
    String Student = introMap.getStudent();
    String Studying = introMap.getStudying();
    String Work_life_balance = introMap.getWorkLifeBalance();
    String Working = introMap.getWorking();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_intro);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Users");

        age = (EditText) findViewById(R.id.age);
        height = (EditText) findViewById(R.id.height);
        weight = (EditText) findViewById(R.id.weight);
        locality = (EditText) findViewById(R.id.locality);
        members = (EditText) findViewById(R.id.members);
        profession = (EditText) findViewById(R.id.profession);
        religion = (EditText) findViewById(R.id.religion);
        student = (EditText) findViewById(R.id.student);
        studying = (EditText) findViewById(R.id.studying);
        work_life_balance = (EditText) findViewById(R.id.work_life_balance);
        working = (EditText) findViewById(R.id.working);

        //***************
        age.setText(Age);
        height.setText(Height);
        weight.setText(Weight);
        locality.setText(Locality);
        members.setText(Members);
        profession.setText(Profession);
        religion.setText(Religion);
        student.setText(Student);
        studying.setText(Studying);
        work_life_balance.setText(Work_life_balance);
        working.setText(Working);


        // verifyInfoExistence();
        Log.d("UpdateInfoActivity:", "introMap:" + introMap.toString());

        Button update_intro_button = (Button) findViewById(R.id.update_intro_button);
        update_intro_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Age = age.getText().toString();
                Height = height.getText().toString();
                Weight = weight.getText().toString();
                Locality = locality.getText().toString();
                Members = members.getText().toString();
                Profession = profession.getText().toString();
                Religion = religion.getText().toString();
                Student = student.getText().toString();
                Studying = studying.getText().toString();
                Work_life_balance = work_life_balance.getText().toString();
                Working = working.getText().toString();

                if (TextUtils.isEmpty(Age)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Age", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Height)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Height", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Weight)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Weight", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Locality)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Locality", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Members)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Members", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Profession)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Profession", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Religion)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Religion", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Student)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Student", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Studying)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Studying", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Work_life_balance)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Work Life Balance", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Working)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Working", Toast.LENGTH_SHORT).show();
                } else {
                    String currentUserId = firebaseAuth.getCurrentUser().getUid();
                    UserIntro profileMap = new UserIntro(Mood, Age, Locality, Height, Weight, Members, Student, Studying, Working, Profession, Religion, Work_life_balance);
                    mMessageDatabaseReference.child("Database").child(database_no).child(currentUserId).child("intro").setValue(profileMap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getApplicationContext(), "Intro Updated", Toast.LENGTH_SHORT).show();
                                        Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
                                        startActivity(i);
                                    } else {
                                        String Error = task.getException().toString();
                                        Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }
            }
        });
    }


}