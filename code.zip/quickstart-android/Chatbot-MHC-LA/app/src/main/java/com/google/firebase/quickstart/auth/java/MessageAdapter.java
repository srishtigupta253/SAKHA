package com.google.firebase.quickstart.auth.java;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.quickstart.auth.R;

import java.util.List;

import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.AdapterFlagCyber;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.CyberLabels;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.dass21.isLegalAid;
import static com.google.firebase.quickstart.auth.java.dass21.isSendSummary;
import static com.google.firebase.quickstart.auth.java.dass21.isSummary;

public class MessageAdapter extends ArrayAdapter<FriendlyMessage> {
    public MessageAdapter(Context context, int resource, List<FriendlyMessage> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.item_message, parent, false);
        }


        ImageView photoImageView = convertView.findViewById(R.id.photoImageView);

        TextView messageTextView = convertView.findViewById(R.id.messageTextView);
        messageTextView.setClickable(true);
        messageTextView.setMovementMethod(LinkMovementMethod.getInstance());

        TextView authorTextView = convertView.findViewById(R.id.nameTextView);

        Button bt1 = convertView.findViewById(R.id.opt1_button);
        Button bt2 = convertView.findViewById(R.id.opt2_button);
        Button bt3 = convertView.findViewById(R.id.opt3_button);
        Button bt4 = convertView.findViewById(R.id.opt4_button);
        Button bt5 = convertView.findViewById(R.id.opt5_button);
        Button bt6 = convertView.findViewById(R.id.opt6_button);
        Button bt7 = convertView.findViewById(R.id.opt7_button);
        Button bt8 = convertView.findViewById(R.id.opt8_button);

        // Button mSendButton = convertView.findViewById(R.id.sendButton);
        // final boolean[] isClick = {false};

        FriendlyMessage message = getItem(position);

        message.setText(message.getText().replace("\n","<br>"));
        bt1.setText(message.getOpt1());
        bt2.setText(message.getOpt2());
        bt3.setText(message.getOpt3());
        bt4.setText(message.getOpt4());
        bt5.setText(message.getOpt5());
        bt6.setText(message.getOpt6());
        bt7.setText(message.getOpt7());
        bt8.setText(message.getOpt8());

        if(message.getOpt1().equals("null"))
            bt1.setVisibility(View.GONE);
        else
            bt1.setVisibility(View.VISIBLE);

        if(message.getOpt2().equals("null"))
            bt2.setVisibility(View.GONE);
        else
            bt2.setVisibility(View.VISIBLE);

        if(message.getOpt3().equals("null"))
            bt3.setVisibility(View.GONE);
        else
            bt3.setVisibility(View.VISIBLE);

        if(message.getOpt4().equals("null"))
            bt4.setVisibility(View.GONE);
        else
            bt4.setVisibility(View.VISIBLE);

        if(message.getOpt5().equals("null"))
            bt5.setVisibility(View.GONE);
        else
            bt5.setVisibility(View.VISIBLE);

        if(message.getOpt6().equals("null"))
            bt6.setVisibility(View.GONE);
        else
            bt6.setVisibility(View.VISIBLE);

        if(message.getOpt7().equals("null"))
            bt7.setVisibility(View.GONE);
        else
            bt7.setVisibility(View.VISIBLE);

        if(message.getOpt8().equals("null"))
            bt8.setVisibility(View.GONE);
        else
            bt8.setVisibility(View.VISIBLE);


        // DONE: Change setOnClickListener for all buttons to account for change in Cyber Crime buttons of LifeStyleActivity.java
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt1(),Toast.LENGTH_SHORT).show();
               // FriendlyMessage friendlyMessage= new FriendlyMessage(message.getOpt1(),mUsername,null);
               //friendlyMessage.setOpt1("check");
               //  mMessageAdapter.add(friendlyMessage);
               //  mMessageAdapter.notifyDataSetChanged();

                mMessageEditText.setText(message.getOpt1());
                String temp=message.getOpt1();


                if(temp.equals("Faking my profile"))
                {
                    AdapterFlagCyber=1;
                    // CyberLabels[1]=3;
                    CyberLabels[15]=3;
                    CyberLabels[14]=3;
                    // faking_my_profile_suggestion();
                } else if(temp.equals("Yes, I want to see Summary")) {
//                    Intent iii = new Intent(getApplicationContext(), LegalAid.class);
//                    startActivity(iii);
                    isSummary = true;
                } else if(temp.equals("Yes, I would like to get a Legal Aid as well.")) {
//                    Intent iii = new Intent(getApplicationContext(), LegalAid.class);
//                    startActivity(iii);
                    isLegalAid = true;
                } else if(temp.equals("Yes, I am fine with sharing my info.")) {
                    isSendSummary = true;
                }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt2(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt2());
                String temp=message.getOpt2();
                if(temp.equals("Blackmailing"))
                {
                    AdapterFlagCyber=1;
                    // CyberLabels[2]=3;
                    // blackmailing_suggestion();

                } else if(temp.equals("No, Summary is not necessary")) {
                    isSummary = false;
                } else if(temp.equals("No, I don't need a Legal Aid now.")) {
                    isLegalAid = false;
                } else if (temp.equals("No, I don't want to share my info.")) {
                    isSendSummary = false;
                }

                mSendButton.performClick();
                // isClick[0] = true;

            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt3(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt3());
                String temp=message.getOpt3();
                if(temp.equals("Social Media account hacked"))
                {
                    AdapterFlagCyber=1;
                    // CyberLabels[10]=3;
                    // social_media_hacked_suggestion();
                }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt4(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt4());
                String temp=message.getOpt4();
                if(temp.equals("Online Harassment"))
                {
                    AdapterFlagCyber=1;
                    // CyberLabels[12]=3;
                    CyberLabels[14]=3;
                    // online_harassment_suggestion();
                }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt5(),Toast.LENGTH_SHORT).show();
//                FriendlyMessage friendlyMessage= new FriendlyMessage(message.getOpt1(),mUsername,null);
//                //friendlyMessage.setOpt1("check");
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText(message.getOpt5());
                String temp=message.getOpt5();
                if(temp.equals("Sending Obscene Content"))
                {
                    AdapterFlagCyber=1;
                    CyberLabels[16]=3;
                    // sending_obscene_content_suggestion();
                }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt6(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt6());
                String temp=message.getOpt6();

                // if(temp.equals("Online abuse by sharing false information"))
                // {
                //     AdapterFlagCyber=1;
                //     CyberLabels[4]=3;
                // }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt7(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt7());
                String temp=message.getOpt7();

                // if(temp.equals("Cyber stalking"))
                // {
                //     AdapterFlagCyber=1;
                //     CyberLabels[0]=3;
                // }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        bt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),message.getOpt8(),Toast.LENGTH_SHORT).show();

                mMessageEditText.setText(message.getOpt8());
//                String temp=message.getOpt();
//                if(temp.equals())
//                {
//                    AdapterFlagCyber=1;
//                    CyberLabels[1]=3;
//                }
                String temp=message.getOpt8();

                // if(temp.equals("My account has been hacked"))
                // {
                //     AdapterFlagCyber=1;
                //     CyberLabels[0]=3;
                // }

                mSendButton.performClick();
                // isClick[0] = true;
            }
        });

        // if (isClick[0]) {
        //     mSendButton.performClick();
        //     isClick[0] = false;
        // }

        boolean isPhoto = message.getPhotoUrl() != null;
        if (isPhoto) {
            messageTextView.setVisibility(View.GONE);
            photoImageView.setVisibility(View.VISIBLE);
            Glide.with(photoImageView.getContext())
                    .load(message.getPhotoUrl())
                    .into(photoImageView);
        } else {
            messageTextView.setVisibility(View.VISIBLE);
            photoImageView.setVisibility(View.GONE);
            // messageTextView.setText(message.getText());
            messageTextView.setText(Html.fromHtml(message.getText()));
        }

       // authorTextView.setText(message.getName());


//        String author=message.getName().toString();


        if (message.getName() != null && message.getName().equals("debug")) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.FILL_PARENT);
            params.weight = 1.0f;
            params.gravity = Gravity.CENTER;
            authorTextView.setTextColor(convertView.getResources().getColor(R.color.font_color));
            //authorTextView.setBackgroundColor(convertView.getResources().getColor(R.color.bot_background));
            authorTextView.setLayoutParams(params);


            // messageTextView.setText(message.getText());
            messageTextView.setText(Html.fromHtml(message.getText()));
            messageTextView.setBackgroundColor(convertView.getResources().getColor(R.color.debug_background));
            messageTextView.setLayoutParams(params);

            //messageTextView.setBackground(convertView.getResources().getColor(R.color.bot_background));

        } else if (message.getName() != null && message.getName().equals("SAKHA")) {

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.FILL_PARENT);
            params.weight = 1.0f;
            params.gravity = Gravity.LEFT;
            authorTextView.setTextColor(convertView.getResources().getColor(R.color.font_color));
            //authorTextView.setBackgroundColor(convertView.getResources().getColor(R.color.bot_background));
            authorTextView.setLayoutParams(params);


            // messageTextView.setText(message.getText());
            messageTextView.setText(Html.fromHtml(message.getText()));
            messageTextView.setTextColor(convertView.getResources().getColor(R.color.bot_text_test));
            messageTextView.setBackgroundResource(R.drawable.bot_message_bg);
//            messageTextView.setBackgroundColor(convertView.getResources().getColor(R.color.bot_background));
            messageTextView.setLayoutParams(params);

            //messageTextView.setBackground(convertView.getResources().getColor(R.color.bot_background));
        } else {
            //Toast.makeText(getContext(),message.getText(),Toast.LENGTH_SHORT).show();
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.FILL_PARENT);
            params.weight = 1.0f;
            params.gravity = Gravity.RIGHT;

            authorTextView.setTextColor(convertView.getResources().getColor(R.color.font_color));
            //authorTextView.setBackgroundColor(convertView.getResources().getColor(R.color.user_background));
            authorTextView.setLayoutParams(params);

            // messageTextView.setText(message.getText());
            messageTextView.setText(Html.fromHtml(message.getText()));
            messageTextView.setTextColor(convertView.getResources().getColor(R.color.user_text_test));
            messageTextView.setBackgroundResource(R.drawable.user_message_bg);
//            messageTextView.setBackgroundColor(convertView.getResources().getColor(R.color.user_background));

            messageTextView.setLayoutParams(params);
        }



        return convertView;
    }
}
