package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
//import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.MY_SOCKET_TIMEOUT_MS;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.whoApiRes;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.emotionApiRes;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.dass21.isFromMHC;
import static com.google.firebase.quickstart.auth.java.dass21.isSecondDassVisit;
import static com.google.firebase.quickstart.auth.java.dass21.isSecondVisit;

import org.json.JSONObject;

public class SuspectActivity extends AppCompatActivity {

    private static final String TAG = "SuspectActivity";

    // public static final String ANONYMOUS = "anonymous";
    //  public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mMessageListView;
    // public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    // private EditText mMessageEditText;
    // private Button mSendButton;

    //public static String mUsername=ANONYMOUS;
//    public static String sphereInPriority="null";
    public int introVar = 0;
    public int flowVar = 0;

    //public UserIntro introMap=new UserIntro();

    //    public static ArrayList <Pair <Integer,String> > orderForSphere = new ArrayList <Pair<Integer,String>> ();
//
//    public static UserLifestyle lifeMap= new UserLifestyle();
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    public int checkprof = 0;
    public int wrtGui = 0;
    public int askWhoVar = 0;
    public boolean isSuggestionsGiven = false;
    public boolean isWhoAsked = false;
    public String suspect = "null";

    public static int numSummaries = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_style);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                //introVar+=1;
                temp = slangCheck(temp);
//                introFun(temp);
                introFun(temp);


            }
        });


        // if (AdapterFlagCyber == 0) {
        //     APIresultUpdate();
        //     introStart("null");
        // } else {
        //     finalSuggestions();
        // }
        // newDebugMessage("whoApiRes = "+whoApiRes);
        numSummaries = getNumSummaries();
        introFun("null");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }

    public int getNumSummaries() {
        final int[] count = {0};
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        mMessageDatabaseReference.child(currentUserId).child("summary").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    count[0] = (int) snapshot.getChildrenCount();
                    numSummaries = count[0];
                    Toast.makeText(getApplicationContext(), "Number of Summaries before = " + numSummaries, Toast.LENGTH_SHORT).show();
                    Log.d("SuspectActivity:", "Number of Summaries before = " + count[0]);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return count[0];
    }

    /*public void askWho(String uinput) {
        switch (askWhoVar) {
            case 0:
                FriendlyMessage friendlyMessage = new FriendlyMessage(whoApiRes, "SAKHA", null);

                friendlyMessage.setText("Who do you suspect for the crime? (You can choose one of the options below or type in the chatbox.)");
                String[] suspectsSplit = whoApiRes.split(",");

                int counter = Math.min(suspectsSplit.length, 8);
                for (int i = 0; i < counter; i++) {
                    switch (i) {
                        case 0:
                            friendlyMessage.setOpt1(suspectsSplit[0]);
                            break;

                        case 1:
                            friendlyMessage.setOpt2(suspectsSplit[1]);
                            break;

                        case 2:
                            friendlyMessage.setOpt3(suspectsSplit[2]);
                            break;

                        case 3:
                            friendlyMessage.setOpt4(suspectsSplit[3]);
                            break;

                        case 4:
                            friendlyMessage.setOpt5(suspectsSplit[4]);
                            break;

                        case 5:
                            friendlyMessage.setOpt6(suspectsSplit[5]);
                            break;

                        case 6:
                            friendlyMessage.setOpt7(suspectsSplit[6]);
                            break;

                        case 7:
                            friendlyMessage.setOpt8(suspectsSplit[7]);
                            break;
                    }
                }

                for (int i = counter; i < 8; i++) {
                    friendlyMessage.setOpt8("null");
                }

                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();

                askWhoVar++;
                break;
            case 1:
                // FriendlyMessage friendlyMessage2 = new FriendlyMessage(whoApiRes+"->Len="+suspectsSplit.length,"SAKHA",null);
                // mMessageAdapter.add(friendlyMessage2);
                // mMessageAdapter.notifyDataSetChanged();

                if (!isWhoAsked) {
                    uinput = uinput.toLowerCase();
                    suspect = uinput;
                    Summary += "She suspects " + suspect + " about the crime. ";
                    isWhoAsked = true;
                    updateToFirebase();
                }

                // Intent ii = new Intent(getApplicationContext(), dass21.class);
                // startActivity(ii);
                break;
        }
    }*/

    public void introStart(String uinput) {
        String temp = "null";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        switch (askWhoVar) {
            case -1:
                introStart("null-suspect");
                break;
            case 0:
                // FriendlyMessage friendlyMessage = new FriendlyMessage(whoApiRes, "SAKHA", null);

                temp = "Who do you suspect for the crime? (You can choose one of the options below or type in the chat box.)";
                // String[] suspectsSplit = whoApiRes.split(",");
                ArrayList<String> suspectsSplit = new ArrayList<String>(Arrays.asList(whoApiRes.split(",")));

                while (suspectsSplit.size() < 8) {
                    suspectsSplit.add("null");
                }

                friendlyMessage.setOpt1(suspectsSplit.get(0));
                friendlyMessage.setOpt2(suspectsSplit.get(1));
                friendlyMessage.setOpt3(suspectsSplit.get(2));
                friendlyMessage.setOpt4(suspectsSplit.get(3));
                friendlyMessage.setOpt5(suspectsSplit.get(4));
                friendlyMessage.setOpt6(suspectsSplit.get(5));
                friendlyMessage.setOpt7(suspectsSplit.get(6));
                friendlyMessage.setOpt8(suspectsSplit.get(7));

                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();
                wrtGui = 1;

                askWhoVar++;
                break;
        }
    }

    public void introFun(String uinput) {
        String temp = "null";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        switch (askWhoVar) {
            case -1:
                introFun("null-suspect");
                break;
            case 0:
                // FriendlyMessage friendlyMessage = new FriendlyMessage(whoApiRes, "SAKHA", null);

                temp = "Who do you suspect for the crime? (You can choose one of the options below or type in the chat box.)";
                // String[] suspectsSplit = whoApiRes.split(",");
                ArrayList<String> suspectsSplit = new ArrayList<String>(Arrays.asList(whoApiRes.split(",")));

                while (suspectsSplit.size() < 8) {
                    suspectsSplit.add("null");
                }

                friendlyMessage.setOpt1(suspectsSplit.get(0));
                friendlyMessage.setOpt2(suspectsSplit.get(1));
                friendlyMessage.setOpt3(suspectsSplit.get(2));
                friendlyMessage.setOpt4(suspectsSplit.get(3));
                friendlyMessage.setOpt5(suspectsSplit.get(4));
                friendlyMessage.setOpt6(suspectsSplit.get(5));
                friendlyMessage.setOpt7(suspectsSplit.get(6));
                friendlyMessage.setOpt8(suspectsSplit.get(7));

                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();
                wrtGui = 1;

                askWhoVar++;
                break;
            case 1:
                // FriendlyMessage friendlyMessage2 = new FriendlyMessage(whoApiRes+"->Len="+suspectsSplit.length,"SAKHA",null);
                // mMessageAdapter.add(friendlyMessage2);
                // mMessageAdapter.notifyDataSetChanged();

                if (!isWhoAsked) {
                    uinput = uinput.toLowerCase();
                    suspect = uinput;
                    Summary += "She suspects " + suspect + " about the crime. ";
                    isWhoAsked = true;
                    updateToFirebase();
                }

                temp = "Have you reported the crime?";
                friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                mMessageAdapter.add(friendlyMessage);
                askWhoVar++;
                break;
            case 2:
                if (uinput.equalsIgnoreCase("yes")) {
                    temp = "When did you report?";
                    friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    askWhoVar = 3;
                } else {
                    // temp = "It might be helpful if you see the sections that apply to your crime.";
                    // friendlyMessage = new FriendlyMessage(temp,"SAKHA",null);
                    // friendlyMessage.setOpt1("Go to Legal Aid");
                    // friendlyMessage.setOpt2("I don't want Legal Aid");
                    // mMessageAdapter.add(friendlyMessage);
                    // mMessageAdapter.notifyDataSetChanged();
                    askWhoVar = 6;
                    introFun("null");
                }
                wrtGui = 0;
                break;
            case 3:
                temp = "Which police station did you report?";
                friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                askWhoVar++;
                break;
            case 4:
                temp = "Has any action been taken?";
                friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                askWhoVar = 6;
                break;
            case 5:
                if (uinput.equalsIgnoreCase("go to legal aid")) {
                    isFromMHC = true;
                    Intent iii = new Intent(getApplicationContext(), LegalAid.class);
                    startActivity(iii);
                } else {
                    askWhoVar++;
                    introFun("null");
                }
                break;
            case 6:
                temp = "Thank you for telling me about whatever has happened with you. I would like to be of some help by showing you the path ahead.";
                friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);

                if (!isSecondDassVisit) {
                    temp = "Before that I need to assess a few things about your current condition.";
                    friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                    mMessageAdapter.add(friendlyMessage);
                }

                mMessageAdapter.notifyDataSetChanged();
                wrtGui = 0;

                // funEmotion(lifeMap.getOpen_ended_answer());
                Intent ii = new Intent(getApplicationContext(), dass21.class);
                startActivity(ii);
                return;
        }

        if (wrtGui == 1) {
            friendlyMessage.setText(temp);
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
            wrtGui = 0;
        }
    }

    public void funEmotion(String uinput) {
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        //String url = "https://vaibhavqwerty.pythonanywhere.com/";
//        String url = "https://imash.pythonanywhere.com/emotion";
        String url = "https://sdandapat.pythonanywhere.com/emotion";


        StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                emotionApiRes = response;

                // FriendlyMessage friendlyMessage = new FriendlyMessage("funWho()->bertApiRes: "+bertApiRes, "debug", null);
                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();


                // FriendlyMessage friendlyMessage = new FriendlyMessage("whoApiRes: "+whoApiRes, "debug", null);
                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();

                // Intent ii=new Intent(getApplicationContext(),CyberCrimeNew.class);
                Intent ii = new Intent(getApplicationContext(), dass21.class);
                startActivity(ii);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                String temp = "emotionapierror";
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text", uinput);
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        sr.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        queue.add(sr);
    }

    // public String retInt(String str)
    // {
    //
    //     String[] splited = str.split("\\s+");
    //     for(int i=0;i<splited.length;i++)
    //     {
    //         int n=splited[i].length();
    //
    //         if(onlyDigits(splited[i],n)==true)
    //         {
    //             return splited[i];
    //         }
    //     }
    //
    //     return "null";
    // }
    //
    // public static boolean
    // onlyDigits(String str, int n)
    // {
    //     // Traverse the string from
    //     // start to end
    //     for (int i = 0; i < n; i++) {
    //
    //         // Check if character is
    //         // digit from 0-9
    //         // then return true
    //         // else false
    //         if ((str.charAt(i) >= '0'
    //                 && str.charAt(i) <= '9') || str.charAt(i)=='.' ) {
    //             return true;
    //         }
    //         else {
    //             return false;
    //         }
    //     }
    //     return false;
    // }

    void updateToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);
        mMessageDatabaseReference.child(currentUserId).child("suspect").setValue(suspect)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Suspect Info Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    // public boolean funYes(String uinput)
    // {
    //     uinput=uinput.toLowerCase();
    //     String[] splited= uinput.split(" ");
    //     for(int i=0;i<splited.length;i++)
    //     {
    //         if(splited[i].equals("yes"))
    //             return true;
    //     }
    //     return false;
    //
    // }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}