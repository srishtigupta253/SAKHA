package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.List;

public class ManageCounsellorContactsActivity extends AppCompatActivity {

    private static final String TAG = "ManageCounsellorContactsActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mCounsellorListView;
    private ProgressBar mProgressBar;
    // private ImageButton mPhotoPickerButton;
    // public static EditText mMessageEditText;
    // public static Button mSendButton;
    private Button mAddCounsellorContactButton;
    public static String mUsername=ANONYMOUS;

    public static ArrayList<Contact> contacts = new ArrayList<>();

    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    FirebaseDatabase mFirebaseDatabase;
    public static DatabaseReference mCounsellorDatabaseReference;

    public static ContactAdapter mCounsellorContactAdapter;

    public static boolean isCounsellor = false, isLegal = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counsellor_contacts);

        isCounsellor = true;
        isLegal = false;

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mCounsellorDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("CounsellorContacts");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mCounsellorListView = (ListView) findViewById(R.id.counsellorListView);
        mAddCounsellorContactButton = (Button) findViewById(R.id.addCounsellorContactButton);

        // mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        // mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        // mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
        List<Contact> contacts = new ArrayList<>();
        mCounsellorContactAdapter = new ContactAdapter(this, R.layout.item_contact, contacts);
        mCounsellorListView.setAdapter(mCounsellorContactAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

           // Send button sends a message and clears the EditText
        mAddCounsellorContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), AddContactActivity.class);
                startActivity(i);
                // mContactAdapter.notifyDataSetChanged();
            }
        });

//        Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//        startActivity(ii);

        initializeContacts();
        // newDebugContact("after contacts fetch, "+contacts.size()+contacts);
        // for (Contact c : contacts) {
        //     mContactAdapter.add(c);
        //     mContactAdapter.notifyDataSetChanged();
        // }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    // greetings and first question
    public void initializeContacts() {
        // contacts.add(new Contact(22.61,88.34,"Mahesh","917980664155",36));

        // newDebugContact("before contacts fetch, "+contacts.size()+contacts);
        for (Contact c : contacts) {
            mCounsellorContactAdapter.add(c);
            mCounsellorContactAdapter.notifyDataSetChanged();
        }

        getContacts();
        // (new Handler()).postDelayed(this::getContacts,1000);

        // newDebugContact("after contacts fetch, "+contacts.size()+contacts);
        // for (Contact c : contacts) {
        //     mContactAdapter.add(c);
        //     mContactAdapter.notifyDataSetChanged();
        // }
    }

    void getContacts() { //, double lat, double lon) {
        // mMessageDatabaseReference.addValueEventListener(new ValueEventListener() {
        mCounsellorDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // int count = (int) dataSnapshot.getChildrenCount();
                // newDebugContact("count = "+count);
                // (new Handler()).postDelayed(this::pass, 20000);

                if (dataSnapshot.exists()) {
                    // newDebugContact("contacts exist");

                    for (DataSnapshot phoneSnapshot: dataSnapshot.getChildren()) {
                        Contact c = phoneSnapshot.getValue(Contact.class);
                        contacts.add(c);
                    }

                    // newDebugContact("during contacts fetch, "+contacts.size()+contacts);
                    for (Contact c : contacts) {
                        mCounsellorContactAdapter.add(c);
                        mCounsellorContactAdapter.notifyDataSetChanged();
                    }
                } else {
                    // newDebugContact("contacts don't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    void newDebugContact(String message) {
        Contact contact = new Contact(16.49,80.65,message,"91abcdefghi",2);
        mCounsellorContactAdapter.add(contact);
        mCounsellorContactAdapter.notifyDataSetChanged();
    }

    @Override
    public void finish() {
        contacts.clear();
        mCounsellorContactAdapter.clear();
        mCounsellorContactAdapter.notifyDataSetChanged();
        super.finish();
    }
}
