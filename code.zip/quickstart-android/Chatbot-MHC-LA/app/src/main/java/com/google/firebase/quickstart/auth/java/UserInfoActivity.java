package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;
import com.google.firebase.quickstart.auth.java.requests.RequestModel;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;

import java.text.ParseException;
import java.util.Map;

public class UserInfoActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        // mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Users");
        mMessageDatabaseReference = mFirebaseDatabase.getReference();

        Button update = (Button) findViewById(R.id.updatebutton);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText license = (EditText) findViewById(R.id.license);
                EditText empid = (EditText) findViewById(R.id.empid);
                EditText username = (EditText) findViewById(R.id.username);
                EditText firstname = (EditText) findViewById(R.id.firstname);
                EditText lastname = (EditText) findViewById(R.id.lastname);
                EditText phoneno = (EditText) findViewById(R.id.phonenumber);
                EditText address = (EditText) findViewById(R.id.address_user);


                String License = license.getText().toString();
                String EmpID = empid.getText().toString();
                String Username = username.getText().toString();
                String PhoneNo = phoneno.getText().toString();
                String Firstname = firstname.getText().toString();
                String Lastname = lastname.getText().toString();
                String Address = address.getText().toString();

                if (TextUtils.isEmpty(License)) {
                    Toast.makeText(getApplicationContext(), "Please enter your License Key", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(EmpID) && !License.equalsIgnoreCase("LICFREE")) {
                    Toast.makeText(getApplicationContext(), "Please enter your Employ ID", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Username)) {
                    Toast.makeText(getApplicationContext(), "Please enter your Nickname (for conversation)", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Firstname)) {
                    Toast.makeText(getApplicationContext(), "Please enter your First Number", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Lastname)) {
                    Toast.makeText(getApplicationContext(), "Please enter your Last Number", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(PhoneNo)) {
                    Toast.makeText(getApplicationContext(), "Please enter your Phone Number", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Address)) {
                    Toast.makeText(getApplicationContext(), "Please enter your Address", Toast.LENGTH_SHORT).show();
                } else {
                    String currentUserId = firebaseAuth.getCurrentUser().getUid();
                    //String deviceToken = FirebaseInstanceId.getInstance().getToken();
                    //HashMap<String ,String> profileMap = new HashMap<>();
//                    profileMap.put("device_token",deviceToken);
//                    profileMap.put("uid",currentUserId);
//                    profileMap.put("name",Username);
//                    profileMap.put("phone_number",PhoneNo);
//                    profileMap.put("address",Address);

                    // Query <License,Database_no> from Firebase. If Valid, Database No. will have certain value. Else (if invalid), Database No. will be null.
                    // Also add user to UserDBKey
                    // final String[] database_no = {null};
                    mMessageDatabaseReference.child("All_License").child(License).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                database_no = snapshot.getValue(String.class);
                                Log.d("UserInfoActivity:", "License: " + License + ", database_no: " + database_no);
                                if (database_no != null) {

                                    UserInfo profileMap = new UserInfo(currentUserId, Username, Firstname, Lastname, PhoneNo, Address);
                                    RequestModel requestMap = new RequestModel(currentUserId, Firstname + " " + Lastname, EmpID, PhoneNo, 0L);

                                    // check if the user is approved by org admin
                                    mMessageDatabaseReference.child("UserDBKey").child(currentUserId).addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            if (snapshot.exists()) // user is approved
                                            {
                                                // continue as normal TODO : display welcome popup
                                                showWelcomeAlert();

                                                mMessageDatabaseReference.child("UserDBKey").child(currentUserId).setValue(database_no)
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(getApplicationContext(), "UserDB Initialized", Toast.LENGTH_SHORT).show();
                                                                } else {
                                                                    String Error = task.getException().toString();
                                                                    Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });


                                                mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("info").setValue(profileMap)
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {

                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(getApplicationContext(), "Profile Info Initialized", Toast.LENGTH_SHORT).show();
//                                                        Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
//                                                        startActivity(i);
                                                                } else {
                                                                    String Error = task.getException().toString();
                                                                    Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });

                                                /** TEMP : ADD USER role by default -- REMOVE **/
                                                mMessageDatabaseReference.child("Database").child(database_no).child("Role").child(currentUserId).setValue("user")
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {

                                                                if (task.isSuccessful()) {
                                                                    Toast.makeText(getApplicationContext(), "Default Role Assigned", Toast.LENGTH_SHORT).show();
                                                                    verifyUserExistence();

//                                                        Intent i = new Intent(getApplicationContext(), IntroActivity.class);
//                                                        startActivity(i);
                                                                } else {
                                                                    String Error = task.getException().toString();
                                                                    Toast.makeText(getApplicationContext(), "Error Assigning Role " + Error, Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });
                                            } else // user is not approved
                                            {
                                                // display "not verified yet" pop up
                                                showNotApprovedAlert(requestMap);

                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                                } else {
                                    Toast.makeText(getApplicationContext(), "Invalid License Key: User not in any database", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Invalid License Key", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }
        });
    }

    private void verifyUserExistence() {
        String currentUserId = firebaseAuth.getUid();


        assert currentUserId != null;
        mMessageDatabaseReference.child("UserDBKey").child(currentUserId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // sentToResturentsActivity();
                    database_no = dataSnapshot.getValue(String.class);
                    Log.d("EmailPasswordActivity:", "database_no: " + database_no);
                    Toast.makeText(getApplicationContext(), "database_no: " + database_no, Toast.LENGTH_SHORT).show();
                    mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("info").child("name").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                mUsername = snapshot.getValue(String.class);
                                Toast.makeText(getApplicationContext(), "Welcome " + mUsername + "!", Toast.LENGTH_SHORT).show();

                                // Intent i =new Intent(getApplicationContext(),dass21.class);
                                mMessageDatabaseReference.child("Database").child(database_no).child("Role").child(currentUserId).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists()) {
                                            String role = snapshot.getValue(String.class);
                                            Toast.makeText(getApplicationContext(), mUsername + " is a(n) " + role, Toast.LENGTH_SHORT).show();
                                            assert role != null;
                                            if (role.equalsIgnoreCase("user")) {
                                                Intent i = new Intent(getApplicationContext(), IntroActivity.class);
                                                startActivity(i);
                                            } else if (role.equalsIgnoreCase("admin")) {
                                                Intent i = new Intent(getApplicationContext(), AdminPanelActivity.class);
                                                startActivity(i);
                                            } else if (role.equalsIgnoreCase("counsellor")) {
                                                Toast.makeText(getApplicationContext(), "Counsellor's Panel COMING SOON", Toast.LENGTH_SHORT).show();
                                                // Intent i = new Intent(getApplicationContext(), CounsellorPanelActivity.class);
                                                Intent i = new Intent(getApplicationContext(), ComingSoonActivity.class);
                                                startActivity(i);
                                            } else {
                                                Toast.makeText(getApplicationContext(), "Verify your role with admin", Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Roles not assigned for your organization", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            } else {
                                // TODO: Explain this else condition
                                Toast.makeText(getApplicationContext(), "User in Database: Enter Info", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(getApplicationContext(), UserInfoActivity.class);
                                startActivity(i);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "New User: Enter Info", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), UserInfoActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void showNotApprovedAlert(RequestModel requestMap) {

        AlertDialog notApprovedDialog = new AlertDialog.Builder(this).create();

        notApprovedDialog.setTitle("Verification Pending");
        notApprovedDialog.setMessage("You have not been verified by the org admin. Please send approval request.");
        notApprovedDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Request Approval", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                // Check if request was previously sent
                mMessageDatabaseReference.child("Database").child(database_no).child("Requests").child(requestMap.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            notApprovedDialog.cancel();
                            showAlreadyRequestedAlert();
                        }
                        else
                        {
                            // send user data to request db
                            sendRequest(requestMap);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


                // TODO : send notification to the admin app
                // TODO : send email to the admin MAYBE
            }
        });

        notApprovedDialog.show();
    }

    private void sendRequest(RequestModel requestMap) {
        long currentTimeStamp = System.currentTimeMillis();
//        long unixTime = System.currentTimeMillis();
//        String currentTimeStamp = String.valueOf(unixTime); // timestamp to know the order of request

        requestMap.setTimestamp(currentTimeStamp);

        Log.v("utk", "current timestamp : " + currentTimeStamp);
        mMessageDatabaseReference.child("Database").child(database_no).child("Requests").child(requestMap.getUid()).setValue(requestMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {
                            Log.v("utk","request sent");

                        } else {
                            Log.v("utk","Error in sending request");
                        }
                    }
                });
    }

    private void showAlreadyRequestedAlert() {

        AlertDialog alreadyRequestedDialog = new AlertDialog.Builder(this).create();

        alreadyRequestedDialog.setTitle("Approval request already sent");
        alreadyRequestedDialog.setMessage("Please wait for the admin to approve your request");
        alreadyRequestedDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                alreadyRequestedDialog.cancel();
            }
        });

        alreadyRequestedDialog.show();
    }

    private void showWelcomeAlert() {
        Toast.makeText(this, "You have been approved. Welcome", Toast.LENGTH_SHORT).show();
    }


}