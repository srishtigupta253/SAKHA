package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.usersList;

import static java.lang.Thread.sleep;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatisticsActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public static MessageAdapter mMessageAdapter;
    public static int usesrWriteFlag = 1;

    public static boolean isLifeStyleExists = false;

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    static ValueEventListener listener;

    AnyChartView anyChartView;
    Pie pie;
    Boolean justOpened;
    Map<String, Integer> sleepMap= new HashMap<String, Integer>();
    Map<String, Integer> crimeMap= new HashMap<String, Integer>();
    Map<String, Integer> anxietyMap= new HashMap<String, Integer>();
    Map<String, Integer> depressionMap= new HashMap<String, Integer>();
    Map<String, Integer> stressMap= new HashMap<String, Integer>();
    Map<String, Integer> therapyMap= new HashMap<String, Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);

        anyChartView = findViewById(R.id.pie_chart);
        pie = AnyChart.pie();
        anyChartView.setChart(pie);

        justOpened = true;

        Spinner spinner = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.statistics_parameters, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(this);

        getUsersList();


    }

    void sleepPieChart() {
        if(!sleepMap.isEmpty())
        {
            setupPieChart(sleepMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        UserLifestyle lifestyle = introSnapshot.getValue(UserLifestyle.class);
                        String key = lifestyle.getSleep_hours();
                        int count = sleepMap.containsKey(key) ? sleepMap.get(key) : 0;
                        sleepMap.put(key,count+1);
                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(sleepMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }

    void crimePieChart() {
        if(!crimeMap.isEmpty())
        {
            setupPieChart(crimeMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("cybercrimes_detected").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        String crimes = introSnapshot.getValue(String.class);
                        for(String key : crimes.split(" "))
                        {
                            int count = crimeMap.containsKey(key) ? crimeMap.get(key) : 0;
                            crimeMap.put(key,count+1);
                        }

                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(crimeMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }

    void anxietyPieChart() {
        if(!anxietyMap.isEmpty())
        {
            setupPieChart(anxietyMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("dassScreeningResult").child("anxiety_result").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        String key = introSnapshot.getValue(String.class);
                        int count = anxietyMap.containsKey(key) ? anxietyMap.get(key) : 0;
                        anxietyMap.put(key,count+1);
                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(anxietyMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }

    void depressionPieChart() {
        if(!depressionMap.isEmpty())
        {
            setupPieChart(depressionMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("dassScreeningResult").child("depression_result").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        String key = introSnapshot.getValue(String.class);
                        int count = depressionMap.containsKey(key) ? depressionMap.get(key) : 0;
                        depressionMap.put(key,count+1);
                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(depressionMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }

    void stressPieChart() {
        if(!stressMap.isEmpty())
        {
            setupPieChart(stressMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("dassScreeningResult").child("anxiety_result").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        String key = introSnapshot.getValue(String.class);
                        int count = stressMap.containsKey(key) ? stressMap.get(key) : 0;
                        stressMap.put(key,count+1);
                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(stressMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }

    void therapyPieChart() {
        if(!therapyMap.isEmpty())
        {
            setupPieChart(therapyMap);
            return;
        }

        for (String uid : usersList) {

            mMessageDatabaseReference.child(uid).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                    if(introSnapshot.exists())
                    {
                        UserLifestyle lifestyle = introSnapshot.getValue(UserLifestyle.class);
                        String key = lifestyle.getTherapist_visit();
                        int count = therapyMap.containsKey(key) ? therapyMap.get(key) : 0;
                        therapyMap.put(key,count+1);
                    }
                    //onDataChange is async so call the next ui change after this function has finished
                    if(uid==usersList.get(usersList.size()-1))
                        setupPieChart(therapyMap);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                }
            });
        }
    }



    void setupPieChart(Map<String,Integer> dataMap) {
        List<DataEntry> dataEntries = new ArrayList<>();

        for( Map.Entry<String, Integer> mp : dataMap.entrySet())
        {
            dataEntries.add(new ValueDataEntry(mp.getKey(),mp.getValue()));
        }
        Log.d("stats","setup Pie no. of dataentries : "+dataEntries.size());
        pie.data(dataEntries);
    }

    void getUsersList() {

        mMessageDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot uidSnapshot : dataSnapshot.getChildren()) {
                        String uid = uidSnapshot.getKey();

                        usersList.add(uid);
                    }
                } else {
                    Log.d("getUsersList:", "users list doesn't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(justOpened)
        {
            justOpened =false;
            return;
        }

        Log.d("stats","spinner position -> "+i+" long l-> "+l);
        switch (i) {
            case (1) :
                Log.d("stats","spin 1");
                sleepPieChart();
                break;
            case (2) :
                Log.d("stats","spin 2");
                anxietyPieChart();
                break;
            case (3):
                Log.d("stats","spin 3");
                depressionPieChart();
                break;
            case (4):
                Log.d("stats","spin 4");
                stressPieChart();
                break;
            case (5):
                crimePieChart();
                break;
            case (6):
                therapyPieChart();
                break;
            default:
                Log.d("stats","spin default");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}

