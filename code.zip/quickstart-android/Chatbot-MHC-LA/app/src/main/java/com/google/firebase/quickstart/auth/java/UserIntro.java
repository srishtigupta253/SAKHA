package com.google.firebase.quickstart.auth.java;

import java.util.ArrayList;

public class UserIntro {

    private String mood;
    private String age;
    private String locality;
    private String religion;
    private String weight;
    private String height;
    private String members;

    private String student;     // is the user studying or not
    private String studying;    // what is the user studying

    private String working;     // is the user working or not
    private String profession;  // what is the user's profession
    private String workLifeBalance;
    // private String duration ;

    public UserIntro() {
        this.mood = "null";
        this.age = "null";
        this.locality = "null";
        this.height = "null";
        this.weight = "null";
        this.members = "null";
        this.student = "null";
        this.studying = "null";
        this.working = "null";
        this.profession = "null";
        this.religion = "null";
        this.workLifeBalance = "null";
    }

    public UserIntro(String mood, String age, String locality, String height, String weight, String members, String student, String studying, String working, String profession, String religion, String workLifeBalance) {
        this.mood = mood;
        this.age = age;
        this.locality = locality;
        this.height = height;
        this.weight = weight;
        this.members = members;
        this.student = student;
        this.studying = studying;
        this.working = working;
        this.profession = profession;
        this.religion = religion;
        this.workLifeBalance = workLifeBalance;
    }

    public String getMood() {
        return mood;
    }

    public String getMembers() {
        return members;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getAge() {
        return age;
    }

//    public String getDuration() {
//        return duration;
//    }


    public String getReligion() {
        return religion;
    }

    public String getLocality() {
        return locality;
    }

    public String getStudent() {
        return student;
    }

    public String getStudying() {
        return studying;
    }

    public String getWorking() {
        return working;
    }

    public String getProfession() {
        return profession;
    }

    public String getWorkLifeBalance() {
        return workLifeBalance;
    }

    public void setMood(String mood) {
        this.mood = mood;
    }

    public void setAge(String age) {
        this.age = age;
    }

//    public void setDuration(String duration) {
//        this.duration = duration;
//    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public void setMembers(String members) {
        this.members = members;
    }

    public void setStudent(String student) {
        this.student = student;
    }

    public void setStudying(String studying) {
        this.studying = studying;
    }

    public void setWorking(String working) {
        this.working = working;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public void setWorkLifeBalance(String workLifeBalance) {
        this.workLifeBalance = workLifeBalance;
    }

    @Override
    public String toString() {
        return "UserIntro{" +
                "mood='" + mood + '\'' +
                "age='" + age + '\'' +
                ", locality='" + locality + '\'' +
                ", religion='" + religion + '\'' +
                ", weight='" + weight + '\'' +
                ", height='" + height + '\'' +
                ", members='" + members + '\'' +
                ", student='" + student + '\'' +
                ", studying='" + studying + '\'' +
                ", working='" + working + '\'' +
                ", profession='" + profession + '\'' +
                ", workLifeBalance='" + workLifeBalance + '\'' +
                '}';
    }
}
