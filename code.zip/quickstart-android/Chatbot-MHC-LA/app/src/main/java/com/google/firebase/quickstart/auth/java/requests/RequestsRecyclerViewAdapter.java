package com.google.firebase.quickstart.auth.java.requests;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.quickstart.auth.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class RequestsRecyclerViewAdapter extends RecyclerView.Adapter<RequestsRecyclerViewAdapter.MyViewHolder>{

    private final RequestsRecyclerViewInterface requestsRecyclerViewInterface;
    Context context;
    ArrayList<RequestModel> requests;


    //constructor
    public RequestsRecyclerViewAdapter (Context context, ArrayList<RequestModel> requests, RequestsRecyclerViewInterface requestsRecyclerViewInterface) {
        this.context = context;
        this.requests = requests;
        this.requestsRecyclerViewInterface = requestsRecyclerViewInterface;
    }

    @NonNull
    @Override
    public RequestsRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflate the each item
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_requests,parent,false);

        return new RequestsRecyclerViewAdapter.MyViewHolder(view, requestsRecyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestsRecyclerViewAdapter.MyViewHolder holder, int position) {
        // bind values to each item as they come back to the screen based on position on the screen
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy hh:mm aaa");
        holder.name.setText(requests.get(position).getName());
        holder.empID.setText(requests.get(position).getEmpId());
        holder.datetime.setText(dateFormat.format(new Date(requests.get(position).getTimestamp())));
    }

    @Override
    public int getItemCount() {
        return requests.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, datetime, empID;
        public MyViewHolder(@NonNull View itemView, RequestsRecyclerViewInterface requestsRecyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.text_view_request_name);
            datetime = itemView.findViewById(R.id.text_view_request_time);
            empID = itemView.findViewById(R.id.text_view_request_empID);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(requestsRecyclerViewInterface != null)
                    {
                        int pos = getBindingAdapterPosition();
                        if(pos != RecyclerView.NO_POSITION) {
                            requestsRecyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });
        }
    }
}
