package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.google.firebase.quickstart.auth.java.IntroActivity.ANONYMOUS;
import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
//import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.orderForSphere;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.sphereInPriority;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;


public class RootCauseActivity extends AppCompatActivity {

    private static final String TAG = "LifeStyleActivity";

    // public static final String ANONYMOUS = "anonymous";
    //  public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;

    public static int isSentiment=0;

    private ListView mMessageListView;
    // public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    private EditText mMessageEditText;
    private Button mSendButton;
    //public static String mUsername=ANONYMOUS;

    public static String uinput2="null";
    public int introVar=0;
    //public UserIntro introMap=new UserIntro();


    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    public int checkprof=0;
    public int wrtGui=1;
    public String curSphere="null";
    //objects for various sphere
    public static FamilySphere ObjFamily=new FamilySphere();
    public static SocietalSphere ObjSociety=new SocietalSphere();
    public static CyberSphere ObjCyber=new CyberSphere();
    public static WorkSphere ObjWork= new WorkSphere();
    public static StudySphere ObjStudy= new StudySphere();

    public static int subSphere=0;
    public int indexForPriority=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root_cause);



        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);


        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click


                String temp=mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage=new FriendlyMessage(temp,mUsername,null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                introVar+=1;
                temp=slangCheck(temp);
                funQuestion(temp);


            }
        });

        introStart();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }


    public void introStart()
    {

        sphereInPriority=sphereInPriority.replaceAll("[^a-zA-Z0-9,]", ""); ;
        String[] splited = sphereInPriority.split(",");
        indexForPriority++;
        introVar=0;
        curSphere=splited[indexForPriority];
  //  curSphere="cyber";
//        Toast.makeText(getApplicationContext(),sphereInPriority,Toast.LENGTH_SHORT).show();
        funQuestion("null");







    }

    public void funQuestion(String uinput)
    {
        String temp="null";
        switch(curSphere)
        {
            case "family":
                if(isSentiment==1)
                    funSentiment(uinput);
                else
                    temp=ObjFamily.funFamily(introVar,uinput);
                break;

            case "cyber":
                if(isSentiment==1)
                    funSentiment(uinput);
                else
                    temp=ObjCyber.funCyber(introVar,uinput);
                break;
            case "society":
                if(isSentiment==1)
                    funSentiment(uinput);
                else
                    temp=ObjSociety.funSociety(introVar,uinput);

                break;
            case "work":
                if(isSentiment==1)
                    funSentiment(uinput);
                else
                    temp=ObjWork.funWork(introVar,uinput);
                break;
            case "study":
                if(isSentiment==1)
                    funSentiment(uinput);
                else
                    temp=ObjStudy.funStudy(introVar,uinput);
                break;
            case "unknown":
                break;
            default:
                temp="default";

        }


        if(temp.equals("doneFound"))
        {
           // updateToFirebase();
//            if(ObjCyber.sphereDetected==0)
//            rootMap.setCyber_check("Not found");
//            else
//            rootMap.setCyber_check("found");
//
//            FriendlyMessage friendlyMessage = new FriendlyMessage(rootMap.getCyber_check(), "SAKHA", null);
//            mMessageAdapter.add(friendlyMessage);
//            mMessageAdapter.notifyDataSetChanged();
            Intent ii=new Intent(getApplicationContext(),dass21.class);
            startActivity(ii);
            //root cause detected;
        }
        else if(temp.equals("doneNotFound"))
        {

            introStart();
        }
        else if(temp.equals("checksentiment"))
        {
            switch(curSphere)
            {
                case "family":
                    switch(subSphere)
                    {
                        case 1:
                            funSentiment2(ObjFamily.sentChk1);
                            break;
                        case 2:
                            funSentiment2(ObjFamily.sentChk2);
                            break;
                        case 3:
                            funSentiment2(ObjFamily.sentChk3);
                            break;
                        case 4:
                            funSentiment2(ObjFamily.sentChk4);
                            break;
                        case 5:
                            funSentiment2(ObjFamily.sentChk5);
                            break;

                    }

                    break;
                case "cyber":
                    funSentiment2(ObjCyber.totalSentCheck);
                    break;
                case "society":
                    funSentiment2(ObjSociety.totalSentCheck);
                    break;
                case "work":
                    funSentiment2(ObjWork.totalSentCheck);
                    break;
                case "study":
                    funSentiment2(ObjStudy.totalSentCheck);
                    break;
                case "unknown":
                    break;
                default:
                    temp="default";
            }

        }
        else if(temp.equals("skip"))
        {
            introVar+=1;
            funQuestion("skipped");
        }
        else
        if(!temp.equals("null")) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        }

    }




    public String retInt(String str)
    {

        String[] splited = str.split("\\s+");
        for(int i=0;i<splited.length;i++)
        {
            int n=splited[i].length();

            if(onlyDigits(splited[i],n)==true)
            {
                return splited[i];
            }
        }

        return "null";
    }

    public static boolean
    onlyDigits(String str, int n)
    {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if ((str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i)=='.' ) {
                return true;
            }
            else {
                return false;
            }
        }
        return false;
    }



    public void funSentiment(String uinput) {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://sentiment-analysis-api.herokuapp.com/sentiment";

        StringRequest sr = new StringRequest(Request.Method.POST, url , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
//                output.setText(response.toUpperCase());
                Toast.makeText(getApplicationContext(),response.toUpperCase(),Toast.LENGTH_SHORT).show();

                String temp="funsentiment";
                switch(curSphere)
                {
                    case "family":
                        temp=ObjFamily.funFamily(introVar,response.toLowerCase());
                        break;
                    case "cyber":
                        temp=ObjCyber.funCyber(introVar,response.toLowerCase());
                        break;
                    case "society":
                        temp=ObjSociety.funSociety(introVar,response.toLowerCase());
                        break;
                    case "work":
                        temp=ObjWork.funWork(introVar,response.toLowerCase());
                        break;
                    case "study":
                        temp=ObjStudy.funStudy(introVar,response.toLowerCase());
                        break;
                    case "unknown":
                        break;
                    default:
                        temp="default";
                }
                if(temp.equals("doneNotFound"))
                {
                    introStart();
                }
                else
                { FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
                String temp="apierror";
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text",uinput );
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(sr);



    }

    public void funSentiment2(String uinput) {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://sentiment-analysis-api.herokuapp.com/sentiment";

        StringRequest sr = new StringRequest(Request.Method.POST, url , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
//                output.setText(response.toUpperCase());
                Toast.makeText(getApplicationContext(),response.toUpperCase(),Toast.LENGTH_SHORT).show();
                String res=response.toLowerCase();
                if(!res.equals("negative"))
                {
                    introStart();
                }
                else
                {
                    String temp="null";
                    switch(curSphere)
                    {
                        case "family":
                            temp=ObjFamily.finalQues();
                            break;
                        case "cyber":
                            temp=ObjCyber.finalQues();
                            break;
                        case "society":
                            temp=ObjSociety.finalQues();
                            break;
                        case "work":
                            temp=ObjWork.finalQues();
                            break;
                        case "study":
                            temp=ObjStudy.finalQues();
                            break;
                        case "unknown":
                            break;
                        default:

                    }

                    FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text",uinput );
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(sr);



    }

    public String slangCheck(String uinput)
    {
        String[] splited = uinput.split(" ");
        String ans="";
        for(int i=0;i<splited.length;i++)
        {
            if(slangList.get(splited[i])!=null)
                ans=ans+slangList.get(splited[i]);
            else
                ans=ans+splited[i];

            if(i<splited.length-1)
                ans=ans+" ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }





}