package com.google.firebase.quickstart.auth.java;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;
import com.google.firebase.quickstart.auth.java.requests.RequestsActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;

public class AdminPanelActivity extends AppCompatActivity {
    public static MessageAdapter mMessageAdapter;
    public static int usesrWriteFlag=1;

    public static boolean isLifeStyleExists = false;

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    static ValueEventListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

        Button button_counsellor_contacts = findViewById(R.id.button_counsellor_contacts);
        Button button_legal_aid_contacts = findViewById(R.id.button_legal_aid_contacts);
        Button button_view_summaries = findViewById(R.id.button_view_summaries);
        Button button_view_statistics = findViewById(R.id.button_view_statistics);
        Button button_active_requests = findViewById(R.id.button_view_requests);

        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);

        button_counsellor_contacts.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                String currentUserId = firebaseAuth.getUid();

                // TODO: Change destination activity here
                Intent i = new Intent(getApplicationContext(),ManageCounsellorContactsActivity.class);
                // Intent i=new Intent(getApplicationContext(),dass21.class);
                startActivity(i);

            }
        });

        button_legal_aid_contacts.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                Intent i = new Intent(getApplicationContext(),ManageLegalAidContactsActivity.class);
                startActivity(i);
            }
        });

        button_view_summaries.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                Intent i = new Intent(getApplicationContext(),SummaryFilterActivity.class);
                // Intent i = new Intent(getApplicationContext(),ViewSummariesActivity.class);
                startActivity(i);
            }
        });

        button_view_statistics.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                Intent i = new Intent(getApplicationContext(),StatisticsActivity.class);
                startActivity(i);
            }
        });

        button_active_requests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open Requests Activity
                    Intent i = new Intent(getApplicationContext(), RequestsActivity.class);
                    startActivity(i);
            }
        });

    }

    private void verifyIntroExistence() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child(currentUserId).child("intro").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if((dataSnapshot.child("age").exists()))
                {
                    // newDebugMessage("verifyIntroExistence: Intro exists");
                    //sentToResturentsActivity();
                    introMap = dataSnapshot.getValue(UserIntro.class);
                    // int age=introMap.getAge();
                    Toast.makeText(getApplicationContext(),"intro exists" , Toast.LENGTH_SHORT).show();
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                }
                else
                {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(),"intro doesn't exist" , Toast.LENGTH_SHORT).show();
                    Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
