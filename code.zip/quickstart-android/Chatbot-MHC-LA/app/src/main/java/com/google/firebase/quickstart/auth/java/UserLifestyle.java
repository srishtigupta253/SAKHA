package com.google.firebase.quickstart.auth.java;

import com.firebase.ui.auth.data.model.User;

public class UserLifestyle {

    private String physical_activity;
    private String physical_activity_type;
    private String physical_activity_regular;
    private String hobbies;
    private String sleep_hours;
    private String healthy_diet;
    private String timely_diet;
    private String weight_change;
    private String open_ended_answer;
    private String active_social_media;
    private String therapist_visit;

    UserLifestyle()
    {
        this.physical_activity="null";
        this.physical_activity_regular="null";
        this.physical_activity_type="null";
        this.hobbies="null";
        this.sleep_hours="null";
        this.healthy_diet="null";
        this.timely_diet="null";
        this.weight_change="null";
        this.open_ended_answer="null";
        this.active_social_media="null";
        this.therapist_visit="null";
    }

    public String getPhysical_activity()
    {
        return physical_activity;
    }

    public String getHealthy_diet() {
        return healthy_diet;
    }

    public String getHobbies() {
        return hobbies;
    }

    public String getPhysical_activity_regular() {
        return physical_activity_regular;
    }

    public String getPhysical_activity_type() {
        return physical_activity_type;
    }

    public String getSleep_hours() {
        return sleep_hours;
    }

    public String getTimely_diet() {
        return timely_diet;
    }

    public String getWeight_change() {
        return weight_change;
    }

    public String getOpen_ended_answer()
    {
        return open_ended_answer;
    }

    public String getActive_social_media() {
        return active_social_media;
    }

    public String getTherapist_visit() {
        return therapist_visit;
    }

    public void setHealthy_diet(String healthy_diet) {
        this.healthy_diet = healthy_diet;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public void setPhysical_activity(String physical_activity) {
        this.physical_activity = physical_activity;
    }

    public void setPhysical_activity_regular(String physical_activity_regular) {
        this.physical_activity_regular = physical_activity_regular;
    }

    public void setPhysical_activity_type(String physical_activity_type) {
        this.physical_activity_type = physical_activity_type;
    }

    public void setSleep_hours(String sleep_hours) {
        this.sleep_hours = sleep_hours;
    }

    public void setTimely_diet(String timely_diet) {
        this.timely_diet = timely_diet;
    }

    public void setWeight_change(String weight_change) {
        this.weight_change = weight_change;
    }

    public void setOpen_ended_answer(String open_ended_answer)
    {
        this.open_ended_answer = open_ended_answer;
    }

    public void setActive_social_media(String active_social_media) {
        this.active_social_media = active_social_media;
    }

    public void setTherapist_visit(String therapist_visit) {
        this.therapist_visit = therapist_visit;
    }
}

