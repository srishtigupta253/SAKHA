package com.google.firebase.quickstart.auth.java;

import android.os.Parcel;
import android.os.Parcelable;

import org.jetbrains.annotations.NotNull;

public class Summary { //implements Parcelable {
    private String Health_Councelling_Summary = "null";
    private int summaryNo = 1;
    private String cybercrimes_detected = "null";
    private UserDass21 dassScreeningResult = new UserDass21();
    private UserInfo info = new UserInfo();
    private UserIntro intro = new UserIntro();
    private UserLifestyle lifestyle = new UserLifestyle();
    private UserRootCause root_cause_result = new UserRootCause();
    private String suspect = "null";

    // @Override
    // public int describeContents() {
    //     return 0;
    // }
    //
    // @Override
    // public void writeToParcel(Parcel out, int flags) {
    //     out.writeString(getHealth_Councelling_Summary());
    //     out.writeInt(getSummaryNo());
    //     out.writeString(getCybercrimes_detected());
    //     out.writeValue(getDassScreeningResult());
    //     out.writeValue(getInfo());
    //     out.writeValue(getIntro());
    //     out.writeValue(getLifestyle());
    //     out.writeValue(getRoot_cause_result());
    //     out.writeString(getSuspect());
    // }

    public Summary() {
        this.Health_Councelling_Summary = "null";
        this.summaryNo = 1;
        this.cybercrimes_detected = "null";
        this.dassScreeningResult = new UserDass21();
        this.info = new UserInfo();
        this.intro = new UserIntro();
        this.lifestyle = new UserLifestyle();
        this.root_cause_result = new UserRootCause();
        this.suspect = "null";
    }

    public Summary(String Health_Councelling_Summary, int summaryNo, String cybercrimes_detected, UserDass21 dassScreeningResult, UserInfo info, UserIntro intro, UserLifestyle lifestyle, UserRootCause root_cause_result, String suspect) {
        this.Health_Councelling_Summary = Health_Councelling_Summary;
        this.summaryNo = summaryNo;
        this.cybercrimes_detected = cybercrimes_detected;
        this.dassScreeningResult = dassScreeningResult;
        this.info = info;
        this.intro = intro;
        this.lifestyle = lifestyle;
        this.root_cause_result = root_cause_result;
        this.suspect = suspect;
    }

    public String getHealth_Councelling_Summary() {
        return Health_Councelling_Summary;
    }

    public void setHealth_Councelling_Summary(String health_Councelling_Summary) {
        Health_Councelling_Summary = health_Councelling_Summary;
    }

    public int getSummaryNo() {
        return summaryNo;
    }

    public void setSummaryNo(int summaryNo) {
        this.summaryNo = summaryNo;
    }

    public String getCybercrimes_detected() {
        return cybercrimes_detected;
    }

    public void setCybercrimes_detected(String cybercrimes_detected) {
        this.cybercrimes_detected = cybercrimes_detected;
    }

    public UserDass21 getDassScreeningResult() {
        return dassScreeningResult;
    }

    public void setDassScreeningResult(UserDass21 dassScreeningResult) {
        this.dassScreeningResult = dassScreeningResult;
    }

    public UserInfo getInfo() {
        return info;
    }

    public void setInfo(UserInfo info) {
        this.info = info;
    }

    public UserIntro getIntro() {
        return intro;
    }

    public void setIntro(UserIntro intro) {
        this.intro = intro;
    }

    public UserLifestyle getLifestyle() {
        return lifestyle;
    }

    public void setLifestyle(UserLifestyle lifestyle) {
        this.lifestyle = lifestyle;
    }

    public UserRootCause getRoot_cause_result() {
        return root_cause_result;
    }

    public void setRoot_cause_result(UserRootCause root_cause_result) {
        this.root_cause_result = root_cause_result;
    }

    public String getSuspect() {
        return suspect;
    }

    public void setSuspect(String suspect) {
        this.suspect = suspect;
    }

    @NotNull
    @Override
    public String toString() {
        // "varapu is 27 years old. She lives in Rural locality.Her religion is Jain. Her weight is 87 kg and height is 1.6 meters. She lives with father. She is a student. She is currently studying null. She does not do any part time job.  She does running as physical activities regularly. Her hobbies are watch television. She sleeps for 7 hours daily. She maintains a healthy diet. She eats meals in a timely manner. She has not seen weight fluctuations in recently. She is not an active user of social media. Cyber Crimes Detected: blackmailing, CYBER_STALKING MONEY_THEFT NON_CONSENSUAL_PORNOGRAPHY JOB_SCAM OFFER_AND_COUPON_SCAM REVENGE_PORN SEXTING_SCAM CYBER_BULLYING TROLLING FLAMING . She suspects someone unknown about the crime. Dass 21 results are Mild anxiety, Mild depression, null stress."
        String temp = info.getName() + " is " + intro.getAge() + " years old. ";
        temp += "She lives in " + intro.getLocality() + " locality. Her religion is " + intro.getReligion() + ". ";
        temp += "Her weight is " + intro.getWeight() + " and height is " + intro.getHeight() + ". ";
        temp += "She lives with " + intro.getMembers() + ". ";
        // She is a student. She is currently studying null. She does not do any part time job.
        // She does running as physical activities regularly.
        temp += "Her hobbies are " + lifestyle.getHobbies();
        temp += "She sleeps for " + lifestyle.getSleep_hours() + " daily. ";
        if (lifestyle.getHealthy_diet().equalsIgnoreCase("yes")) {
            temp += "She maintains a healthy diet. ";
        } else {
            temp += "She does not maintain a healthy diet. ";
        }
        if (lifestyle.getTimely_diet().equalsIgnoreCase("yes")) {
            temp += "She eats meals in a timely manner. ";
        } else {
            temp += "She does not have meals in a timely manner. ";
        }
        if (lifestyle.getWeight_change().equalsIgnoreCase("yes")) {
            temp += "She has seen weight fluctuations in recently. ";
        } else {
            temp += "She has not seen weight fluctuations in recently. ";
        }
        if (lifestyle.getActive_social_media().equalsIgnoreCase("yes")) {
            temp += "She is an active user of social media. ";
        } else {
            temp += "She is not an active user of social media. ";
        }
        temp += "Cyber Crimes Detected: " + getCybercrimes_detected() + ". ";
        temp += "She suspects " + suspect + " about the crime. ";
        temp += "Dass21 results are " + dassScreeningResult.getAnxiety_result() + " anxiety, " + dassScreeningResult.getDepression_result() + " depression, " + dassScreeningResult.getStress_result() + " stress.";

        return temp;
    }

    String getPreview() {
        String preview = "Age: "+getIntro().getAge()
                +", Address: "+getInfo().getAddress()
                +", Depression: "+dassScreeningResult.getDepression_result()
                +", Anxiety: "+dassScreeningResult.getAnxiety_result()
                +", Stress: "+dassScreeningResult.getStress_result()
                +", Cybercrimes: "+this.getCybercrimes_detected();

        return preview;
    }

}