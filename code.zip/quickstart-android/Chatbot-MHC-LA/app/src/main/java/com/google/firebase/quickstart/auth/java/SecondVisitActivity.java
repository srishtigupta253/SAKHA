package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
import static com.google.firebase.quickstart.auth.java.IntroActivity.childCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.childrenCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.husbandCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.infoMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.dass21.isFromLA;

import static java.lang.Integer.parseInt;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SecondVisitActivity extends AppCompatActivity {
    private static final String TAG = "SecondVisitActivity";
    private ListView mMessageListView;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;

    public int introVar = -1; // var for pointing question to be asked
    public int endActivity = 0; //flag
    public static String detectedCybercrime = "null";
    public static String suspect = "null";
    public static String prevEmotion = "null";
    public static UserDass21 dassmap = new UserDass21();
    public static UserIntro introMap = new UserIntro();
    public static UserInfo infoMap = new UserInfo();
    public static UserLifestyle lifeMap = new UserLifestyle();
    public static String uName = "null";

    //mood map
    Map<String, Integer> moodMap = new HashMap<String, Integer>();


    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    private DatabaseReference myRef;

    //flags
    public int ww = 0;
    public int checkprof = 0;

    // options
    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<>(Arrays.asList("Yes", "No"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_visit);

        Summary = "";
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        mMessageDatabaseReference = myRef.child("Database").child(database_no).child("Users");

        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        // Initialize message ListView and its adapter
        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        //Initialize Mood Map
        initMoodMap();

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();
//                temp=slangCheck(temp);
                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");

                introVar += 1;
                temp = slangCheck(temp);
                introFun(temp);
            }
        });

        // Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
        // startActivity(ii);
//        introStart();

        if (isFromLA) {
            introVar = 10;
            introFun("Mental Health Counselling");
        } else
            retrieveData();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void introStart() {

        newChatbotMessage("Welcome back, " + uName + "! I am glad you are back to seek my services and I will be more than happy to help you improve! ", noOptions);
        newChatbotMessage("The last time we spoke, you had mentioned that " + suspect + " was responsible for " + detectedCybercrime + " cyber crimes happening to you. I also remember that we had analyzed your mental health condition to have " + dassmap.getDepression_result() + " depression, " + dassmap.getAnxiety_result() + " anxiety and " + dassmap.getStress_result() + " stress.", noOptions);
        newChatbotMessage("What is your current mood like?"/*"\n\uD83D\uDE41️ \uD83D\uDE15 \uD83D\uDE10 \uD83D\uDE42 \uD83D\uDE00"*/, new ArrayList<>(Arrays.asList("Depressed \uD83D\uDE41", "Sad \uD83D\uDE15", "Normal \uD83D\uDE10", "Content \uD83D\uDE42", "Happy \uD83D\uDE00")));

    }

    // introductory questions
    public void introFun(String uinput) {
        Log.d("SecondVisit:", "introFun:introVar=" + introVar);
        switch (introVar) {
            case 0:
                String oldMood = introMap.getMood();
                String newMood = "depressed";
                if (uinput.toLowerCase().contains("depressed")) {
                    newMood = "depressed";
                } else if (uinput.toLowerCase().contains("sad")) {
                    newMood = "sad";
                } else if (uinput.toLowerCase().contains("normal")) {
                    newMood = "normal";
                } else if (uinput.toLowerCase().contains("content")) {
                    newMood = "content";
                } else if (uinput.toLowerCase().contains("happy")) {
                    newMood = "happy";
                }
                introMap.setMood(newMood);

                if (moodMap.get(oldMood) < moodMap.get(newMood)) {
                    newChatbotMessage("Wow! You seem to be doing better than you did the last time we spoke! Let’s see your progress!", noOptions);
                } else if (oldMood == newMood) {
                    newChatbotMessage("Seems like there isn’t much change in the way you felt last time and today! Don’t worry! I will try to make it better this time.", noOptions);
                } else {
                    newChatbotMessage("Oh! You don’t seem to be doing better than before! No problem let’s try to improve that now.", noOptions);
                }

                newChatbotMessage("So, before diving in to that, has there been any change in your life regarding exercise or sleep cycle that you would like to fill me in with?", YesNoOptions);
                break;
            case 1:
                if (funYes(uinput)) {
                    newChatbotMessage("Okay! Let's find out your improvement.", noOptions);
                    newChatbotMessage("Is there any type of physical activity that you do to keep yourself fit?", YesNoOptions);
                } else {
                    newChatbotMessage("No problem! You are doing a good job. Keep trying to work on improving those facets.", noOptions);
                    newChatbotMessage("Okay, secondly, did you try any of the suggestions I provided to improve your mental condition?\n", YesNoOptions);
                    introVar = 6;  // move to case 7
                }
                break;
            case 2:
                if (funYes(uinput)) {
                    lifeMap.setPhysical_activity("yes");
                    newChatbotMessage("Very good, could you tell what are those?", noOptions);
                } else {
                    lifeMap.setPhysical_activity("no");
                    introVar = 4; // go to case 5
                    String sleep_hours = lifeMap.getSleep_hours();
                    newChatbotMessage("Last time you said, you were sleeping over " + sleep_hours + " daily. Has that changed? How many hours are you sleeping now?", new ArrayList<>(Arrays.asList("2 to 3 hours", "4 to 6 hours", "7 to 9 hours", "more than 9 hours")));
                }
                break;
            case 3:
                lifeMap.setPhysical_activity_type(uinput);
                newChatbotMessage("How regular are you with them?", new ArrayList<>(Arrays.asList("Everyday", "Few days a week", "Once a month", "Never")));
                break;
            case 4:
                if (!funYes(uinput)) {
                    lifeMap.setPhysical_activity_regular("yes");
                }
                String sleep_hours = lifeMap.getSleep_hours();
                newChatbotMessage("Last time you said, you were sleeping over " + sleep_hours + " daily. Has that changed? How many hours are you sleeping now?", new ArrayList<>(Arrays.asList("2 to 3 hours", "4 to 6 hours", "7 to 9 hours", "more than 9 hours")));
                break;
            case 5:
                lifeMap.setSleep_hours(retInt(uinput));
                int sleep = parseInt(lifeMap.getSleep_hours()), recdSleep;
                String stageOfLife = "", recSleep = "";
                int age = parseInt(introMap.getAge());
                if (age >= 14 && age <= 17) {
                    stageOfLife = "a teenager";
                    recSleep = "8-10 hours";
                    recdSleep = 8;
                } else if (age >= 18 && age <= 25) {
                    stageOfLife = "a young adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else if (age >= 26 && age <= 64) {
                    stageOfLife = "an adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else {
                    stageOfLife = "an older adult";
                    recSleep = "7-8 hours";
                    recdSleep = 7;
                }
                if (sleep < recdSleep) {
                    newChatbotMessage("As " + stageOfLife + ", you need to have " + recSleep + " of sleep.", noOptions);
                    newChatbotMessage("I could give you a few tips on improving your sleep cycle: \n" +
                            "<b>1</b>. <b>Lighten up on Evening Meals</b> by finishing dinner several hours before bedtime and avoiding foods that cause indigestion. \n" +
                            "<b>2</b>. Drink enough fluid at night to keep from waking up thirsty—but not so much and so close to bedtime that you will be awakened by the need for a trip to the bathroom. \n" +
                            "<b>3</b>. Little known fact but staring at a clock in your bedroom, either when you are trying to fall asleep or when you wake in the middle of the night, can actually increase stress, making it harder to fall asleep. ", noOptions);
                } else {
                    newChatbotMessage("You seem to be having a good sleep cycle! Keep it up!", noOptions);
                }

                newChatbotMessage("Last time you mentioned, you spend over " + lifeMap.getActive_social_media() + " hours on social media. Now, how much time do you spend on social media daily (in hours)?", new ArrayList<>(Arrays.asList("2 to 3 hours", "4 to 6 hours", "7 to 9 hours", "more than 9 hours")));
                break;
            case 6:
                int socialMediaTime;
                if (uinput.equalsIgnoreCase("2 to 3 hours")) {
                    socialMediaTime = 2;
                } else if (uinput.equalsIgnoreCase("4 to 6 hours")) {
                    socialMediaTime = 4;
                } else if (uinput.equalsIgnoreCase("7 to 9 hours")) {
                    socialMediaTime = 7;
                } else {
                    socialMediaTime = 9;
                }
                lifeMap.setActive_social_media(String.valueOf(socialMediaTime));
                if (socialMediaTime > 3) {
                    newChatbotMessage("I have noticed that you spend more than three hours per day on social media, and you put yourself at risk of developing not only feelings of depression, anxiety, and isolation, but the time spent scrolling can have a physical effect on your body.\n" +
                            "Experts have recommended 30 minutes or less per day as the ideal amount of time you should spend on social media. ", noOptions);
                } else {
                    newChatbotMessage("Wow! You really are maintaining the ideal time one should spend on social media. Good going!", noOptions);
                }

                newChatbotMessage("Okay, secondly, did you try any of the suggestions I provided to improve your mental condition?\n", YesNoOptions);
                break;
            case 7:
                if (funYes(uinput)) {
                    newChatbotMessage(" Oh good! Maybe you could head over to Mental Health Counselling later and see your improvement", noOptions);
                } else {
                    newChatbotMessage("Please try them if you want to see better results. Head over to Mental Health Counselling later to see what can be done.\n", noOptions);
                }
                newChatbotMessage("Also, have you been to a therapist since the last time we spoke?", YesNoOptions);
                break;
            case 8:
                if (funYes(uinput)) {
                    newChatbotMessage("That's a good sign!", noOptions);
                    lifeMap.setTherapist_visit("yes");
                } else {
                    lifeMap.setTherapist_visit("no");
                    if (dassmap.getStress_result() == "Extremely Severe" || dassmap.getAnxiety_result() == "Extremely Severe" || dassmap.getDepression_result() == "Extremely Severe") {
                        newChatbotMessage("That is not a good sign! I would strongly recommend you to visit one as your condition could worsen.", noOptions);
                    } else {
                        newChatbotMessage("No worries, lets analyze your condition again to see if you need a therapist urgently or not.", noOptions);
                    }
                }
                newChatbotMessage("Moving on, you mentioned last time about " + detectedCybercrime + " cyber crimes. Has it been resolved?", YesNoOptions);
                break;
            case 9:
                mMessageAdapter.clear();

                if (funYes(uinput)) {
                    newChatbotMessage("That is a relief. Maybe you should head over to the Mental Health Counselling part to check your mental condition and if you want to discuss about any other cyber crime.\n", noOptions);
                } else {
                    newChatbotMessage("That is not good news! Please head over to LA to explore further.", noOptions);
                }
                newChatbotMessage("Where would you like to go next?", new ArrayList<>(Arrays.asList("Mental Health Counselling", "Legal Aid", "History")));

                updateSummary();
                updateToFirebase();

                break;
            case 10:
                if (uinput.equalsIgnoreCase("Mental Health Counselling")) {

                    newChatbotMessage("Let's check your improvement in terms of depression, anxiety and stress.", noOptions);

                    // go to dass21
                    dass21.isSecondVisit = true;
                    Intent i = new Intent(getApplicationContext(), dass21.class);
                    startActivity(i);

                } else if (uinput.equalsIgnoreCase("Legal Aid")) {

                    newChatbotMessage(uinput + " Welcome back " + uName + " Could you please tell me if you are here for the previous issue or a new issue?", new ArrayList<>(Arrays.asList("Previous Issue", "New Issue")));
                    introVar = 11; // go to case 12
                } else // History page
                {
                    if (!isPaidUser()) {
                        Log.v("utk", "msg list size before : " + mMessageAdapter.getCount());
                        showPaidFeatureAlert();
                        Log.v("utk", "msg list size after : " + mMessageAdapter.getCount());

                        introVar = 8; // go to case 9 again
                    } else {
                        Intent i = new Intent(getApplicationContext(), HistoryActivity.class);
                        startActivity(i);
                        introVar = 8; // go to case 9 again
                    }
                }
                break;
            case 11:
//                if (uinput.equalsIgnoreCase(getString(R.string.better))) {
//                    newChatbotMessage("Wow! You seem to be doing better than you did the last time we spoke! Let’s see your progress!\n", noOptions);
//                } else if (uinput.equalsIgnoreCase(getString(R.string.same))) {
//                    newChatbotMessage("Seems like there isn’t much change in the way you felt last time and today! Don’t worry! I will try to make it better this time.", noOptions);
//                } else {
//                    newChatbotMessage("Oh! You don’t seem to be doing better than before! No problem let’s try to improve that now", noOptions);
//                }

//                newChatbotMessage("Let's check your improvement in terms of depression, anxiety and stress.", noOptions);
//
//                // go to dass21
//                dass21.isSecondVisit = true;
//                Intent i = new Intent(getApplicationContext(), dass21.class);
//                startActivity(i);
//                finish();

                break;
            case 12:
                if (uinput.equalsIgnoreCase("Previous Issue")) {
                    newChatbotMessage("When we were discussing your previous issue, I had shown a few helpful sections and list of evidence. So have you filed a case yet?", YesNoOptions);

                } else {
                    dass21.isSecondVisit = true;
                    IntroActivity.introMap = introMap;
                    MentalHealthActivity.lifeMap = lifeMap;
                    Intent ii = new Intent(getApplicationContext(), LegalAid.class);
                    startActivity(ii);
                }
                break;
            case 13:
                if (funYes(uinput)) {
                    newChatbotMessage("Contact a higher authority or consult a lawyer personally", noOptions);
                } else {
                    newChatbotMessage("I would recommend you to file one.", noOptions);

                    dass21.isFromMHC = true;
                    IntroActivity.introMap = introMap;
                    MentalHealthActivity.lifeMap = lifeMap;
                    Intent ii = new Intent(getApplicationContext(), LegalAid.class);
                    startActivity(ii);
                }
                break;
            default:

        }

    }

    private void showPaidFeatureAlert() {

        AlertDialog premiumFeatDialog = new AlertDialog.Builder(this).create();

        premiumFeatDialog.setTitle("Purchase Licence");
        premiumFeatDialog.setMessage("Sorry, this is a premium feature. Please purchase a license to use this feature");
        premiumFeatDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Okay", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.v("utk", "alert button onclicklistener");
                mSendButton.performClick();
            }
        });

        premiumFeatDialog.show();
    }

    public void startLifeStyle() {
        updateToFirebase();
        endActivity = 1;
        Intent iii = new Intent(getApplicationContext(), LifeStyleActivity.class);
        startActivity(iii);
    }

    public void startMentalHealth() {
        updateToFirebase();
        endActivity = 1;
        Intent iii = new Intent(getApplicationContext(), MentalHealthActivity.class);
        startActivity(iii);
    }

    static void newChatbotMessage(String message, ArrayList<String> options) {
        while (options.size() < 8) {
            options.add("null");
        }

        FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
        chatbotMsg.setOpt1(options.get(0));
        chatbotMsg.setOpt2(options.get(1));
        chatbotMsg.setOpt3(options.get(2));
        chatbotMsg.setOpt4(options.get(3));
        chatbotMsg.setOpt5(options.get(4));
        chatbotMsg.setOpt6(options.get(5));
        chatbotMsg.setOpt7(options.get(6));
        chatbotMsg.setOpt8(options.get(7));

        mMessageAdapter.add(chatbotMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    // function to find digits from input string
    public String retInt(String str) {
        String[] splited = str.split("\\s+");
        for (String s : splited) {
            int n = s.length();
            if (onlyDigits(s, n)) {
                return s;
            }
        }
        return "null";
    }

    // return true if input string is digit
    public static boolean onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {
            // Check if character is a digit from 0-9
            // then return true
            // else false
            boolean flag = (str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i) == '.';
            if (!flag) return false;
        }
        return true;
    }

    void updateToFirebase() {
        updateIntroToFirebase();
        updateLifestyleToFirebase();
    }

    // updating intro of user in firebase
    void updateIntroToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        mMessageDatabaseReference.child(currentUserId).child("intro").setValue(introMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        // also save "mood" for History
        String currentDate = new SimpleDateFormat("d MMM yy", Locale.getDefault()).format(new Date());
        Log.v("utk", "current date : " + currentDate);
        mMessageDatabaseReference.child(currentUserId).child("history").child("mood").child(currentDate).setValue(introMap.getMood())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.v("utk", "mood history updated");
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // updating lifestyle of user in firebase
    void updateLifestyleToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        mMessageDatabaseReference.child(currentUserId).child("lifestyle").setValue(lifeMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "LifeStyle Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        // also save sleep hours "sleep" for History
        String currentDate = new SimpleDateFormat("d MMM yy", Locale.getDefault()).format(new Date());
        Log.v("utk", "current date : " + currentDate);
        mMessageDatabaseReference.child(currentUserId).child("history").child("sleep").child(currentDate).setValue(lifeMap.getSleep_hours())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.v("utk", "sleep history updated");
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        // also save social media hours "socialmedia" for History
        Log.v("utk", "current date : " + currentDate);
        mMessageDatabaseReference.child(currentUserId).child("history").child("socialmedia").child(currentDate).setValue(lifeMap.getActive_social_media())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.v("utk", "social media history updated");
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    private void retrieveCyberCrime() {
        String currentUserId = firebaseAuth.getUid();
        mMessageDatabaseReference.child(currentUserId).child("cybercrimes_detected").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.exists())) {
                    detectedCybercrime = dataSnapshot.getValue(String.class);
                    Toast.makeText(getApplicationContext(), "Cybercrime :" + detectedCybercrime, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Cybercrime info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    // cybercrime, suspect, Dass result, User Info, User Intro, User Lifestyle
    public void retrieveData() {
        String currentUserId = firebaseAuth.getUid();
        mMessageDatabaseReference.child(currentUserId).child("cybercrimes_detected").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.exists())) {
                    detectedCybercrime = dataSnapshot.getValue(String.class);
//                    Toast.makeText(getApplicationContext(), "Cybercrime :" + detectedCybercrime, Toast.LENGTH_SHORT).show();

                    mMessageDatabaseReference.child(currentUserId).child("suspect").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if ((dataSnapshot.exists())) {
                                suspect = dataSnapshot.getValue(String.class);
//                                Toast.makeText(getApplicationContext(), "Suspect :" + suspect, Toast.LENGTH_SHORT).show();

                                mMessageDatabaseReference.child(currentUserId).child("dassScreeningResult").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if ((dataSnapshot.exists())) {
                                            dassmap = dataSnapshot.getValue(UserDass21.class);
//                                            Toast.makeText(getApplicationContext(), "Dassmap :" +  dassmap, Toast.LENGTH_SHORT).show();

                                            mMessageDatabaseReference.child(currentUserId).child("info").addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                    if ((dataSnapshot.exists())) {
                                                        infoMap = dataSnapshot.getValue(UserInfo.class);
                                                        uName = infoMap.getName();

                                                        mMessageDatabaseReference.child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                if ((dataSnapshot.exists())) {
                                                                    introMap = dataSnapshot.getValue(UserIntro.class);

                                                                    mMessageDatabaseReference.child(currentUserId).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                        @Override
                                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                            if ((dataSnapshot.exists())) {
                                                                                lifeMap = dataSnapshot.getValue(UserLifestyle.class);

                                                                                introStart(); //***************//
                                                                            }
                                                                        }

                                                                        @Override
                                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                        }
                                                                    });

                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                                            }
                                                        });
//                                                        Toast.makeText(getApplicationContext(), "Cybercrime :" +  detectedCybercrime, Toast.LENGTH_SHORT).show();
                                                    }
                                                }

                                                @Override
                                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                                }
                                            });

                                        } else {
                                            Toast.makeText(getApplicationContext(), "Dass21 info doesn't exist", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            } else {
                                Toast.makeText(getApplicationContext(), "Suspect info doesn't exist", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                } else {
                    Toast.makeText(getApplicationContext(), "Cybercrime info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    // User Intro, User Lifestyle
    public void retrieveData2() {
        String currentUserId = firebaseAuth.getUid();
        mMessageDatabaseReference.child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.exists())) {
                    introMap = dataSnapshot.getValue(UserIntro.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mMessageDatabaseReference.child(currentUserId).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.exists())) {
                    lifeMap = dataSnapshot.getValue(UserLifestyle.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void updateSummary() {
        Summary += mUsername + " is " + retInt(introMap.getAge()) + " years old. ";
        Summary += "She lives in a " + introMap.getLocality() + " locality. ";
        Summary += "Her religion is " + introMap.getReligion() + ". ";
        Summary += " She does " + lifeMap.getPhysical_activity_type() + " as physical activities ";
        if (lifeMap.getPhysical_activity_regular() == "yes")
            Summary += "regularly";
        Summary += ". ";
        Summary += "Her hobbies are " + lifeMap.getHobbies() + ". ";
        Summary += "She uses social media for over " + lifeMap.getActive_social_media() + " hours daily. ";
        Summary += "Her weight is " + retInt(introMap.getWeight()) + " kg and height is " + retInt(introMap.getHeight()) + " meters. ";
        Summary += "She lives with " + introMap.getMembers() + ". ";
        if (funYes(introMap.getStudent())) {
            Summary += "She is a student. She is currently studying " + introMap.getStudying() + ". ";
            if (funYes(introMap.getWorking())) {
                Summary += "She is doing a part time job. ";
            } else {
                Summary += "She does not do any part time job. ";
            }
        } else {
            Summary += "She is not a student. ";
            if (funYes(introMap.getWorking())) {
                Summary += "She is a working professional. ";
                Summary += "She has been working for " + introMap.getProfession() + ". ";
                if (funYes(introMap.getWorkLifeBalance())) {
                    Summary += "She says her personal and professional life are well balanced. ";
                } else {
                    Summary += "She says her personal and professional life are not well balanced. ";
                }
            } else {
                Summary += "She is not a working professional. ";
            }
        }

        if (funYes(lifeMap.getHealthy_diet())) {
            Summary += "She is having a healthy diet. ";
        } else {
            Summary += "She is not having a healthy diet. ";
        }

        if (funYes(lifeMap.getTimely_diet())) {
            Summary += "She is having meals in a timely manner. ";
        } else {
            Summary += "She is not having meals in a timely manner. ";
        }

        if (funYes(lifeMap.getTherapist_visit())) {
            Summary += "She has visited a therapist. ";
        } else {
            Summary += "She has not visited a therapist. ";
        }

    }

    // updating family variables
    void funUpdateFamily(String uinput) {
        uinput = uinput.toLowerCase();

        String[] splited = uinput.split("\\\\s*,\\\\s*");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("husband"))
                husbandCnt = 1;
            if (splited[i].equals("child"))
                childCnt = 1;
            if (splited[i].equals("children"))
                childrenCnt = 1;
        }
    }

    public boolean isPaidUser() {
        return !database_no.equalsIgnoreCase("licfree");
    }


    // returns true if yes found else false
    public boolean funYes(String uinput) {
        uinput = uinput.toLowerCase();
        String[] splited = uinput.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("yes"))
                return true;
        }
        return false;

    }

    public void initMoodMap() {
        moodMap.put("depressed", 0);
        moodMap.put("sad", 1);
        moodMap.put("normal", 2);
        moodMap.put("content", 3);
        moodMap.put("happy", 4);
    }

    // function for checking slang words
    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }

    @Override
    public void finish() {
        mMessageAdapter.clear();
        mMessageAdapter.notifyDataSetChanged();
        super.finish();
    }
}