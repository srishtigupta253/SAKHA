package com.google.firebase.quickstart.auth.java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.quickstart.auth.R;

import org.w3c.dom.Text;

import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;

public class DisorderActivity extends AppCompatActivity {

    TextView tv=findViewById(R.id.summaryTextview);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disorder);

    }





}