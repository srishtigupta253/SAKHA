package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.LegalAid2.evidences;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.CyberLabels;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.cyberList;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.mainRootCause;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.dass21.isFromLA;
import static com.google.firebase.quickstart.auth.java.dass21.isFromMHC;
import static com.google.firebase.quickstart.auth.java.dass21.isSecondVisit;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Objects;
import java.util.Set;

public class LegalAidSuggestionsActivity extends AppCompatActivity {

    private static final String TAG = "LegalAidSuggestionsActivity";
    public static final int MY_SOCKET_TIMEOUT_MS = 30000;

    private ListView mMessageListView;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    public int introVar = 0;

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    public int wrtGui = 1;

    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<String>(Arrays.asList("Yes","No"));
    String platform = "";

    public int platSugState = 0, basicSugState = 0, rootPlatSugState = 0;
    public int cyberCrimeID = 0;

    public Hashtable<Integer,Integer> nextCrime = new Hashtable<Integer, Integer>() {{
        put(0,1);
        put(1,2);
        put(2,3);
        put(3,5);
        put(5,6);
        put(6,7);
        put(7,8);
        put(8,9);
        put(9,10);
        put(10,11);
        put(11,12);
        put(12,13);
        put(13,14);
        put(14,15);
        put(15,16);
        put(16,17);
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestions);

        //Initialise Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // TODO: Send messages on click

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages-1).setOpt1("null");
                mMessageAdapter.getItem(messages-1).setOpt2("null");
                mMessageAdapter.getItem(messages-1).setOpt3("null");
                mMessageAdapter.getItem(messages-1).setOpt4("null");
                mMessageAdapter.getItem(messages-1).setOpt5("null");
                mMessageAdapter.getItem(messages-1).setOpt6("null");
                mMessageAdapter.getItem(messages-1).setOpt7("null");
                mMessageAdapter.getItem(messages-1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                // introVar += 1;
                temp = slangCheck(temp);

                introFun(temp);

            }
        });

        showCyberLabels();
        introStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public void showCyberLabels() {
        Set<String> keys = cyberList.keySet();
        String[] array = keys.toArray(new String[0]);
        StringBuilder temp = new StringBuilder();
        for (String s : array) {
            temp.append(s).append("=").append(CyberLabels[Integer.parseInt(Objects.requireNonNull(cyberList.get(s)))]).append("\n");
        }
        Log.d("CyberLabels:", temp.toString());
    }

    public void introStart() {
        String temp = "Let me help you explore a few legal options that you could pursue. Would you like to see them?";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        friendlyMessage.setOpt1("Yes");
        friendlyMessage.setOpt2("No");
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        introVar++;
    }

    public void introFun(String uinput) {
        // String temp = "empty";
        // FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        ArrayList<String> options;

        // newDebugMessage("introFun("+uinput+"), case: "+introVar+", uinput: "+uinput);
        switch (introVar) {
            case 1:
                if (funYes(uinput)) {
                    newChatbotMessage("Firstly, do you wish to report it to the police?",YesNoOptions);
                    introVar = 2;
                } else {
                    if(isFromMHC) {
                        newChatbotMessage(getString(R.string.finalthanks),noOptions);
                        break;
                    }
                    newChatbotMessage("Would you like to go to Mental Health Counselling?",YesNoOptions);
                    introVar = 10;
                }
                break;
            case 2:
                if(funYes(uinput)) {
                    newChatbotMessage("Wow! That’s a brave step. Would you like to go and complaint personally or do it online?", new ArrayList<>(Arrays.asList("Personally","Online")));
                    introVar = 4;
                } else {
                    newChatbotMessage("You could still report to Indian Computer Emergency Response Team (CERT-IN) which is the national nodal agency for tackling the issues occurring in tow with computer security threats. \n" +
                            "Use the following channels to report: \n" +
                            "<a href=\"incident@cert-in.org.in\">E-mail</a> " +
                            "<a href=\"tel:+911800-11-4949\">Helpdesk</a> " +
                            "<a href=\"tel:+911800-11-6969\">Fax</a> " +
                            "<a href=\"https://cert-in.org.in/PDF/certinirform.pdf\">Form</a>",noOptions);
                    introVar = 9;
                    introFun("null-case2-no");

                    // // newDebugMessage("INFORMATION THEFT suggestions COMING SOON");
                    // newChatbotMessage("Analyze what's been stolen. There could be multiple thefts at the same time. \n" +
                    //         "Discover the source. As soon as you realize that you have been targeted, think about all your recent online activities which could have led to it. \n" +
                    //         "Use the following resources to report: \n" +
                    //         "<b>Equifax</b>: <a href=\"mailto:ecissupport@equifax.com\">Email</a>: , <a href=\"tel:18002093247\">Toll Free number</a>, Website: <a href=\"https://www.equifax.co.in/\">Link 1</a>, <a href=\"https://www.equifax.co.in/consumer/forms/dispute_resolution/en_in\">Link 2</a>, <a href=\"https://eport.equifax.co.in/eport/dispute.jsp\">Link 3</a>\n" +
                    //         "Experian: Phone: <a href=\"tel:+912268186760\">22 6818 6760</a>, <a href=\"tel:+912268186700\">22 6818 6700</a>, <a href=\"tel:+914046720000\">40 46720000</a>, Website: <a href=\"https://www.experian.in/\">Link 1</a>, <a href=\"https://consumer.experian.in/ECSINDIA-DCE/?isDCEFlow=true&_ga=2.189343403.1805598240.1626090120-1338790607.1626090120#!/utiERNPage\">Link 2</a>\n" +
                    //         "TransUnion CIBIL: <a href=\"tel:+912261404300\">022 - 61404300</a>022 - 61404300 (Monday to Friday ; 10:00 AM to 6:00 PM), Website: <a href=\"https://www.transunioncibil.com/\">Link 1</a>, <a href=\"https://www.cibil.com/consumer-dispute-resolution\">Link 2</a>, <a href=\"https://www.cibil.com/contact-us\">Link 3</a>\n",noOptions);
                    //
                    //
                    // // newDebugMessage("MONEY THEFT suggestions COMING SOON");
                    // newChatbotMessage("Here are 7 steps that will help you recover your money \n" +
                    //         "File a complaint with the Cyber Crime Cell to trace the IP address from which you received the scam email. \n" +
                    //         "Submit a Customer Dispute Resolution Form with the Bank from where you have transferred the money. \n" +
                    //         "Make a complaint to the Bank in which the Scammer has a bank account, where you have transferred the money. \n" +
                    //         "File a complaint before the Adjudicating Officer, Information Technology Act, 2000 against the Bank where the scammers bank account is functional, along with making the IP address a party so that the Court orders a tracing of the address. \n" +
                    //         "The court will further conduct an inquiry into your complaint and the matter will be heard and decided within a period of 6 to 9 months. \n" +
                    //         "The complaint should be filed in the format as specified in <a href=\"https://indianexpress.com/article/technology/opinion-technology/7-steps-for-recovering-money-if-you-become-victim-of-an-online-recruitment-scam/\">The Information Technology (Qualification and Experience of Adjudicating Officers and Manner of Holding Enquiry) Rules, 2003;</a> \n" +
                    //         "The Application Fees for filing a Complaint is Rs. 50 and depending on the claim amount a court fee is payable. ",noOptions);
                }
                break;
            case 3:
                if (funYes(uinput)) {
                    newDebugMessage("EVIDENCES are COMING SOON");
                    // newChatbotMessage(evidences,noOptions);
                } else {
                    newChatbotMessage("Thank you for using our app. We hope we helped you in the best way possible. You may close the app now.",noOptions);
                }
                break;
            case 4:
                if(uinput.equalsIgnoreCase("personally")) {
                    newChatbotMessage("Let me walk you through the whole process. \n" +
                            "1. The very first step to file a cyber crime complaint is to register a written complaint with the cyber crime cell of the city you are currently in. \n" +
                            "2. When filing the cyber crime complaint, you need to provide your name, contact details, and address for mailing. You need to address the written complaint to the Head of the Cyber Crime Cell of the city where you are filing the cyber crime complaint. \n" +
                            "3. A legal counsel can be approached to assist you with reporting it to the police station. Additionally, you may be asked to provide certain documents with the complaint. \n" +
                            "4. If you do not have access to any of the cyber cells in India, you can file a First Information Report (FIR) at the local police station. In case your complaint is not accepted there, you can approach the Commissioner or the city’s Judicial Magistrate. ",noOptions);
                    introVar = 7;
                    introFun("null");
                } else {
                    newChatbotMessage("There are multiple options you have online.  \n" +
                            "<b>One</b> is the official website by government for all types of cybercrimes. You could <b>report as yourself or report anonymously.</b>\n" +
                            "Would you like to see the steps as to how to do that?",YesNoOptions);
                    introVar = 5;
                }
                break;
            case 5:
                if(funYes(uinput)) {
                    newChatbotMessage("<b>Step 1</b>: Open <a href=\"https://cybercrime.gov.in\">cybercrime.gov.in</a> and on doing so, you will observe an option to “Report women/child related crime”. \n" +
                            "<b>Step 2</b>: On clicking that, you are asked to choose how you would like to report. You could “Report anonymously” or “Report” as yourself. \n" +
                            "<b>Step 3</b>: On choosing either of the options, you find the option to “File a complaint”. Once you accept the terms, you are redirected to the registration/login page from where you can easily file an online complaint. ",noOptions);
                    introVar = 8;
                    introFun("null-case5-yes");
                } else {
                    newChatbotMessage("Head over to the <a href=\"https://cybercrime.gov.in\">cybercrime.gov.in</a> site to lodge your complaint.",YesNoOptions);
                    introVar = 8;
                    introFun("null-case5-no");
                }
                break;
            case 8:
                newChatbotMessage("<b>Second</b> is to complain on National Commission for Women. \n" +
                        "Would you like to see the steps as to how to do that?",YesNoOptions);
                introVar = 6;
                break;
            case 6:
                if (funYes(uinput)) {
                    newChatbotMessage("<b>Step 1</b>: Open <a href=\"http://ncw.nic.in/\">http://ncw.nic.in/</a> on your browser. There will be a pop up that directly takes you to ‘Register a Complaint’. \n" +
                            "<b>Step 2</b>: Otherwise, on opening the site, you will see a section called ‘NCW Applications’ and under that ‘Complaints’. \n" +
                            "<b>Step 3</b>: There you see two options: ‘Online Complaint Registration’ and ‘Status of a Complaint’. On choosing to complaint, you will be redirected to <a href=\"http://ncwapps.nic.in/onlinecomplaintsv2/\">http://ncwapps.nic.in/onlinecomplaintsv2/</a> ",noOptions);
                } else {
                    newChatbotMessage("Head over to <a href=\"http://ncw.nic.in/\">the site</a> to lodge your complaint. ",noOptions);
                }
                introVar = 9;
                introFun("null");
                break;
            case 7:
                if(isFromMHC) {
                newChatbotMessage(getString(R.string.finalthanks),noOptions);
                break;
                }
                // TODO : go to MHC again functionality
//                // newChatbotMessage("Thank you for using this app. I hope I helped you in the best way possible. You may close the app now.",noOptions);
                newChatbotMessage("Would you like to go to Mental Health Counselling?",YesNoOptions);
                introVar = 10;
                break;
            case 9:
                newChatbotMessage("Other than the police, these platforms also seem to be helpful to others.",noOptions);
                newChatbotMessage("There are also certain expert helpline numbers like that of <b>The Cyber Blog India</b> who can connect you to their cybercrime specialists.\n" +
                        "<a href=\"mailto:contact@cyberblogindia.in\">Mail</a>\n" +
                        "<a href=\"tel:+919340337396\">WhatsApp Helpline</a>\n" +
                        "<a href=\"https://t.me/incyberblog\">Telegram Channel</a>\n" +
                        "In case of an offence against a woman/girl, for the sake of comfort, the victim may put forth a special request to get in touch with a female team member to assist her. \n",noOptions);
                newChatbotMessage("Other organizations include the <b><a href=\"http://www.cybervictims.org/contactus.shtml\">Centre for Cyber Victim Counseling</a></b> where they do not offer to work as detectives and are not Cyber Police. \n" +
                        "They provide free service to victims of cybercrimes by helping you to understand the nature of the crime that has happened to you, will help you to take action against the offender. \n",noOptions);
                introVar = 7;


                introFun("null");
                break;
            case 10:
                if(funYes(uinput) && !isFromMHC) {
                    isFromLA = true;
                    Intent i;
                    i = new Intent(getApplicationContext(), MentalHealthActivity.class);
                    startActivity(i);
                } else {
                    // newDebugMessage("Redirect to Basic and Platform Suggestions");
                    newChatbotMessage(getString(R.string.finalthanks),noOptions);
                }
                break;
        }
    }

    void startLegalAid() {
        isFromMHC = true;
        Intent iii = new Intent(getApplicationContext(), LegalAid.class);
        startActivity(iii);
    }

    void newChatbotMessage(String message, ArrayList<String> options) {
        if(wrtGui == 1){
            while (options.size() < 8) {
                options.add("null");
            }

            FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
            chatbotMsg.setOpt1(options.get(0));
            chatbotMsg.setOpt2(options.get(1));
            chatbotMsg.setOpt3(options.get(2));
            chatbotMsg.setOpt4(options.get(3));
            chatbotMsg.setOpt5(options.get(4));
            chatbotMsg.setOpt6(options.get(5));
            chatbotMsg.setOpt7(options.get(6));
            chatbotMsg.setOpt8(options.get(7));

            wrtGui = 1;

            mMessageAdapter.add(chatbotMsg);
            mMessageAdapter.notifyDataSetChanged();
        }
    }

    static void newDebugMessage(String message) {
        FriendlyMessage debugMsg = new FriendlyMessage(message, "debug", null);
        mMessageAdapter.add(debugMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    public boolean funYes(String temp) {
        String[] list_yes = {
                "yes",
                "yup",
                "yes i think so",
                "i think so",
                "fairly certain",
                "affirmative",
                "amen",
                "fine",
                "good",
                "okay",
                "true",
                "yea",
                "all right",
                "alright",
                "by all means",
                "aye",
                "beyond a doubt",
                "by all means",
                "certainly",
                "definitely",
                "sure",
                "exactly",
                "gladly",
                "good enough",
                "granted",
                "indubitably",
                "just so",
                "most assuredly",
                "naturally",
                "of course",
                "positively",
                "precisely",
                "sure thing",
                "surely",
                "undoubtedly",
                "unquestionably",
                "very well",
                "willingly",
                "without fail",
                "yep",
                "yeah"
        };

        String[] list_no = {
                "no",
                "no i dont think so",
                "certainly not",
                "by no means",
                "of course not",
                "not really",
                "on no account",
                "not on any account",
                "not likely",
                "hardly",
                "no way",
                "not"
        };

        temp = temp.toLowerCase();
        String temp_new = "";
        for (int i = 0; i < temp.length(); i++) {
            Character ch = temp.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == ' ') {
                temp_new += ch;
            } else {
                temp_new += " ";
            }
        }

        temp_new = temp_new.toLowerCase();
        for (String str : list_yes) {
            if (temp_new.contains(str)) {
                return true;
            }
        }

        for (String str : list_no) {
            if (temp_new.contains(str)) {
                return false;
            }
        }
        return false;
    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}