package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.List;

import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.newChatbotMessage;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.sphereInPriority;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.isLifeStyleExists;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.infoMap;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;

public class IntroActivity extends AppCompatActivity {

    private static final String TAG = "IntroActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;

    public static String Summary = "";


    private ListView mMessageListView;
    //    public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    public static EditText mMessageEditText;
    public static Button mSendButton;
    public static String mUsername = ANONYMOUS;
    public static String database_no = "null";
//    public static String detectedCybercrime = "";

    public int introVar = 0; // var for pointing question to be asked
    public static UserIntro introMap = new UserIntro(); // class object storing info to be uploded to firebase
    public int endActivity = 0; //flag

    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    //flags
    public int ww = 0;
    public int checkprof = 0;

    // family sphere variables
    public static int childCnt = 0, childrenCnt = 0, husbandCnt = 0;
    public static boolean isStudent = false, isWorking = false, askedStudent = false, askedWorking = false;

    int age;
    String student, working;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        Summary = "";
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();
//                temp=slangCheck(temp);
                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                introVar += 1;
                temp = slangCheck(temp);
                introFun(temp);

            }
        });

//        Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//        startActivity(ii);
        introStart();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent i;
        switch (id) {
            case R.id.update_info:
                verifyInfoExistence();
                break;
            case R.id.update_intro:
                verifyIntroExistence2();
                break;
        }
        return true;
    }

    private void verifyInfoExistence() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("info").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("uid").exists())) {
                    infoMap = dataSnapshot.getValue(UserInfo.class);
                    Toast.makeText(getApplicationContext(), "info exists", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), UpdateInfoActivity.class);
                    startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyIntroExistence2() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("age").exists())) {
                    introMap = dataSnapshot.getValue(UserIntro.class);
                    Toast.makeText(getApplicationContext(), "intro exists", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), UpdateIntroActivity.class);
                    startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyIntroExistence() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("age").exists())) {
                    // newDebugMessage("verifyIntroExistence: Intro exists");
                    //sentToResturentsActivity();
                    introMap = dataSnapshot.getValue(UserIntro.class);
                    // int age=introMap.getAge();
                    Toast.makeText(getApplicationContext(), "intro exists", Toast.LENGTH_SHORT).show();

                    verifyLifestyleExistence();
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "intro doesn't exist", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), IntroActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyLifestyleExistence() {
        // newDebugMessage("inside verifyLifestyleExistence()");
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("physical_activity").exists())) {
                    // newDebugMessage("verifyLifestyleExistence: Lifestyle Information exists");
                    //sentToResturentsActivity();
                    lifeMap = dataSnapshot.getValue(UserLifestyle.class);
                    // String physical_activity=lifeMap.getPhysical_activity();
                    Toast.makeText(getApplicationContext(), "lifestyle exists", Toast.LENGTH_SHORT).show();
                    isLifeStyleExists = true;
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                } else {
                    // sentToSettingActivity();
                    // newDebugMessage("verifyLifestyleExistence: Lifestyle Information doesn't exist");
                    Toast.makeText(getApplicationContext(), "lifestyle doesn't exist", Toast.LENGTH_SHORT).show();
                    isLifeStyleExists = false;
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    // greetings and first question
    public void introStart() {
        newChatbotMessage("Hi " + mUsername + ". Welcome to SAKHA! Your one stop solution to solving your mental health or legal issues pertaining to cybercrime and consulting qualified experts for the same. We are so excited to have you here. Thank you in advance for choosing our services.");
        newChatbotMessage("Let's begin with a few questions so I understand you better.");
        newChatbotMessage(mUsername + ", how old are you ? ");
    }

    // introductory questions
    public void introFun(String uinput) {
        String temp = "empty";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);

        switch (introVar) {
            case 1:
                Summary += mUsername + " is " + retInt(uinput) + " years old. ";
                introMap.setAge(retInt(uinput));
                temp = "In which type of locality do you live (urban/rural)? ";
                friendlyMessage.setOpt1("Urban");
                friendlyMessage.setOpt2("Rural");
                break;
            case 2:
                introMap.setLocality(uinput);
                Summary += "She lives in a " + uinput + " locality. ";
                temp = "What is your religion ?";
                friendlyMessage.setOpt1("Hindu");
                friendlyMessage.setOpt2("Muslim");
                friendlyMessage.setOpt3("Christian");
                friendlyMessage.setOpt4("Sikh");
                friendlyMessage.setOpt5("Jain");
                friendlyMessage.setOpt6("Buddhist");
                friendlyMessage.setOpt7("Others");
                break;
            case 3:
                introMap.setReligion(uinput);
                Summary += "Her religion is " + uinput + ". ";

                updateIntroToFirebase();
                updateLifestyleToFirebase();
                endActivity = 1;
                Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
                startActivity(i);
                // end of relation building

                // //     age = Integer.parseInt(introMap.getAge());
                // //     if (age <= 25) {
                // //         temp = "Are you still doing your studies?";
                // //         askedStudent = true;
                // //     } else {
                // //         temp = "Are you a working professional?";
                // //         askedWorking = true;
                // //     }
                // //     friendlyMessage.setOpt1("Yes");
                // //     friendlyMessage.setOpt2("No");
                // //     break;
                // // case 4:
                // //     age = Integer.parseInt(introMap.getAge());
                // //     if(age <= 25) {
                // //         introMap.setStudent(uinput);
                // //         isStudent = funYes(uinput);
                // //     } else {
                // //         introMap.setWorking(uinput);
                // //         isWorking = funYes(uinput);
                // //     }
                //     temp = "Is there any type of physical activity that you do to keep yourself fit?";
                //     friendlyMessage.setOpt1("Yes");
                //     friendlyMessage.setOpt2("No");
                //     break;
                // case 4:
                //     if (funYes(uinput)) {
                //         // some code
                //         lifeMap.setPhysical_activity("yes");
                //         temp = "Very good, could you tell what are those?";
                //     } else {
                //         lifeMap.setPhysical_activity("no");
                //         temp = "What do you like to do in your free time as your hobbies? Separate each activity by comma(,).";
                //         introVar = 6;   // go to case 7
                //     }
                //     // temp = QFun(uinput);
                //     break;
                // case 5:
                //     lifeMap.setPhysical_activity_type(uinput);
                //     Summary += " She does " + uinput + " as physical activities. ";
                //
                //     temp = "How regular are you with them?";
                //     friendlyMessage.setOpt1("Everyday");
                //     friendlyMessage.setOpt2("Few days a week");
                //     friendlyMessage.setOpt3("Once a month");
                //     friendlyMessage.setOpt4("Never");
                //     break;
                // case 6:
                //     lifeMap.setPhysical_activity_regular("yes");
                //     if (funYes(lifeMap.getPhysical_activity_regular())) Summary += " regularly. ";
                //     else Summary += ". ";
                //
                //     temp = "This is nice. What do you like to do in your free time as your hobbies? Separate each activity by comma(,)";
                //     break;
                // case 7:
                //     lifeMap.setHobbies(uinput);
                //     Summary += "Her hobbies are " + uinput + ". ";
                //
                //     temp = "How many hours do you sleep daily?";
                //     friendlyMessage.setOpt1("2 to 3 hours");
                //     friendlyMessage.setOpt2("4 to 6 hours");
                //     friendlyMessage.setOpt3("7 to 9 hours");
                //     friendlyMessage.setOpt4("more than 9 hours");
                //     break;
                // case 8:
                //     lifeMap.setSleep_hours(retInt(uinput));
                //     int sleep = parseInt(lifeMap.getSleep_hours()), recdSleep;
                //     String stageOfLife = "", recSleep = "";
                //     int age = parseInt(introMap.getAge());
                //     if(age >= 14 && age <= 17) {
                //         stageOfLife = "a teenager";
                //         recSleep = "8-10 hours";
                //         recdSleep = 8;
                //     } else if (age >= 18 && age <= 25) {
                //         stageOfLife = "a young adult";
                //         recSleep = "7-9 hours";
                //         recdSleep = 7;
                //     } else if (age >= 26 && age <= 64) {
                //         stageOfLife = "an adult";
                //         recSleep = "7-9 hours";
                //         recdSleep = 7;
                //     } else {
                //         stageOfLife = "an older adult";
                //         recSleep = "7-8 hours";
                //         recdSleep = 7;
                //     }
                //     if (sleep < recdSleep) {
                //         newChatbotMessage("You are " + stageOfLife + ". You need to have " + recSleep + " of sleep.");
                //         newChatbotMessage("I could give you a few tips on improving your sleep cycle: \n" +
                //                 "<b>1</b>. <b>Lighten up on Evening Meals</b> by finishing dinner several hours before bedtime and avoiding foods that cause indigestion. \n" +
                //                 "<b>2</b>. Drink enough fluid at night to keep from waking up thirsty—but not so much and so close to bedtime that you will be awakened by the need for a trip to the bathroom. \n" +
                //                 "<b>3</b>. Little known fact but staring at a clock in your bedroom, either when you are trying to fall asleep or when you wake in the middle of the night, can actually increase stress, making it harder to fall asleep. ");
                //     } else {
                //         newChatbotMessage("You seem to be having a good sleep cycle! Keep it up!");
                //     }
                //
                //     temp = "Are you an active user of social media ?";
                //     friendlyMessage.setOpt1("Yes");
                //     friendlyMessage.setOpt2("No");
                //     break;
                // case 9:
                //     if (funYes(uinput)) {
                //         lifeMap.setActive_social_media("yes");
                //         Summary += "She is an active user of social media. ";
                //         temp = "How much time do you spend on social media daily (in hours)?";
                //     } else {
                //         lifeMap.setActive_social_media("no");
                //         Summary += "She is not an active user of social media. ";
                //         introVar = 10; // go to case 11
                //     }
                //     break;
                // case 10:
                //     double socialMediaTime = parseDouble(uinput);
                //     Summary += "She uses social media for " + socialMediaTime + " hours daily. ";
                //     if(socialMediaTime > 3) {
                //         newChatbotMessage("I have noticed that you spend more than three hours per day on social media, and you put yourself at risk of developing not only feelings of depression, anxiety, and isolation, but the time spent scrolling can have a physical effect on your body.\n" +
                //                 "Experts have recommended 30 minutes or less per day as the ideal amount of time you should spend on social media. ");
                //     } else {
                //         newChatbotMessage("Wow! You really are maintaining the ideal time one should spend on social media. Good going!");
                //     }
                //     break;
                // case 11:
                //     temp = "There are still a few more things I would like to know. Do you wish to give me more details or move ahead for now?";
                //     friendlyMessage.setOpt1("More Details");
                //     friendlyMessage.setOpt2("Move Ahead");
                //     break;
                // case 12:
                //     updateIntroToFirebase();
                //     updateLifestyleToFirebase();
                //     if(uinput.equalsIgnoreCase("more details")) {
                //         // ask optional details
                //         endActivity=1;
                //         Intent i = new Intent(getApplicationContext(), OptionalQuestionsActivity.class);
                //         startActivity(i);
                //     } else {
                //         // choose MHC or LA
                //         endActivity=1;
                //         Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
                //         startActivity(i);
                //     }
                // default:
                //     updateIntroToFirebase();
                //     updateLifestyleToFirebase();
                //     endActivity=1;
                //     Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
                //     startActivity(i);
                //     // Intent iii=new Intent(getApplicationContext(),LifeStyleActivity.class);
                //     // startActivity(iii);
                //
                //     // default:
                //     //     if(ww==0) {
                //     //         temp=QProf2(uinput);
                //     //     }
                //     //     else {
                //     //         temp=QProf3();
                //     //     }
                //     //
                //     //     if(temp.equals("ok1")) {
                //     //         updateToFirebase();
                //     //         endActivity=1;
                //     //         Intent ii=new Intent(getApplicationContext(),LifeStyleActivity.class);
                //     //         startActivity(ii);
                //     //         //temp = "Error !!!";
                //     //     }
                //     //     else if (temp.equals("ok")) {
                //     //         temp=QProf3();
                //     //     }

        }

        if (endActivity != 1) {
            friendlyMessage.setText(temp);
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        }


    }

    public void startLifeStyle() {
        updateIntroToFirebase();
        updateLifestyleToFirebase();
        endActivity = 1;
        Intent iii = new Intent(getApplicationContext(), LifeStyleActivity.class);
        startActivity(iii);
    }


    // function to find digits from input string
    public String retInt(String str) {

        String[] splited = str.split("\\s+");
        for (int i = 0; i < splited.length; i++) {
            int n = splited[i].length();

            if (onlyDigits(splited[i], n) == true) {
                return splited[i];
            }
        }

        return "null";
    }

    // return true if input string is digit
    public static boolean onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if ((str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i) == '.') {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }


    // updating introductory info of user in firebase
    void updateIntroToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);
        mMessageDatabaseReference.child(currentUserId).child("intro").setValue(introMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    void updateLifestyleToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // mMessageDatabaseReference.child(currentUserId).child("suspect").removeEventListener(suspectListener);

        mMessageDatabaseReference.child(currentUserId).child("lifestyle").setValue(lifeMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Life style Updated", Toast.LENGTH_SHORT).show();
                            // newDebugMessage("updated to firebase");
                            // funSentiment(lifeMap.getOpen_ended_answer());
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    // updating family variables
    void funUpdateFamily(String uinput) {
        uinput = uinput.toLowerCase();

        String[] splited = uinput.split("\\\\s*,\\\\s*");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("husband"))
                husbandCnt = 1;
            if (splited[i].equals("child"))
                childCnt = 1;
            if (splited[i].equals("children"))
                childrenCnt = 1;


        }
    }

    public boolean isPaidUser() {
        return !database_no.equalsIgnoreCase("licfree");
    }

    // returns true if yes found else false
    public boolean funYes(String uinput) {
        uinput = uinput.toLowerCase();
        String[] splited = uinput.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("yes"))
                return true;
        }
        return false;

    }


    // function for checking slang words
    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }

    @Override
    public void finish() {

        mMessageAdapter.clear();
        mMessageAdapter.notifyDataSetChanged();
        super.finish();
    }
}