package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.RootCauseActivity.isSentiment;

public class WorkSphere {

    //    public int sphereDetected; // to check whether the sphere was detected or not by api
//    public String totalSentCheck; // total string that has to be sent to api for sentiment analysis
//    public String finalCause; // final cause answer for summary
//    private int someVar; // flag variable
    public int sphereDetected;
    public String totalSentCheck;
    public String finalCause;
    private int someVar;

    WorkSphere()
    {
       this.sphereDetected=0;
        this.totalSentCheck="";
        this.finalCause="null";
        this.someVar=0;
    }

    public String funWork(int i,String uinput)
    {
        String temp="null"; // return next question to be asked for this sphere
        switch(i)
        {
            case 0:
                temp=" I understand you work in an unethical work environment. Correct?";
                break;
            case 1:
                if(!funYes(uinput))
                {
                    temp="doneNotFound";

                }
                else
                temp="You are a working professional, how long have you worked there?";
                break;
            case 2:
                temp="Has any kind of behaviour from your team or boss, disturbed you?";
                break;
            case 3:
                if(uinput.equals("yes"))
                {
                  totalSentCheck=totalSentCheck+"Team member's behaviour is bad. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"Team member's behaviour is good. ";

                }
                temp="For the amount of time you have spent in your company, hopefully, you are happy with the position you are at right now ?";
                break;
            case 4:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"My position is fine. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"I am not happy with my position. ";

                }
                temp="Being a female in a male dominant society is not easy! Have you noticed any kind of inequality or discrimination, based on your gender?";
                break;
            case 5:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"I face discrimination and inequality. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"Equality";

                }
                temp="There must be many people around you of the opposite sex. Have you encountered any indecent proposals?";
                break;
            case 6:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"I encountered indecent proposal. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"Everyone behaved well. ";

                }
                temp="checksentiment";
                break;
            case 7:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default Work";



        }

        return temp;
    }
// return final question for the sphere
    public String finalQues()
    {
        return "It doesn’t seem like your work environment is something you are enjoying at the time. Do you want to share any specific incident that had led you to feel that?";
    }
// retrun 1 if yes else 0
    public boolean funYes(String uinput)
    {
        uinput=uinput.toLowerCase();
        String[] splited= uinput.split(" ");
        for(int i=0;i<splited.length;i++)
        {
            if(splited[i].equals("yes"))
                return true;
        }
        return false;

    }

}
