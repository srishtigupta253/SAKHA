package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.ktx.Firebase;
import com.google.firebase.quickstart.auth.R;

import static com.google.firebase.quickstart.auth.java.ChooserActivity.up;

public class MainActivity extends AppCompatActivity {

    //public static int up=0;
    private static FirebaseAuth mAuth;
   // private static FirebaseUser user;

    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // TextView tv=findViewById(R.id.check);

        mAuth= FirebaseAuth.getInstance();



       // tv.setText( mAuth.getUid());

        database = FirebaseDatabase.getInstance();
       myRef = database.getReference().child("Users");

       // myRef.setValue("Hello, World!");

    verifyUserExistence();

    }

    private void verifyUserExistence()
    {
        String currentUserId = mAuth.getUid();
        //UserUniqueId=currentUserId;
       myRef.child(currentUserId).child("info").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if((dataSnapshot.child("name").exists()))
                {
                    //sentToResturentsActivity();
                    Toast.makeText(MainActivity.this,"Welcome" , Toast.LENGTH_SHORT).show();
                    Intent i =new Intent(MainActivity.this,IntroActivity.class);
                    startActivity(i);
                }
                else
                {
                    // sentToSettingActivity();
                    Intent i =new Intent(MainActivity.this,UserInfoActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}