package com.google.firebase.quickstart.auth.java;

public class UserDass21 {
    private String depression_result="null";
    private String anxiety_result="null";
    private String stress_result="null";

    UserDass21()
    {}

    UserDass21(String depression_result,String anxiety_result,String stress_result)
    {
        this.anxiety_result=anxiety_result;
        this.depression_result=depression_result;
        this.stress_result=stress_result;
    }

    public void setAnxiety_result(String anxiety_result) {
        this.anxiety_result = anxiety_result;
    }

    public void setDepression_result(String depression_result) {
        this.depression_result = depression_result;
    }

    public void setStress_result(String stress_result) {
        this.stress_result = stress_result;
    }

    public String getAnxiety_result() {
        return anxiety_result;
    }

    public String getDepression_result() {
        return depression_result;
    }

    public String getStress_result() {
        return stress_result;
    }
}
