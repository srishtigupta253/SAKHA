package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.RootCauseActivity.isSentiment;

public class CyberSphere {
    public int sphereDetected; // to check whether the sphere was detected or not by api
    public String totalSentCheck; // total string that has to be sent to api for sentiment analysis
    public String finalCause; // final cause answer for summary
    private int someVar; // flag variable

    CyberSphere()
    {
        this.sphereDetected=0;
        this.totalSentCheck="";
        this.finalCause="null";
        this.someVar=0;
    }
//    i // selecting question no. to be asked
//  		uinput // user input
    public String funCyber(int i,String uinput)
    {
        String temp="null";// string i.e question to be asked next for cyber sphere.
        switch(i)
        {
            case 0:
                temp="These days, friends on social media apps are more interacted with, than your real-life friends, and most of our time is spent on scrolling through our feed, right! But your experience doesn’t sound good. Am I right?";
                break;
            case 1:
                if(!funYes(uinput))
                {
                    temp="doneNotFound";
                }
                else
                    temp="Fake Job offers, shopping vouchers and other ways of retrieving your personal information are very common these days. Have you encountered any such kind of online scams?";
                break;
            case 2:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"Victim of fake jobs. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"";

                }
                temp="Facebook and dating apps have attracted a lot of crowd, and exchange of messages and personal pictures has become a means to blackmail by familiar or unfamiliar people. Hopefully you have been able to prevent these!";
                break;
            case 3:
//                if(uinput.equals("yes"))
//                {
//                    totalSentCheck=totalSentCheck+"Blackmail by familiar or unfamiliar people. ";
//                }
//                else
//                {
//                    totalSentCheck=totalSentCheck+"Nothing. ";
//                }
                totalSentCheck+=uinput;
                temp="Suspicious links, spam emails and fake phone calls from banks have managed to obtain sensitive information from many people by disguising themselves as a trustworthy entity. Are you a part of this victimized crowd?";
                break;
            case 4:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"Suspicious links, spam emails and fake phone calls from banks have managed to obtain sensitive information from many people by disguising themselves as a trustworthy entity. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"";
                }
                temp="Expansion of digital sphere and advancement of technology has given rise to a new disease called Cyber Bullying where embarrassing posts, photos and hurtful message sharing has become common. Have you been a patient affected by this disease?";
                break;
            case 5:
                if(funYes(uinput))
                {
                    totalSentCheck=totalSentCheck+"Cyber bullying is bad. I am very sad.";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"No cyber bullying. ";
                }
                temp="checksentiment";
                break;
            case 6:
                temp="I can't even imagine what you must be going through. Have you reported this ?";
                break;
            case 7:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default Cyber";

        }

        return temp;
    }

    public String finalQues()
    {
        return "Looks like you have encountered a fraud that has hurt your trust. It might help sharing with us about it.";
    }

//    Boolean value 1 if user enters yes else zero.
    public boolean funYes(String uinput)
    {
        //uinput: user input
        uinput=uinput.toLowerCase();
        String[] splited= uinput.split(" ");
        for(int i=0;i<splited.length;i++)
        {
            if(splited[i].equals("yes"))
                return true;
        }
        return false;

    }


}
