package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
//import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.MY_SOCKET_TIMEOUT_MS;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.bertApiRes;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.cyberList;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.emotionApiRes;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.newChatbotMessage;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.CyberLabels;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.whoApiRes;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.lifeMap;

public class CyberCrimeNew extends AppCompatActivity {

    private static final String TAG = "CyberCrimeNew";

    // public static final String ANONYMOUS = "anonymous";
    //  public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mMessageListView;
    // public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    // private EditText mMessageEditText;
    // private Button mSendButton;

    //public static String mUsername=ANONYMOUS;
//    public static String sphereInPriority="null";
    public int introVar = 0;
    public int flowVar = 0;

    //public UserIntro introMap=new UserIntro();

    //    public static ArrayList <Pair <Integer,String> > orderForSphere = new ArrayList <Pair<Integer,String>> ();
//
//    public static UserLifestyle lifeMap= new UserLifestyle();
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    public int checkprof = 0;
    public int wrtGui = 1;
    public int askWhoVar = 0;
    public boolean isSuggestionsGiven = false;
    public boolean isWhoAsked = false;
    public String suspect = "null";
    public static String CyberCrimesDetected = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_style);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                //introVar+=1;
                temp = slangCheck(temp);
//                introFun(temp);
                introFun(temp);


            }
        });


        // newDebugMessage("AdapterFlagCyber = "+AdapterFlagCyber);

        // // if (AdapterFlagCyber == 0) {
        // (new Handler()).postDelayed(this::introStart, 2000);
        // // } else {
        // //     finalSuggestions();
        // // }
        // newChatbotMessage("I am sorry to hear about what has happened to you. It seems that this situation has made you feel " + emotionApiRes);
        // newChatbotMessage("I can help you get a handle on the emotions you are going through but first please help me understand the exact crime by answering a few questions.");
        showCyberLabels();
        APIresultUpdate();
        introFun("null");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }

    public void showCyberLabels() {
        Set<String> keys = cyberList.keySet();
        String[] array = keys.toArray(new String[0]);
        StringBuilder temp = new StringBuilder();
        for (String s : array) {
            temp.append(s).append("=").append(CyberLabels[Integer.parseInt(Objects.requireNonNull(cyberList.get(s)))]).append("\n");
        }
        Log.d("CyberLabels:", temp.toString());
    }

    void APIresultUpdate() {
//        FriendlyMessage friendlyMessage=new FriendlyMessage(bertApiRes,"SAKHA",null);
//        mMessageAdapter.add(friendlyMessage);
//        mMessageAdapter.notifyDataSetChanged();
        String[] splited = bertApiRes.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (cyberList.get(splited[i]) != null) {
                String ss = cyberList.get(splited[i]).toString();
                int xx = Integer.parseInt(ss);
                if (CyberLabels[xx] != 3) {
                    CyberLabels[xx] = 1;
                }

            }
        }

        // TODO: uncomment these debug messages
        // Set<String> keys = cyberList.keySet();
        // String[] array = keys.toArray(new String[keys.size()]);
        // String temp = "";
        // for(int i = 0; i < array.length; i++) {
        //     temp += array[i]+"="+CyberLabels[Integer.parseInt(cyberList.get(array[i]))]+"\n";
        // }
        // newDebugMessage("APIresultupdate:"+"\n"+temp);
    }

//    {'Cyber_Stalking': 2,
//            'Information_Theft': 2,
//            'Money_Theft': 3,
//            'NCP': 2,
//            'Online Abuse': 2,
//            'financial_scam': 3,
//            'job_scam': 2,
//            'matrimonial_scam': 2,
//            'offer_and_coupon_scam': 3,
//            'ordering_product': 3,
//            'photo_morphing': 2,
//            'revenge_porn': 2,
//            'sexting': 3,
//            'travel_scam': 3}

    public void introStart() {
        showCyberLabels();
        APIresultUpdate();
        // newChatbotMessage("I am sorry to hear about what has happened to you. It seems that this situation has made you feel " + emotionApiRes);
        // newChatbotMessage("I can help you get a handle on the emotions you are going through but first please help me understand the exact crime by answering a few questions.");
        introFun("null");
    }

    public void introFun(String uinput) {
        FriendlyMessage friendlyMessage = new FriendlyMessage(bertApiRes, "SAKHA", null);

        switch (introVar) {
            case 0:
                if (CyberLabels[introVar] == 1) {
                    // friendlyMessage.setText("I don't think your experience of social media platforms has been happy! Isn't it?");
                    friendlyMessage.setText("Online stalking is very prevalent in these times and you also seem to be a victim of it, isn’t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of CYBER STALKING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 1:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("When our personal data is misused, it is not a good feeling. It appears as if this has happened with you. Am I right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of INFORMATION THEFT.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 2:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("After analysing what you just shared, I wanted to confirm if you might have lost any money in this process. Have you?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of MONEY THEFT.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 3:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("It gives me an impression that your pictures have been misused. Is that right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of NON CONSENSUAL PORNOGRAPHY.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 4:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Someone seems to be abusing you online maybe by posting something false or cooking up fake stories about you. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of ONLINE ABUSE.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 5:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Your bank amount seems to have been robbed. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of FINANCIAL SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 6:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("You seem to have been trapped in a job con. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of JOB SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 7:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("You seem to have been trapped in a dating con. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of DATING AND MATRIMONIAL SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 8:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("You seem to have been trapped by fake offers and coupons. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of OFFER AND COUPON SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 9:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Shopping sites are being misused to harass you, right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of HARASSMENT BY ORDERING PRODUCTS.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 10:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("It looks like your pictures have been morphed and misused without your consent. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of ABUSE BY PHOTO MORPHING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 11:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Am I right to conclude that a close person has taken revenge on you?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of REVENGE PORN.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 12:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("This game of sexual texting to trap somebody is getting stronger. Looks like you have fallen for such a trap. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of SEXTING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 13:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("You seem to have been trapped in a travel con. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of HOLIDAY SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        //finalSuggestions();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 14:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("It appears to me that a bully on the cyber space won’t let go of you. Right? ");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of Cyber Bullying.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");
                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 15:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("There are multiple cases where trolls think it is okay to comment whatever they wish to. Along with celebs, seems like you are also facing this, right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of Trolling.");
                        // final_crimes_detected=final_crimes_detected+"  "+ "trolling";
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;
            case 16:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Numerous messages and personal texts are sent on a daily basis to offend and harass women. Seems like you have also received them, right? ");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of flaming.");
                        // final_crimes_detected=final_crimes_detected+"  "+ "flaming";
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        flowVar = 1;
                        introVar = introVar + 1;
                        introFun("null");

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun("null");
                }
                break;

            default:
                if (flowVar == 0) {
                    introVar = 0;
                    introFun2("null");
                } else {
                    finalSuggestions();
                }


        }


    }

    public void introFun2(String uinput) {

        FriendlyMessage friendlyMessage = new FriendlyMessage(bertApiRes, "SAKHA", null);

        switch (introVar) {
            case 0:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("Online stalking is very prevalent in these times and you also seem to be a victim of it, isn’t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of CYBER STALKING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();
                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 1:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("When our personal data is misused, it is not a good feeling. It appears as if this has happened with you. Am I right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of INFORMATION THEFT.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 2:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("After analysing what you just shared, I wanted to confirm if you might have lost any money in this process. Have you?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of MONEY THEFT.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 3:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("It gives me an impression that your pictures have been misused. Is that right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of NON CONSENSUAL PORNOGRAPHY.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 4:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("Someone seems to be abusing you online maybe by posting something false or cooking up fake stories about you. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of ONLINE ABUSE.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 5:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("Your bank amount seems to have been robbed. Isn't it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of FINANCIAL SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 6:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("You seem to have been trapped in a job con. Isn't it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of JOB SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 7:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("You seem to have been trapped in a dating con. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of DATING AND MATRIMONIAL SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 8:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("You seem to have been trapped by fake offers and coupons. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of OFFER AND COUPON SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 9:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("Shopping sites are being misused to harass you, right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of HARASSMENT BY ORDERING PRODUCTS.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 10:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("It looks like your pictures have been morphed and misused without your consent. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of ABUSE BY PHOTO MORPHING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 11:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("Am I right to conclude that a close person has taken revenge on you?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of REVENGE PORN.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 12:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("This game of sexual texting to trap somebody is getting stronger. Looks like you have fallen for such a trap. Right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of SEXTING.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 13:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("You seem to have been trapped in a travel con. Isn\\'t it?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of HOLIDAY SCAM.");
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 14:
                if (CyberLabels[introVar] == 0) {
                    friendlyMessage.setText("It appears to me that a bully on the cyber space won’t let go of you. Right? ");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of Cyber Bullying.");
                        // final_crimes_detected=final_crimes_detected+"  "+ "cyber_bullying";
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 15:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("There are multiple cases where trolls think it is okay to comment whatever they wish to. Along with celebs, seems like you are also facing this, right?");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of Trolling.");
                        // final_crimes_detected=final_crimes_detected+"  "+ "trolling";
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;
            case 16:
                if (CyberLabels[introVar] == 1) {
                    friendlyMessage.setText("Numerous messages and personal texts are sent on a daily basis to offend and harass women. Seems like you have also received them, right? ");
                    friendlyMessage.setOpt1("Yes");
                    friendlyMessage.setOpt2("No");
                    mMessageAdapter.add(friendlyMessage);
                    mMessageAdapter.notifyDataSetChanged();
                    CyberLabels[introVar] = 5;
                } else if (CyberLabels[introVar] == 5) {
                    uinput = uinput.toLowerCase();
                    if (uinput.equals("yes")) {
                        CyberLabels[introVar] = 3;
                        friendlyMessage.setText("It looks like a case of flaming.");
                        // final_crimes_detected=final_crimes_detected+"  "+ "flaming";
                        mMessageAdapter.add(friendlyMessage);
                        mMessageAdapter.notifyDataSetChanged();
                        finalSuggestions();

                    } else {
                        CyberLabels[introVar] = 2;
                        introVar = introVar + 1;
                        introFun2("null");
                    }

                } else {
                    introVar = introVar + 1;
                    introFun2("null");
                }
                break;

            default:
                finalSuggestions();


        }


    }


    public void finalSuggestions() {
        // FriendlyMessage friendlyMessage=new FriendlyMessage("Suggestions are:","SAKHA",null);
        // mMessageAdapter.add(friendlyMessage);
        // // Summary=Summary+"Cyber Crimes Detected : ";
        //
        // if(MajorCrimeFlags[0]) {
        //     faking_my_profile_suggestion();
        // }
        //
        // if(MajorCrimeFlags[1]) {
        //     blackmailing_suggestion();
        // }
        //
        // if(MajorCrimeFlags[2]) {
        //     social_media_hacked_suggestion();
        // }
        //
        // if(MajorCrimeFlags[3]) {
        //     online_harassment_suggestion();
        // }
        //
        // if(MajorCrimeFlags[4]) {
        //     sending_obscene_content_suggestion();
        // }
        //

        if (CyberLabels[0] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "CYBER_STALKING ";
            // cyber_stalking_suggestion();
        }

        if (CyberLabels[1] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "INFORMATION_THEFT ";
            // Information_theft_suggestion();
        }

        if (CyberLabels[2] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "MONEY_THEFT ";
            // Money_theft_suggestion();
        }

        if (CyberLabels[3] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "NON_CONSENSUAL_PORNOGRAPHY ";
            // Non_Consensual_pornography_simple_suggestion();
        }

        if (CyberLabels[4] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "ONLINE_ABUSE ";
            // Online_abuse_suggestion();
        }

        if (CyberLabels[5] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "FINANCIAL_SCAM ";
            // Financial_scam_suggestion();
        }

        if (CyberLabels[6] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "JOB_SCAM ";
            // Job_scam_suggestion();
        }

        if (CyberLabels[7] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "MATRIMONIAL_OR_DATING_SCAM ";
            // Matrimonial_or_Dating_scam_suggestion();
        }

        if (CyberLabels[8] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "OFFER_AND_COUPON_SCAM ";
            // Offer_and_Coupon_scam_suggestion();
        }

        if (CyberLabels[9] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "ORDERING_PRODUCT ";
            // Ordering_product_suggestion();
        }

        if (CyberLabels[10] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "PHOTO_MORPHING ";
            // Photo_morphing_suggestion();
        }

        if (CyberLabels[11] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "REVENGE_PORN ";
            // Revenge_porn_suggestion();
        }

        if (CyberLabels[12] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "SEXTING_SCAM ";
            // Sexting_suggestion();
        }

        if (CyberLabels[13] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "TRAVEL_SCAM ";
            // Holiday_scam_suggestion();
        }

        if (CyberLabels[14] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "CYBER_BULLYING ";
            // cyber_bullying_suggestion();
        }

        if (CyberLabels[15] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "TROLLING ";
            // trolling_suggestion();
        }

        if (CyberLabels[16] == 3) {
            CyberCrimesDetected = CyberCrimesDetected + "FLAMING ";
            // flaming_suggestion();
        }

        Summary = Summary + "She is a victim of " + CyberCrimesDetected + "cybercrimes. ";
        updateToFirebase();
        // mMessageAdapter.notifyDataSetChanged();


        // TODO: uncomment these debug statements
        // String[] cybercrimes = {
        //     "Cyber_Stalking",
        //     "Information_Theft",
        //     "Money_Theft",
        //     "NCP",
        //     "Online_Abuse",
        //     "financial_scam",
        //     "job_scam",
        //     "matrimonial_scam",
        //     "offer_and_coupon_scam",
        //     "ordering_product",
        //     "photo_morphing",
        //     "revenge_porn",
        //     "sexting",
        //     "travel_scam",
        //     "Cyber_Bullying",
        //     "Trolling_and_dissing",
        //     "Flaming"
        // };
        // // ArrayList<String> cybercrimes = new ArrayList<String>(cyberList.keys());
        // String temp = "";
        // for (int i = 0; i < CyberLabels.length; i++) {
        //     temp += "\t" + cybercrimes[i] + ":" + CyberLabels[i] + ",\n";
        // }
        //
        // FriendlyMessage friendlyMessageX = new FriendlyMessage(temp,"debug",null);
        // mMessageAdapter.add(friendlyMessageX);

        // FriendlyMessage friendlyMessageY = new FriendlyMessage("CyberCrimeNew->bertApiRes: "+bertApiRes, "debug", null);
        // mMessageAdapter.add(friendlyMessageY);

        // mMessageAdapter.notifyDataSetChanged();

        funWho(lifeMap.getOpen_ended_answer());
        // Intent ii=new Intent(getApplicationContext(),SuspectActivity.class);
        // startActivity(ii);

    }

    void startSuspectActivity() {
        funWho(lifeMap.getOpen_ended_answer());
        Intent ii = new Intent(getApplicationContext(), SuspectActivity.class);
        startActivity(ii);
    }

    public void funWho(String uinput) {
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        //String url = "https://vaibhavqwerty.pythonanywhere.com/";
//        String url = "https://imash.pythonanywhere.com/who";
        String url = "https://sdandapat.pythonanywhere.com/who";


        StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();

                whoApiRes = response;

                // FriendlyMessage friendlyMessage = new FriendlyMessage("funWho()->bertApiRes: "+bertApiRes, "debug", null);
                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();


                // FriendlyMessage friendlyMessage = new FriendlyMessage("whoApiRes: "+whoApiRes, "debug", null);
                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();

                // Intent ii=new Intent(getApplicationContext(),CyberCrimeNew.class);
                Intent ii = new Intent(getApplicationContext(), SuspectActivity.class);
                startActivity(ii);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                String temp = "whoapierror";
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text", uinput);
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        sr.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        queue.add(sr);
    }

    void cyber_bullying_suggestion() {
        String[] suggestions = new String[]{
                "Your first step should be to see what the anti-abuse policy of the platform is, and what steps the platform recommends for you to stop it",
                "Online Crime Reporting Portal: You can lodge a complaint by using the Ministry of Home Affairs' Online Crime Reporting Portal. You may be redirected to a specific State Government's website to register a complaint. Register a complaint in the section Services for Citizen, and click on Report a Cyber Crime. Here, you can provide information about the offender, the victim, and the incident along with any supporting evidence, such as screenshots. You can report anonymously or with identification, and you can track your complaint as well",
                "Use the Cyber Crime Reporting Portal: You can also directly file a complaint on the Cyber Crime Reporting Portal. Complaints can also be made anonymously.  You can complain against various cybercrimes by selecting the option Report Cyber Crime Related to Women/Child or Report Other Cyber Crime. You must login and create an account and select \"Report and Track\" if you wish to track your complaint"
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    void trolling_suggestion() {
        String[] suggestions = new String[]{
                "If the comment was posted on social media websites like Facebook, Twitter, or Instagram, you can report the user directly.  Reporting the user to Google is another option if they are violating Google's SEO rules. Websites that misuse Google's AdSense policy can get banned and have their ad profit taken away.",
                "If you can't remove an incriminating statement, then you can resort to making a rebuttal. Your response should be brief and concise. Avoid bickering with other users, as this will tarnish your reputation even more but you have to weigh the pros on cons of getting personally involved in the matter.",
                "If you do decide to take legal measures, be sure to keep records of all the defaming statements made towards you. Take screenshots of the posts, comments, search engine results, or other incriminating documents and print them out. You should also hold onto any evidence that indicates the user's identity."
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    void flaming_suggestion() {
        String[] suggestions = new String[]{
                "One of the strategies can be to block the abusive person from contacting you. You can block someone on your smartphone, through the telephone company, or on the social media platform.",
                "Forward calls from a specific phone number. Some telcos have a feature that lets you forward calls from a specific number to another phone number. You can forward all calls and messages from the abusive person to another number, which means that even if he dials your number, your phone doesn't ring and you don't get the harassing text messages.",
                "Screenshot, archive, and/or print the message in case future threats appear. You will want to have all abuse documented should it escalate and/or should you decide to inform law enforcement.",
                "Do not forward the email. If you need to share it, copy and paste the content instead. Forwarding the email might cause you to lose important routing data encoded in the original email—data that law enforcement may require later on."
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    static void faking_my_profile_suggestion() {
        // newDebugMessage("faking_my_profile_suggestions");

        String[] suggestions = new String[]{
                "If someone has created an account pretending to be you, you can make a report directly to that site.",
                "It is very important to ensure that you are connected via social media to only people you know, are friends with, or can at least trust. So, scan your list and remove unwanted people.",
                "Take screenshots of the imposter's account and all related activities they may engage in. This can come in handy if they block you or the bogus account is removed."
        };

        for (int i = 0; i < suggestions.length; i++) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(suggestions[i], "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    static void blackmailing_suggestion() {
        // newDebugMessage("blackmailing_suggestions");

        String[] suggestions = new String[]{
                "Report to the local police if you are a victim of cyber-blackmail. But before you reach out to police, contact a lawyer and take proper advice to track down the blackmailer. This can make your case stronger.",
                "Make sure you have all the evidence such as pictures, screenshots of conversations and so on. This will help you to get justice.",
                "In case of cyber-blackmail, the victims can also report the crime anonymously at www.cybercrime.gov.in. It is a dedicated website set up by the Ministry of Home Affairs for reporting cybercrime."
        };

        for (int i = 0; i < suggestions.length; i++) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(suggestions[i], "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    static void social_media_hacked_suggestion() {
        // newDebugMessage("social_media_hacked_suggestions");

        String[] suggestions = new String[]{
                "Change your password - if you can still log into your account, follow the usual process to reset your password. Make this a strong password that you have never used before. If the password has been changed, try to reset your password using the ‘forgot my password’ link.",
                "Turn on two-factor authentication - almost all good email accounts now give you the option to turn on two-factor authentication. Turn this on now.",
                "Change your log in details for other sites that use the same - or similar - username and password - any other online accounts with the same or similar log in details need to be changed immediately. It is highly likely that a cybercriminal will check other popular sites as soon as they get into your social media account."
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    static void online_harassment_suggestion() {
        // newDebugMessage("online_harassment_suggestions");

        String[] suggestions = new String[]{
                "All social media have a set of provisions allowing users to report complaints or problems. Harassment and stalking can be reported following those methods as well",
                "Harassment and stalking faced online should be immediately reported with the cybercrime cells in the city. In the absence of such cells an F.I.R must be made at the local police station",
                "Don’t ever delete a message, warned advocate Shah, adding that exchanges of messenger services are used as legal evidence if the case reaches court. One can confide in a colleague or even write about it on social media platforms. The victim can also send an email to herself after the incident—this will serve as a good memory aid if she decides to report the case after a period of time and can be used as evidence"
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    static void sending_obscene_content_suggestion() {
        // newDebugMessage("sending_obscene_content_suggestions");

        String[] suggestions = new String[]{
                "Delete all the photos and videos. Delete all the photos because storing such content may cause serious problems for you. As storing someone's nude and child pornography is illegal. And you can take screenshots of the chat to save it as proof.",
                "Block and report that individual. If this individual is unknown to you then block him and if he is sending you these messages through any social media or dating apps then report his or her profile.",
                "File a police complaint and take legal action. If this person continues to send you this content, then do not hesitate to file a police complaint against that individual."
        };

        for (String sug : suggestions) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(sug, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage);
        }
    }

    void Money_theft_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);
        temp = "Report the incident to the bank, immediately.";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Note down the details of all the transactions that took place at the time like the date, time, amount, merchant’s name, and others";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Lodge an FIR in the local police station because the Cyber Crime Cell might not take direct complaints. The local police will forward the case to the Cyber Crime cell'";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);


    }

    void Non_Consensual_pornography_simple_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Most internet platforms do not allow sexually explicit images to be posted. Contact the platforms where the images have been posted and report the images for violating the terms of service";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Before contacting the companies, take screen shots of all images as they appear on all platforms as evidence for your legal case";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "You can also hire a service to remove the images and monitor for any additional images. Some services offer discounts to victims and will offer free services for underage victims";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Information_theft_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "The first step to solve the problem is to find where it started. You must think about all the recent activities and investigate which could have led to it. Any new website, response to an unusual email, new software, or any registration on e-commerce site can probably cause this theft";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Victims must immediately file a complaint in the nearest police station or cybercrime cell because it qualifies as a proof of identity theft";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);


    }

    void cyber_stalking_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);


        temp = "In cases where the offender is known, you may send the stalker a clear written warning saying the contact is unwanted and asking that the perpetrator cease sending communications of any kind";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "One way is to file a complaint with the stalker’s Internet Service Provider (ISP) and yours. Many ISPs offer tools that filter or block communications from specific individuals.";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Women can contact the National Commission for Women by calling on either 1091 for women in distress and 011-26942369 or 26944754 to contact the NCW";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);
    }

    void Job_scam_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Never provide personal details such as your bank account, National Insurance number, date of birth, driving licence or utility bill information during an application process or on your CV.";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Do not conduct the whole process online. At some point a job application should lead to a telephone call or face to face interview. Be wary of hiring agents who keep solely to email";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Do some research, find out about the company that the job is with. Check landline telephone numbers to confirm the job is real. Use social media and similar sources to dig deeper into the organisation to check their reputation";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Holiday_scam_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Where possible pay for holidays and travel using either a credit card or the third-party payment service advised by the website. These can provide you additional financial protection";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Research any property before you book, look if it is advertised elsewhere or has its own website. Be extremely cautious if the prices are significantly different";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Don’t be convinced by photos, they may have been taken from somewhere else on the internet. You can check photos using a reverse image search on the internet through websites like https://www.tineye.com/ or https://reverse.photos/'";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Offer_and_Coupon_scam_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "It\\'s the only website with that great deal. If most websites offer a code for 10% off, a 75% off offer is likely a scam";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Never pay for coupons. Don\\'t be tricked into paying for something that\\'s actually free";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Watch for bait and switch tactics. This scam offers you online coupon codes and, once you agree, requires you fill in a form with personal information to steal away your identity";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Matrimonial_or_Dating_scam_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Never send money to someone you have not met in person and be extremely wary of giving money to someone you have recently met, particularly if you have only recently started a relationship with them";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Be wary of anyone asking you to receive money on their behalf and transferring it on. They may be using you to launder money";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Talk to family and friends for advice, even if the other party is asking you to keep the relationship secret.";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Financial_scam_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Keep online banking software and banking apps up to date. Always download updates when prompted";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Always log out of your online banking account or banking app when you have finished using it. Closing the app or web page or turning off your device may not be sufficient";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Do not use publicly available Wi-Fi networks for banking. It is very difficult to tell if a hotspot is secure or not, so it is always best not to use it";
        friendlyMessage.setText(temp);

    }

    void Photo_morphing_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Uploading high resolution files online to display is a very bad idea. Should someone get hold of the high-resolution file, they can pretty much do what they want with it";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Add watermarks to your photos. Adding a small section of text, or a logo, to the corner of a photo is a great way to stamp ownership onto your photos";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Compress photos you upload. Aside from the actual dimensions of the image, you can reduce the quality of the photo. Your photo will still look great, but it really limits the options of someone with bad intentions";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Revenge_porn_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "You should make a record of what has been posted online. Even if legal matters aren\\'t your first thought, it could be important later. Social media can remove pictures quickly when they are reported, but that could leave you without proof of a crime";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Places like Pornhub and XVideos respond quite positively and quickly with taking content down but it\\'s much harder dealing with sites dedicated to revenge porn because their whole aim is to show those photos and videos. You might be able to use the right to be forgotten. This lets you ask search engines like Google to remove material from their search results. The photos or videos don\\'t get deleted but this approach makes them much harder to find. You\\'ll probably need a lawyer to help";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Consider your next step. Moving forward legally could show impact on your mental health, but it\\'s important to stand up for yourself, rather than hide in shame";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Sexting_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Keep private information private. Private details which could identify you in the real world – name, age, gender, phone number, home address, school name, and photographs – should only ever be shared with people you know";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Monitor the privacy settings. It’s always best to assume that default settings are public and should be changed accordingly";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Stay safe online and in real life. Never arrange to meet someone you only know online for some time";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Online_abuse_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Your first step should be to see what the anti-abuse policy of the platform is, and what steps the platform recommends for you to stop it";
        friendlyMessage.setText(temp);
        mMessageAdapter.add(friendlyMessage);
        temp = "Use the Cyber Crime Reporting Portal: You can also directly file a complaint on the Cyber Crime Reporting Portal. Complaints can also be made anonymously.  You can complain against various cybercrimes by selecting the option Report Cyber Crime Related to Women/Child or Report Other Cyber Crime. You must login and create an account and select \"Report and Track\" if you wish to track your complaint";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "Online Crime Reporting Portal: You can lodge a complaint by using the Ministry of Home Affairs\\' Online Crime Reporting Portal. You may be redirected to a specific State Government’s website to register a complaint. Register a complaint in the section Services for Citizen, and click on Report a Cyber Crime. Here, you can provide information about the offender, the victim, and the incident along with any supporting evidence, such as screenshots. You can report anonymously or with identification, and you can track your complaint as well";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);

    }

    void Ordering_product_suggestion() {
        String temp = "";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage1 = new FriendlyMessage(temp, "SAKHA", null);
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);

        temp = "Try to reach out to the customer care numbers displayed on the website and see if they can help give you any information of why you received that order";
        friendlyMessage1.setText(temp);
        mMessageAdapter.add(friendlyMessage1);
        temp = "File an online complaint on https://www.icrpc.org/ to see if any action is taken by them";
        friendlyMessage2.setText(temp);
        mMessageAdapter.add(friendlyMessage2);
    }


    public String retInt(String str) {

        String[] splited = str.split("\\s+");
        for (int i = 0; i < splited.length; i++) {
            int n = splited[i].length();

            if (onlyDigits(splited[i], n) == true) {
                return splited[i];
            }
        }

        return "null";
    }

    public static boolean
    onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if ((str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i) == '.') {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    void updateToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);
        mMessageDatabaseReference.child(currentUserId).child("cybercrimes_detected").setValue(CyberCrimesDetected).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), "Cybercrimes Updated", Toast.LENGTH_SHORT).show();
                    // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                    //startActivity(i);
                } else {
                    String Error = task.getException().toString();
                    Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


//    public void funSentiment(String uinput) {
//
//        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
//        String url = "https://vaibhavqwerty.pythonanywhere.com/";
//
//        StringRequest sr = new StringRequest(Request.Method.POST, url , new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
////                text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
////                output.setText(response.toUpperCase());
//                Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();
//                //String str1=response.toString();
//                sphereInPriority=response;
//
////                FriendlyMessage friendlyMessage = new FriendlyMessage(sphereInPriority, "SAKHA", null);
////                mMessageAdapter.add(friendlyMessage);
////                mMessageAdapter.notifyDataSetChanged();
//                Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//                startActivity(ii);
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
//                String temp="apierror";
//                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
//            }
//        }) {
//            @Override
//            public byte[] getBody() throws AuthFailureError {
//                HashMap<String, String> params2 = new HashMap<String, String>();
//                params2.put("text",uinput );
//                return new JSONObject(params2).toString().getBytes();
//            }
//
//            @Override
//            public String getBodyContentType() {
//                return "application/json";
//            }
//        };
//
//        queue.add(sr);
//
//
//
//    }

    public boolean funYes(String uinput) {
        uinput = uinput.toLowerCase();
        String[] splited = uinput.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("yes"))
                return true;
        }
        return false;

    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}