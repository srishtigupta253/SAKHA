package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.quickstart.auth.R;

public class AdminSummaryDisplay extends AppCompatActivity {

    Button summ_switch;
    TextView case_info_title, age_holder, address_holder, depression_holder, anxiety_holder, stress_holder, cybercrimes_holder, summ_TextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_summary);

        String uid_str = getIntent().getStringExtra("uid_str");
        String age_str = getIntent().getStringExtra("age_str");
        String address_str = getIntent().getStringExtra("address_str");
        String depression_str = getIntent().getStringExtra("depression_str");
        String anxiety_str = getIntent().getStringExtra("anxiety_str");
        String stress_str = getIntent().getStringExtra("stress_str");
        String cybercrimes_str = getIntent().getStringExtra("cybercrimes_str");
        String summary_str = getIntent().getStringExtra("summary_str");

        summ_switch = findViewById(R.id.summ_switch);

        case_info_title = findViewById(R.id.case_info_title);
        case_info_title.setText("User "+uid_str);

        age_holder = findViewById(R.id.age_holder);
        age_holder.setText(age_str);

        address_holder = findViewById(R.id.address_holder);
        address_holder.setText(address_str);

        depression_holder = findViewById(R.id.depression_holder);
        depression_holder.setText(depression_str);

        anxiety_holder = findViewById(R.id.anxiety_holder);
        anxiety_holder.setText(anxiety_str);

        stress_holder = findViewById(R.id.stress_holder);
        stress_holder.setText(stress_str);

        cybercrimes_holder = findViewById(R.id.cybercrimes_holder);
        cybercrimes_holder.setText(cybercrimes_str);

        summ_TextView = findViewById(R.id.summ_TextView);
        summ_TextView.setText(summary_str);
        summ_TextView.setMovementMethod(new ScrollingMovementMethod());

        summ_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(summ_TextView.getVisibility() == View.INVISIBLE) {
                    summ_TextView.setVisibility(View.VISIBLE);
                    summ_switch.setText("Hide Summary");
                    summ_TextView.scrollTo(0,0);
                } else if(summ_TextView.getVisibility() == View.VISIBLE) {
                    summ_TextView.setVisibility(View.INVISIBLE);
                    summ_switch.setText("View Summary");
                }
            }
        });
    }

    @Override
    public void finish() {
        case_info_title.setText("");
        age_holder.setText("");
        address_holder.setText("");
        depression_holder.setText("");
        anxiety_holder.setText("");
        stress_holder.setText("");
        cybercrimes_holder.setText("");
        summ_TextView.setText("");
        super.finish();
    }
}