package com.google.firebase.quickstart.auth.java;

public class UserRootCause {
    private String sphere_detected;
    private String final_cause;

    UserRootCause()
    {
        this.final_cause="null";
        this.sphere_detected="null";
    }

    public void setFinal_cause(String final_cause) {
        this.final_cause = final_cause;
    }

    public void setSphere_detected(String sphere_detected) {
        this.sphere_detected = sphere_detected;
    }

    public String getFinal_cause() {
        return final_cause;
    }

    public String getSphere_detected() {
        return sphere_detected;
    }
}
