package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.CyberCrimesDetected;
import static com.google.firebase.quickstart.auth.java.IntroActivity.ANONYMOUS;
import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
//import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.isLifeStyleExists;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.blackmailing_suggestion;
import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.faking_my_profile_suggestion;
import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.online_harassment_suggestion;
import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.sending_obscene_content_suggestion;
import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.social_media_hacked_suggestion;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;

public class LifeStyleActivity extends AppCompatActivity {

    private static final String TAG = "LifeStyleActivity";
    public static final int MY_SOCKET_TIMEOUT_MS = 30000;

    // public static final String ANONYMOUS = "anonymous";
    //  public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mMessageListView;
    // public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    // private EditText mMessageEditText;
    // public static Button mSendButton;
    public static int AdapterFlagCyber = 0;
    public static int[] CyberLabels = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    public static boolean[] MajorCrimeFlags = {false, false, false, false, false};
    public static Hashtable<String, String> cyberList = new Hashtable();
    //public static String mUsername=ANONYMOUS;
    public static String sphereInPriority = "null";
    public int introVar = 0;
    public int physicalRegular = 0;
    public int sleepMCQ = 0;
    //public UserIntro introMap=new UserIntro();
    public static String bertApiRes = "null";
    public static String whoApiRes = "null";
    public static String emotionApiRes = "null";
    public static ArrayList<Pair<Integer, String>> orderForSphere = new ArrayList<Pair<Integer, String>>();

    public static UserLifestyle lifeMap = new UserLifestyle();
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    ValueEventListener listener, suspectListener;

    public int checkprof = 0;
    public int wrtGui = 1;

    public boolean isBtnClicked = true;
    public static String mainRootCause = "null";
    public static boolean showQuestions = true;
    public String prevSuspect = "prevSuspect";

    // public static boolean isLifeStyleExists = false;
    public static boolean isSuspectExists = false;

    // public boolean ifNextInvoked = false;

    // ArrayList<String> Questions = new ArrayList<>();
    // ArrayList<String> prevAnswers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_style);

        //Initialise Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                if (messages > 0) {
                    mMessageAdapter.getItem(messages - 1).setOpt1("null");
                    mMessageAdapter.getItem(messages - 1).setOpt2("null");
                    mMessageAdapter.getItem(messages - 1).setOpt3("null");
                    mMessageAdapter.getItem(messages - 1).setOpt4("null");
                    mMessageAdapter.getItem(messages - 1).setOpt5("null");
                    mMessageAdapter.getItem(messages - 1).setOpt6("null");
                    mMessageAdapter.getItem(messages - 1).setOpt7("null");
                    mMessageAdapter.getItem(messages - 1).setOpt8("null");
                    mMessageAdapter.notifyDataSetChanged();
                }

                // mMessageAdapter.getView(messages-1,null,);

                // Button bt1= findViewById(R.id.opt1_button);
                // Button bt2= findViewById(R.id.opt2_button);
                // Button bt3= findViewById(R.id.opt3_button);
                // Button bt4= findViewById(R.id.opt4_button);
                // Button bt5= findViewById(R.id.opt5_button);
                // Button bt6= findViewById(R.id.opt6_button);
                // Button bt7= findViewById(R.id.opt7_button);
                // Button bt8= findViewById(R.id.opt8_button);
                //
                // bt1.setEnabled(false);
                // bt2.setEnabled(false);
                // bt3.setEnabled(false);
                // bt4.setEnabled(false);
                // bt5.setEnabled(false);
                // bt6.setEnabled(false);
                // bt7.setEnabled(false);
                // bt8.setEnabled(false);


                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                introVar += 1;
                temp = slangCheck(temp);

                if(isLifeStyleExists) {
                    // newDebugMessage("ClickListener: updateFun2("+temp+"), introVar = "+introVar);
                    updateFun4(temp);
                } else {
                    introFun(temp);
                }

            }
        });
        (new Handler()).postDelayed(this::verifySuspectExistence, 1000);
        // (new Handler()).postDelayed(this::verifyLifestyleExistence, 1000);
        cyberListUpdate();


        if(showQuestions) {
            // newDebugMessage("isLifeStyleExists: "+isLifeStyleExists);
            // if (isLifeStyleExists) {
            //     updateStart4();
            // } else {
            //     introStart();
            // }
            // introStart();
            (new Handler()).postDelayed(this::introStart, 1000);
            showQuestions = false;
        }
    }

    // @Override
    // public boolean onCreateOptionsMenu(Menu menu) {
    //     MenuInflater inflater = getMenuInflater();
    //     inflater.inflate(R.menu.main_menu, menu);
    //     return true;
    // }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public void cyberListUpdate() {
        cyberList.put("Cyber_Stalking", "0");
        cyberList.put("Information_Theft", "1");
        cyberList.put("Money_Theft", "2");
        cyberList.put("NCP", "3");
        cyberList.put("Online_Abuse", "4");
        cyberList.put("financial_scam", "5");
        cyberList.put("job_scam", "6");
        cyberList.put("matrimonial_scam", "7");
        cyberList.put("offer_and_coupon_scam", "8");
        cyberList.put("ordering_product", "9");
        cyberList.put("photo_morphing", "10");
        cyberList.put("revenge_porn", "11");
        cyberList.put("sexting", "12");
        cyberList.put("travel_scam", "13");
        cyberList.put("Cyber_Bullying", "14");
        cyberList.put("Trolling_and_dissing", "15");
        cyberList.put("Flaming", "16");
    }

    private void verifySuspectExistence() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        suspectListener = mMessageDatabaseReference.child(currentUserId).child("suspect").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if((dataSnapshot.exists()))
                {
                    // newDebugMessage("verifySuspectExistence: Suspect Information exists");
                    prevSuspect = dataSnapshot.getValue(String.class);
                    // String physical_activity=lifeMap.getPhysical_activity();
                    Toast.makeText(getApplicationContext(),"suspect exists" , Toast.LENGTH_SHORT).show();

                    isSuspectExists = true;
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                }
                else
                {
                    // sentToSettingActivity();
                    // newDebugMessage("verifySuspectExistence: Suspect Information doesn't exist");
                    Toast.makeText(getApplicationContext(),"suspect doesn't exist" , Toast.LENGTH_SHORT).show();
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void introStart() {
        if(!isLifeStyleExists) {
            String temp = "Is there any type of physical activity that you do to keep yourself fit?";
            FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
            friendlyMessage.setOpt1("Yes");
            friendlyMessage.setOpt2("No");
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        } else {
            updateStart4();
        }
    }

    // public void updateStart4() {
    //     // String temp = "Hello " + mUsername + "! Welcome back.";
    //     String temp = "Hello " + mUsername + "! Welcome back.";
    //     FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
    //     mMessageAdapter.add(friendlyMessage);
    //     mMessageAdapter.notifyDataSetChanged();
    //
    //     // new Handler().postAtTime(new Runnable() {
    //     //     @Override
    //     //     public void run() {
    //     //         //add your code here
    //     //         for(int i = 0; i < 100000; i++) {
    //     //             newDebugMessage("Hello Darkness");
    //     //             System.out.println("Delay: "+i);
    //     //         }
    //     //     }
    //     // }, 5000); // Millisecond 1000 = 1 sec
    //
    //     // try {
    //     //     Thread.sleep(3000);
    //     // } catch (Exception e) {
    //     //     e.printStackTrace();
    //     // }
    //
    //     // new Timer().schedule(new TimerTask() {
    //     //     @Override
    //     //     public void run() {
    //     //         // this code will be executed after 2 seconds
    //     //         Log.d("Delay","by 1sec");
    //     //     }
    //     // }, 2000);
    //
    //     // runOnUiThread(new Runnable() {
    //     //
    //     //     @Override
    //     //     public void run() {
    //     //         final Handler handler = new Handler();
    //     //         handler.postDelayed(new Runnable() {
    //     //             @Override
    //     //             public void run() {
    //     //                 //add your code here
    //     //                 for(int i = 0; i < 100000; i++) {
    //     //                     System.out.println("Delay: "+i);
    //     //                 }
    //     //             }
    //     //         }, 10000);
    //     //
    //     //     }
    //     // });
    //
    //     // final Runnable r = new Runnable() {
    //     //     public void run() {
    //     //         gameOver();
    //     //     }
    //     //
    //     //     private void gameOver(){
    //     //         // Toast.makeText(getApplicationContext(), "Delay", Toast.LENGTH_SHORT).show();
    //     //         newDebugMessage("Delay");
    //     //     }
    //     // };
    //     //
    //     // (new Handler()).postDelayed(r, 5000);
    //
    //     // final Runnable _r_ = new Runnable(){
    //     //     @Override
    //     //     public void run() {}
    //     // };
    //     //
    //     // Handler handler = new Handler(Looper.getMainLooper());
    //     // handler.postDelayed(() -> _r_.run(), 10000);
    //
    //
    //
    //     if(funYes(lifeMap.getPhysical_activity())) {
    //         temp = "You said you have a habit of doing physical activities to maintain fitness. Are you still doing that ?";
    //     } else {
    //         temp = "Have you started doing any physical activities to keep yourself fit? Last time you said you didn't have that habit.";
    //     }
    //     friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
    //     friendlyMessage.setOpt1("Yes");
    //     friendlyMessage.setOpt2("No");
    //     mMessageAdapter.add(friendlyMessage);
    //     mMessageAdapter.notifyDataSetChanged();
    //
    //     // int DELAY = 10000; // Delay time in milliseconds
    //     //
    //     // FriendlyMessage finalFriendlyMessage = friendlyMessage;
    //     // new Handler().postDelayed(new Runnable() {
    //     //     @Override
    //     //     public void run() {
    //     //         // newDebugMessage("Hello Darkness");
    //     //         mMessageAdapter.add(finalFriendlyMessage);
    //     //         mMessageAdapter.notifyDataSetChanged();
    //     //         Log.d("Delay: ","wait for "+DELAY+"s");
    //     //     }
    //     // }, DELAY);
    //     //
    //     // new Handler().postDelayed(new Runnable() {
    //     //     @Override
    //     //     public void run() {
    //     //         FriendlyMessage friendlyMessage= new FriendlyMessage("Delay msg 2","SAKHA",null);
    //     //         mMessageAdapter.add(friendlyMessage);
    //     //         mMessageAdapter.notifyDataSetChanged();
    //     //         Log.d("Delay: ","wait for "+DELAY+"s");
    //     //     }
    //     // }, 2*DELAY);
    // }

    public void updateStart4() {
        // String temp = "Hello " + mUsername + "! Welcome back.";
        String temp = "Hello " + mUsername + "! Welcome back.";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();

        // new Handler().postAtTime(new Runnable() {
        //     @Override
        //     public void run() {
        //         //add your code here
        //         for(int i = 0; i < 100000; i++) {
        //             newDebugMessage("Hello Darkness");
        //             System.out.println("Delay: "+i);
        //         }
        //     }
        // }, 5000); // Millisecond 1000 = 1 sec

        // try {
        //     Thread.sleep(3000);
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }

        // new Timer().schedule(new TimerTask() {
        //     @Override
        //     public void run() {
        //         // this code will be executed after 2 seconds
        //         newDebugMessage("Delay by 1sec");
        //         Log.d("Delay","by 1sec");
        //     }
        // }, 2000);

        // runOnUiThread(new Runnable() {
        //
        //     @Override
        //     public void run() {
        //         final Handler handler = new Handler();
        //         handler.postDelayed(new Runnable() {
        //             @Override
        //             public void run() {
        //                 //add your code here
        //                 for(int i = 0; i < 100000; i++) {
        //                     System.out.println("Delay: "+i);
        //                 }
        //             }
        //         }, 10000);
        //
        //     }
        // });

        // final Runnable r = new Runnable() {
        //     public void run() {
        //         gameOver();
        //     }
        //
        //     private void gameOver(){
        //         // Toast.makeText(getApplicationContext(), "Delay", Toast.LENGTH_SHORT).show();
        //         newDebugMessage("Delay");
        //     }
        // };
        //
        // (new Handler()).postDelayed(r, 5000);

        // final Runnable _r_ = new Runnable(){
        //     @Override
        //     public void run() {}
        // };
        //
        // Handler handler = new Handler(Looper.getMainLooper());
        // handler.postDelayed(() -> _r_.run(), 10000);

        // int secs = 10;
        // Utils.delay(secs, new Utils.DelayCallback() {
        //     @Override
        //     public void afterDelay() {
        //         // Do something after delay
        //         newDebugMessage("Debug message");
        //     }
        // });

        // new CountDownTimer(30000, 1000) {
        //
        //     public void onTick(long millisUntilFinished) {
        //         newDebugMessage("seconds remaining: " + millisUntilFinished / 1000);
        //     }
        //
        //     public void onFinish() {
        //         newDebugMessage("done!");
        //     }
        // }.start();

        // final Handler handler = new Handler(Looper.getMainLooper());
        // handler.postDelayed(new Runnable() {
        //     @Override
        //     public void run() {
        //         //Do something after delay
        //         newDebugMessage("Delay message");
        //     }
        // }, 2000);

        // // Create a new thread inside your Activity.
        // Thread thread = new Thread() {
        //
        //     @Override
        //     public void run() {
        //
        //         // Block this thread for 2 seconds.
        //         try {
        //             Thread.sleep(2000);
        //         } catch (InterruptedException ignored) {
        //
        //         }
        //
        //         // After sleep finished blocking, create a Runnable to run on the UI Thread.
        //         runOnUiThread(new Runnable() {
        //             @Override
        //             public void run() {
        //                 newDebugMessage("delay message");
        //                 // String temp;
        //                 // if(funYes(lifeMap.getPhysical_activity())) {
        //                 //     temp = "You said you have a habit of doing physical activities to maintain fitness. Are you still doing that ?";
        //                 // } else {
        //                 //     temp = "Have you started doing any physical activities to keep yourself fit? Last time you said you didn't have that habit.";
        //                 // }
        //                 // FriendlyMessage friendlyMessage = new FriendlyMessage(temp,"SAKHA",null);
        //                 // friendlyMessage.setOpt1("Yes");
        //                 // friendlyMessage.setOpt2("No");
        //                 // mMessageAdapter.add(friendlyMessage);
        //                 // mMessageAdapter.notifyDataSetChanged();
        //             }
        //         });
        //
        //     }
        //
        // };
        //
        // // Don't forget to start the thread.
        // thread.start();


        // LifeStyleActivity.this.runOnUiThread(new Runnable() {
        //     @Override
        //     public void run() {
        //         SystemClock.sleep(2000);
        //
        //         String temp;
        //         if(funYes(lifeMap.getPhysical_activity())) {
        //             temp = "You said you have a habit of doing physical activities to maintain fitness. Are you still doing that ?";
        //         } else {
        //             temp = "Have you started doing any physical activities to keep yourself fit? Last time you said you didn't have that habit.";
        //         }
        //         FriendlyMessage friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
        //         friendlyMessage.setOpt1("Yes");
        //         friendlyMessage.setOpt2("No");
        //         mMessageAdapter.add(friendlyMessage);
        //         mMessageAdapter.notifyDataSetChanged();
        //     }
        // });

        if(funYes(lifeMap.getPhysical_activity())) {
            temp = "You said you have a habit of doing physical activities to maintain fitness. Are you still doing that ?";
        } else {
            temp = "Have you started doing any physical activities to keep yourself fit? Last time you said you didn't have that habit.";
        }
        friendlyMessage= new FriendlyMessage(temp,"SAKHA",null);
        friendlyMessage.setOpt1("Yes");
        friendlyMessage.setOpt2("No");
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
    }

    public void updateFun4(String uinput)
    {
        String temp="empty";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);

        // newDebugMessage("introFun("+uinput+"), case: "+introVar+", uinput: "+uinput);
        switch (introVar)
        {
            case 1:
                temp=QFun(uinput,friendlyMessage);
                break;
            // case 2:
            //
            //     lifeMap.setHobbies(uinput);
            //     Summary+="Her hobbies are "+uinput+". ";
            //     temp="How many hours do you sleep daily?";
            //     friendlyMessage.setOpt1("2 to 3 hours");
            //     friendlyMessage.setOpt2("4 to 6 hours");
            //     friendlyMessage.setOpt3("7 to 9 hours");
            //     friendlyMessage.setOpt4("more than 9 hours");
            //     break;
            case 3:
                lifeMap.setSleep_hours(retInt(uinput));
                int sleep = parseInt(lifeMap.getSleep_hours()), recdSleep;
                String stageOfLife = "", recSleep = "";
                int age = parseInt(introMap.getAge());
                if(age >= 14 && age <= 17) {
                    stageOfLife = "a teenager";
                    recSleep = "8-10 hours";
                    recdSleep = 8;
                } else if (age >= 18 && age <= 25) {
                    stageOfLife = "a young adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else if (age >= 26 && age <= 64) {
                    stageOfLife = "an adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else {
                    stageOfLife = "an older adult";
                    recSleep = "7-8 hours";
                    recdSleep = 7;
                }
                if (sleep < recdSleep) {
                    newChatbotMessage("You are " + stageOfLife + ". You need to have " + recSleep + " of sleep.");
                    newChatbotMessage("I could give you a few tips on improving your sleep cycle: \n" +
                            "<b>1</b>. <b>Lighten up on Evening Meals</b> by finishing dinner several hours before bedtime and avoiding foods that cause indigestion. \n" +
                            "<b>2</b>. Drink enough fluid at night to keep from waking up thirsty—but not so much and so close to bedtime that you will be awakened by the need for a trip to the bathroom. \n" +
                            "<b>3</b>. Little known fact but staring at a clock in your bedroom, either when you are trying to fall asleep or when you wake in the middle of the night, can actually increase stress, making it harder to fall asleep. ");
                } else {
                    newChatbotMessage("You seem to be having a good sleep cycle! Keep it up!");
                }
                // if (uinput.equals("7 to 9 hours")) {
                //     Summary += "She has a healthy sleep of " + uinput + " daily.";
                // } else {
                //     Summary += "She sleeps for " + uinput + " hours daily.";
                // }

                if (funYes(lifeMap.getHealthy_diet())) {
                    temp = "Are you still maintaining a healthy diet?";
                } else {
                    temp = "Are you following a healthier diet now?";
                }
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 4:
                if(funYes(uinput)) {
                    lifeMap.setHealthy_diet("yes");
                    Summary+="She maintains a healthy diet.";
                } else {
                    lifeMap.setHealthy_diet("no");
                    Summary+="She does not maintain a healthy diet. ";
                }

                if (funYes(lifeMap.getTimely_diet())) {
                    temp = "Are you still having your meals in a timely manner?";
                } else {
                    temp = "Are you having your meals in a timely manner now?";
                }
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 5:
                if(funYes(uinput)) {
                    lifeMap.setTimely_diet("yes");
                    Summary+="She eats meals in a timely manner. ";
                }
                else{
                    lifeMap.setTimely_diet("no");
                    Summary+="She does not eats in timely manner. ";
                }

                temp="Have you seen any weight fluctuations recently?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 6:
                if(funYes(uinput)) {
                    lifeMap.setWeight_change("yes");
                    Summary+="She has seen weight fluctuations recently. ";
                }
                else{
                    lifeMap.setWeight_change("no");
                    Summary+="She has not seen weight fluctuations in recently. ";

                }
                lifeMap.setWeight_change(uinput);

                updateIntroSummary();
                updateLifeStyleSummary();

                temp="You previously had an issue with \""+prevSuspect+"\". Has that been solved since our last encounter?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 7:
                if(funYes(uinput)) {
                    //temp="Now that I know a bit about you, thank you for opening up to me and letting me in! Tell me what brings you here today?";
                    temp = "Thank God, it is solved. What brings you here today then? ( You can choose any of the following or can write in the chat box )";
                    friendlyMessage.setOpt1("Faking my profile");
                    friendlyMessage.setOpt2("Blackmailing");
                    friendlyMessage.setOpt3("Social Media account hacked");
                    friendlyMessage.setOpt4("Online Harassment");
                    friendlyMessage.setOpt5("Sending Obscene Content");
                } else {
                    newDebugMessage("We will provide you further suggestions, please wait...");
                    updateToFirebase();
                }
                break;
            case 8:
                lifeMap.setOpen_ended_answer(uinput);
                directSuggest(uinput.toLowerCase());

                // newDebugMessage("introVar is "+introVar);
                // newDebugMessage("directSuggest() executed");
                // newDebugMessage("isBtnClicked: "+isBtnClicked);

                if(isBtnClicked) {
                    mainRootCause = uinput.toLowerCase();
                    temp = "If there anything else you want to share about the crime, you can type in the chat. Otherwise click the button below.";
                    friendlyMessage.setOpt1("No, nothing else to share");
                } else {
                    // newDebugMessage("Control reaches here if isBtnClicked is false");
                    wrtGui = 0;
                    startCyberCrime(uinput);
                }
                // newDebugMessage("If this message appears, control reaches here after isBtnClicked is false");
                break;
            default:
                wrtGui = 0;
                startCyberCrime(uinput);
        }

        if(wrtGui==1) {
            friendlyMessage.setText(temp);
            if(physicalRegular==1) {
                physicalRegular=0;
                friendlyMessage.setOpt1("Everyday");
                friendlyMessage.setOpt2("Few days a week");
                friendlyMessage.setOpt3("Once a month");
                friendlyMessage.setOpt4("Never");
            }
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        }
    }

    String QFun(String str, FriendlyMessage friendlyMessage) {
        if(funYes(str) || checkprof!=0)
        {
            if(checkprof==0)
            {
                lifeMap.setPhysical_activity("yes");
                checkprof=1;
                introVar=introVar-1;
                return "Very good, could you tell what are those?";
            }
            else if(checkprof==1)
            {
                // Summary+=" She does "+ str+" as physical activities. ";
                lifeMap.setPhysical_activity_type(str);
                checkprof=2;
                introVar=introVar-1;
                physicalRegular=1;
                return "How regular are you with them?";
            }
            else
            {
                lifeMap.setPhysical_activity_regular("yes");
                friendlyMessage.setOpt1("2 to 3 hours");
                friendlyMessage.setOpt2("4 to 6 hours");
                friendlyMessage.setOpt3("7 to 9 hours");
                friendlyMessage.setOpt4("more than 9 hours");
                introVar = 2;
                return "This is nice. Last time you said you sleep for over "+lifeMap.getSleep_hours()+" hours daily. Has that changed? How much time are you sleeping now?";
            }
        }
        else
        {
            lifeMap.setPhysical_activity("no");
            lifeMap.setPhysical_activity_type("null");
            lifeMap.setPhysical_activity_regular("null");
            friendlyMessage.setOpt1("2 to 3 hours");
            friendlyMessage.setOpt2("4 to 6 hours");
            friendlyMessage.setOpt3("7 to 9 hours");
            friendlyMessage.setOpt4("more than 9 hours");
            introVar = 2;
            return "Last time you said you sleep for over "+lifeMap.getSleep_hours()+" hours daily. Has that changed? How much time are you sleeping now?";
        }

    }

    public void introFun(String uinput) {
        String temp = "empty";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);

        // newDebugMessage("introFun("+uinput+"), case: "+introVar+", uinput: "+uinput);
        switch (introVar) {
            case 1:
                if (funYes(uinput)) {
                    // some code
                    lifeMap.setPhysical_activity("yes");
                    temp = "Very good, could you tell what are those?";
                    introVar = 8;
                    // go to case 9
                } else {
                    lifeMap.setPhysical_activity("no");
                    temp = "What do you like to do in your free time as your hobbies? Separate each activity by comma(,).";
                }
                // temp = QFun(uinput);
                break;
            case 2:
                lifeMap.setHobbies(uinput);
                Summary += "Her hobbies are " + uinput + ". ";

                temp = "How many hours do you sleep daily?";
                friendlyMessage.setOpt1("2 to 3 hours");
                friendlyMessage.setOpt2("4 to 6 hours");
                friendlyMessage.setOpt3("7 to 9 hours");
                friendlyMessage.setOpt4("more than 9 hours");
                break;
            case 3:
                lifeMap.setSleep_hours(retInt(uinput));
                int sleep = parseInt(lifeMap.getSleep_hours()), recdSleep;
                String stageOfLife = "", recSleep = "";
                int age = parseInt(introMap.getAge());
                if(age >= 14 && age <= 17) {
                    stageOfLife = "a teenager";
                    recSleep = "8-10 hours";
                    recdSleep = 8;
                } else if (age >= 18 && age <= 25) {
                    stageOfLife = "a young adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else if (age >= 26 && age <= 64) {
                    stageOfLife = "an adult";
                    recSleep = "7-9 hours";
                    recdSleep = 7;
                } else {
                    stageOfLife = "an older adult";
                    recSleep = "7-8 hours";
                    recdSleep = 7;
                }
                if (sleep < recdSleep) {
                    newChatbotMessage("You are " + stageOfLife + ". You need to have " + recSleep + " of sleep.");
                    newChatbotMessage("I could give you a few tips on improving your sleep cycle: \n" +
                            "<b>1</b>. <b>Lighten up on Evening Meals</b> by finishing dinner several hours before bedtime and avoiding foods that cause indigestion. \n" +
                            "<b>2</b>. Drink enough fluid at night to keep from waking up thirsty—but not so much and so close to bedtime that you will be awakened by the need for a trip to the bathroom. \n" +
                            "<b>3</b>. Little known fact but staring at a clock in your bedroom, either when you are trying to fall asleep or when you wake in the middle of the night, can actually increase stress, making it harder to fall asleep. ");
                } else {
                    newChatbotMessage("You seem to be having a good sleep cycle! Keep it up!");
                }
                // optional
                temp = "Do you try to maintain a healthy diet?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 4:
                if (funYes(uinput)) {
                    lifeMap.setHealthy_diet("yes");
                    Summary += "She maintains a healthy diet.";
                } else {
                    lifeMap.setHealthy_diet("no");
                    Summary += "She does not maintain a healthy diet. ";
                }

                // optional
                temp = "Do you eat your meals in a timely manner?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 5:
                if (funYes(uinput)) {
                    lifeMap.setTimely_diet("yes");
                    Summary += "She eats meals in a timely manner. ";
                } else {
                    lifeMap.setTimely_diet("no");
                    Summary += "She does not eats in timely manner. ";
                }

                temp = "Have you seen any weight fluctuations recently?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                break;
            case 6:
                if (funYes(uinput)) {
                    lifeMap.setWeight_change("yes");
                    Summary += "She has seen weight fluctuations recently. ";
                } else {
                    lifeMap.setWeight_change("no");
                    Summary += "She has not seen weight fluctuations in recently. ";
                }

                lifeMap.setWeight_change(uinput);
                temp = "Are you an active user of social media ?";
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
                introVar = 10; // go to case 11
                break;
            case 7:
                //temp="Now that I know a bit about you, thank you for opening up to me and letting me in! Tell me what brings you here today?";
                temp = "Tell me what brings you here today? (You can choose any of the following or can write in the chat)";
                // temp = "Now that I know a bit about you, thank you for opening up to me and letting me in! " + temp;

                // friendlyMessage.setOpt1("Information stolen or misused");
                // friendlyMessage.setOpt2("Money theft using fake job offers or any other means");
                // friendlyMessage.setOpt3("Editing the original picture to make it sexual");
                // friendlyMessage.setOpt4("Harassment by asking for sexual favours");
                // friendlyMessage.setOpt5("Revealing your personal pics and videos for revenge");
                // friendlyMessage.setOpt6("Online abuse by sharing false information");
                // friendlyMessage.setOpt7("Cyber stalking");
                // friendlyMessage.setOpt8("My account has been hacked");

                friendlyMessage.setOpt1("Faking my profile");
                friendlyMessage.setOpt2("Blackmailing");
                friendlyMessage.setOpt3("Social Media account hacked");
                friendlyMessage.setOpt4("Online Harassment");
                friendlyMessage.setOpt5("Sending Obscene Content");
                break;
            case 8:
                lifeMap.setOpen_ended_answer(uinput);
                directSuggest(uinput.toLowerCase());

                // newDebugMessage("introVar is "+introVar);
                // newDebugMessage("directSuggest() executed");
                // newDebugMessage("isBtnClicked: "+isBtnClicked);

                if (isBtnClicked) {
                    temp = "If there anything else you want to share about the crime, you can type in the chat. Otherwise click the button below.";
                    friendlyMessage.setOpt1("No, nothing else to share");
                    introVar = 12; // go to default
                } else {
                    // newDebugMessage("Control reaches here if isBtnClicked is false");
                    startCyberCrime(uinput);
                }
                // newDebugMessage("If this message appears, control reaches here after isBtnClicked is false");
                break;
            case 9:
                lifeMap.setPhysical_activity_type(uinput);
                Summary += " She does " + uinput + " as physical activities. ";

                temp = "How regular are you with them?";
                friendlyMessage.setOpt1("Everyday");
                friendlyMessage.setOpt2("Few days a week");
                friendlyMessage.setOpt3("Once a month");
                friendlyMessage.setOpt4("Never");
                break;
            case 10:
                lifeMap.setPhysical_activity_regular("yes");
                if (funYes(lifeMap.getPhysical_activity_regular())) Summary += " regularly. ";
                else Summary += ". ";

                temp = "This is nice. What do you like to do in your free time as your hobbies? Separate each activity by comma(,)";
                introVar = 1;
                break;
            case 11:
                if (funYes(uinput)) {
                    lifeMap.setActive_social_media("yes");
                    Summary += "She is an active user of social media. ";
                    temp = "How much time do you spend on social media daily (in hours)?";
                    introVar = 11; // go to case 12
                } else {
                    lifeMap.setActive_social_media("no");
                    Summary += "She is not an active user of social media. ";
                    introVar = 6; // go to case 7
                }
                break;
            case 12:
                double socialMediaTime = parseDouble(uinput);
                Summary += "She uses social media for " + socialMediaTime + " hours daily. ";
                if(socialMediaTime > 3) {
                    newChatbotMessage("I have noticed that you spend more than three hours per day on social media, and you put yourself at risk of developing not only feelings of depression, anxiety, and isolation, but the time spent scrolling can have a physical effect on your body.\n" +
                            "Experts have recommended 30 minutes or less per day as the ideal amount of time you should spend on social media. ");
                } else {
                    newChatbotMessage("Wow! You really are maintaining the ideal time one should spend on social media. Good going!");
                }
                introVar = 6; // go to case 7
            default:
                startCyberCrime(uinput);
        }

        if (wrtGui == 1) {
            friendlyMessage.setText(temp);
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();

            // if (physicalRegular == 1) {
            //     physicalRegular = 0;
            //     friendlyMessage.setOpt1("Everyday");
            //     friendlyMessage.setOpt2("Few days a week");
            //     friendlyMessage.setOpt3("Once a month");
            //     friendlyMessage.setOpt4("Never");
            // }
        }
    }

    void updateIntroSummary() {
        // newDebugMessage("updateIntroSummary begins");

        Summary = mUsername + " is " + introMap.getAge() + " years old. ";
        Summary += "She lives in " + introMap.getLocality() + " locality.";
        Summary += "Her religion is " + introMap.getReligion() + ". ";
        Summary += "Her weight is " + introMap.getWeight() + " kg and height is ";
        Summary += introMap.getHeight() + " meters. ";
        Summary += "She lives with " + introMap.getMembers() + ". ";

        int quesVar = 5;
        while (true) {
            quesVar++;
            switch (quesVar) {
                case 6:
                    int age = parseInt(introMap.getAge());
                    String student = introMap.getStudent();
                    String working = introMap.getWorking();

                    if (age <= 25 && student.equals("null")) {
                        // temp = "Are you still doing your studies?";
                        quesVar = 6;
                        // go to case 7 next
                    }
                    if (age > 25 && working.equals("null")) {
                        // temp = "Are you a working professional?";
                        quesVar = 10;
                        // go to case 11 next
                    }

                    break;
                case 7:
                    if (funYes(introMap.getStudent())) {
                        Summary += "She is a student. ";
                        // temp = "What are you currently studying?";
                        quesVar = 7;
                        // go to case 8
                    } else {
                        Summary += "She is not a student. ";
                        // temp = "Are you a working professional?";
                        quesVar = 10;
                        // go to case 11 next
                    }
                    break;
                case 8:
                    Summary += "She is currently studying " + introMap.getStudying() + ". ";
                    // temp = "Do you work as part time employee somewhere?";
                    quesVar = 8;
                    // go to case 9
                    break;
                case 9:
                    if (funYes(introMap.getWorking())) {
                        Summary += "She is doing a part time job. ";
                    } else {
                        Summary += "She does not do any part time job. ";
                    }
                    quesVar = 9;
                    // go to exit
                    // newDebugMessage("updateIntroSummary end");
                    return;
                case 10:
                    if (funYes(introMap.getStudent())) {
                        Summary += "She is enrolled in a course. ";
                    } else {
                        Summary += "She is not enrolled in any course. ";
                    }
                    // temp = "Do you work as part time employee somewhere?";
                    quesVar = 8;
                    // go to case 9
                    break;
                case 11:
                    if (funYes(introMap.getWorking())) {
                        Summary += "She is a working professional. ";
                        // temp = "How long have you worked there?";
                        quesVar = 11;
                        // go to case 12
                    } else {
                        Summary += "She is not a working professional. ";
                        // temp = "Are you enrolled in any course?";
                        quesVar = 9;
                        // go to case 10
                    }
                    break;
                case 12:
                    Summary += "She has been working for " + introMap.getProfession() + ". ";
                    // temp = "Are your personal and professional life well balanced?";
                    quesVar = 12;
                    // go to case 13
                    break;
                case 13:
                    // introMap.setNothing()
                    if (funYes(introMap.getWorkLifeBalance())) {
                        Summary += "She says her personal and professional life are well balanced. ";
                    } else {
                        Summary += "She says her personal and professional life are not well balanced. ";
                    }
                    // newDebugMessage("updateIntroSummary end");
                    return;
                default:
                    // newDebugMessage("updateIntroSummary end");
                    return;
            }
        }
    }

    void updateLifeStyleSummary() {
        if (funYes(lifeMap.getPhysical_activity())) {
            Summary += " She does " + lifeMap.getPhysical_activity_type() + " as physical activities";

            if (funYes(lifeMap.getPhysical_activity_regular())) Summary += " regularly. ";
            else Summary += ". ";
        }
        Summary += "Her hobbies are " + lifeMap.getHobbies() + ". ";

        String uinput = lifeMap.getSleep_hours();
        if (uinput.equals("7 to 9 hours")) {
            Summary += "She has a healthy sleep of " + uinput + " daily.";
        } else {
            Summary += "She sleeps for " + uinput + " hours daily. ";
        }

        if (funYes(lifeMap.getHealthy_diet())) {
            Summary += "She maintains a healthy diet. ";
        } else {
            Summary += "She does not maintain a healthy diet. ";
        }

        if (funYes(lifeMap.getTimely_diet())) {
            Summary += "She eats meals in a timely manner. ";
        } else {
            Summary += "She does not eats in timely manner. ";
        }

        if (funYes(lifeMap.getWeight_change())) {
            Summary += "She has seen weight fluctuations recently. ";
        } else {
            Summary += "She has not seen weight fluctuations in recently. ";
        }

        if (funYes(lifeMap.getActive_social_media())) {
            Summary += "She is an active user of social media. ";
        } else {
            Summary += "She is not an active user of social media. ";
        }
    }

    public void startCyberCrime(String uinput) {
        String temp = "done123";

        // newDebugMessage("Inside startCyberCrime()");

        wrtGui = 0;
        if (isBtnClicked) {
            if (!uinput.toLowerCase().contains("no")) {
                uinput = lifeMap.getOpen_ended_answer() + "," + uinput;
            }
            lifeMap.setOpen_ended_answer(uinput);
        }

        updateToFirebase();

        // if (!isLifeStyleExists) {
        //     updateToFirebase();
        // }

        //call api for sphere priority finding
        funSentiment(uinput);

        // FriendlyMessage debugMessage = new FriendlyMessage("Lifestyle_Fun->bertApiRes: "+bertApiRes, "debug", null);
        // mMessageAdapter.add(debugMessage);
        // mMessageAdapter.notifyDataSetChanged();
    }

    void directSuggest(String uinput) {
        CyberCrimesDetected = "Cyber Crimes Detected: ";

        switch (uinput) {
            case "faking my profile":
                AdapterFlagCyber = 1;
                CyberLabels[15] = 3;
                CyberLabels[14] = 3;
                CyberCrimesDetected = CyberCrimesDetected + "trolling, ";
                MajorCrimeFlags[0] = true;
                // faking_my_profile_suggestion();
                // final_crimes_detected=final_crimes_detected+"  "+ "trolling.";
                break;
            case "blackmailing":
                AdapterFlagCyber = 1;
                CyberCrimesDetected = CyberCrimesDetected + "blackmailing, ";
                MajorCrimeFlags[1] = true;
                // blackmailing_suggestion();
                // final_crimes_detected=final_crimes_detected+"  "+ "blackmailing.";
                break;
            case "social media account hacked":
                AdapterFlagCyber = 1;
                CyberCrimesDetected = CyberCrimesDetected + "social_media_account_hacked, ";
                MajorCrimeFlags[2] = true;
                // social_media_hacked_suggestion();
                // final_crimes_detected=final_crimes_detected+"  "+ "social_media_account_hacked.";
                break;
            case "online harassment":
                AdapterFlagCyber = 1;
                CyberLabels[14] = 3;
                CyberCrimesDetected = CyberCrimesDetected + "online_harassment, ";
                MajorCrimeFlags[3] = true;
                // online_harassment_suggestion();
                // final_crimes_detected=final_crimes_detected+"  "+ "cyber_bullying.";
                break;
            case "sending obscene content":
                AdapterFlagCyber = 1;
                CyberLabels[16] = 3;
                CyberCrimesDetected = CyberCrimesDetected + "sending_obscene_content, ";
                MajorCrimeFlags[4] = true;
                // sending_obscene_content_suggestion();
                // final_crimes_detected=final_crimes_detected+"  "+ "flaming.";
                break;
            default:
                isBtnClicked = false;
                introVar++;
                // newDebugMessage("IntroVar incremented");
        }
    }

    static void newDebugMessage(String message) {
        FriendlyMessage debugMsg = new FriendlyMessage(message, "debug", null);
        mMessageAdapter.add(debugMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    static void newChatbotMessage(String message) {
        FriendlyMessage friendlyMessage = new FriendlyMessage(message, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
    }

    public String retInt(String str) {
        String[] splited = str.split("\\s+");
        for (int i = 0; i < splited.length; i++) {
            int n = splited[i].length();

            if (onlyDigits(splited[i], n)) {
                return splited[i];
            }
        }

        return "null";
    }

    public static boolean onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if ( !( (str.charAt(i) >= '0' && str.charAt(i) <= '9') || str.charAt(i) == '.') ) {
                return false;
            }
        }
        return true;
    }

    void updateToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);

        // mMessageDatabaseReference.child(currentUserId).child("lifestyle").removeEventListener(listener);
        mMessageDatabaseReference.child(currentUserId).child("suspect").removeEventListener(suspectListener);

        mMessageDatabaseReference.child(currentUserId).child("lifestyle").setValue(lifeMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Life style Updated", Toast.LENGTH_SHORT).show();
                            // newDebugMessage("updated to firebase");
                            // funSentiment(lifeMap.getOpen_ended_answer());
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // String QFun(String str) {
    //     if (funYes(str) || checkprof != 0) {
    //         if (checkprof == 0) {
    //             lifeMap.setPhysical_activity("yes");
    //             checkprof = 1;
    //             introVar = introVar - 1;
    //             return "Very good, could you tell what are those?";
    //         } else if (checkprof == 1) {
    //             Summary += " She does " + str + " as physical activities. ";
    //             lifeMap.setPhysical_activity_type(str);
    //             checkprof = 2;
    //             introVar = introVar - 1;
    //             physicalRegular = 1;
    //             return "How regular are you with them?";
    //         } else {
    //             lifeMap.setPhysical_activity_regular("yes");
    //             return "This is nice. What do you like to do in your free time as your hobbies? Enter value seperated by comma(,).";
    //         }
    //     } else {
    //         lifeMap.setPhysical_activity("no");
    //         return "What do you like to do in your free time as your hobbies? Enter value seperated by comma(,).";
    //     }
    //
    // }


    public void funSentiment(String uinput) {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        //String url = "https://vaibhavqwerty.pythonanywhere.com/";
//        String url = "https://imash.pythonanywhere.com/";
        String url = "https://sdandapat.pythonanywhere.com/";


        StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
//                output.setText(response.toUpperCase());
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                //String str1=response.toString();
//                ***old model********
//                sphereInPriority=response;
//                Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//                startActivity(ii);
//                ********************

                bertApiRes = response;
                Log.d("bertApiRes:",bertApiRes);

                // newDebugMessage("bertApiRes: "+bertApiRes);
                Intent ii = new Intent(getApplicationContext(), CyberCrimeNew.class);
                startActivity(ii);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                String temp = "bertapierror" + ": " + error.getMessage();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text", uinput);
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        sr.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        queue.add(sr);


    }

    // public boolean funYes(String uinput)
    // {
    //     uinput=uinput.toLowerCase();
    //     String[] splited= uinput.split(" ");
    //     for(int i=0;i<splited.length;i++)
    //     {
    //         if(splited[i].equals("yes"))
    //             return true;
    //     }
    //     return false;
    //
    // }

    public boolean funYes(String temp) {
        String[] list_yes = {
                "yes",
                "yup",
                "yes i think so",
                "i think so",
                "fairly certain",
                "affirmative",
                "amen",
                "fine",
                "good",
                "okay",
                "true",
                "yea",
                "all right",
                "alright",
                "by all means",
                "aye",
                "beyond a doubt",
                "by all means",
                "certainly",
                "definitely",
                "sure",
                "exactly",
                "gladly",
                "good enough",
                "granted",
                "indubitably",
                "just so",
                "most assuredly",
                "naturally",
                "of course",
                "positively",
                "precisely",
                "sure thing",
                "surely",
                "undoubtedly",
                "unquestionably",
                "very well",
                "willingly",
                "without fail",
                "yep",
                "yeah"
        };

        String[] list_no = {
                "no",
                "no i dont think so",
                "certainly not",
                "by no means",
                "of course not",
                "not really",
                "on no account",
                "not on any account",
                "not likely",
                "hardly",
                "no way",
                "not"
        };

        temp = temp.toLowerCase();
        String temp_new = "";
        for (int i = 0; i < temp.length(); i++) {
            Character ch = temp.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == ' ') {
                temp_new += ch;
            } else {
                temp_new += " ";
            }
        }

        temp_new = temp_new.toLowerCase();
        for (String str : list_yes) {
            if (temp_new.contains(str)) {
                return true;
            }
        }

        for (String str : list_no) {
            if (temp_new.contains(str)) {
                return false;
            }
        }
        return false;
    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}

class Utils {

    // Delay mechanism

    public interface DelayCallback{
        void afterDelay();
    }

    public static void delay(int secs, final DelayCallback delayCallback){
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                delayCallback.afterDelay();
            }
        }, secs * 1000L); // afterDelay will be executed after (secs*1000) milliseconds.
    }
}