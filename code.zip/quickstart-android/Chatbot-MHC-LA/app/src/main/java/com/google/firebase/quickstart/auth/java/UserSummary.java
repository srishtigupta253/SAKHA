package com.google.firebase.quickstart.auth.java;

public class UserSummary {
    private String Summary;

    UserSummary()
    {
        this.Summary="null";
    }

    public void setSummary(String summary) {
        Summary = summary;
    }

    public String getSummary() {
        return Summary;
    }
}
