package com.google.firebase.quickstart.auth.java;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.quickstart.auth.R;

public class ComingSoonActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_soon);
    }
}
