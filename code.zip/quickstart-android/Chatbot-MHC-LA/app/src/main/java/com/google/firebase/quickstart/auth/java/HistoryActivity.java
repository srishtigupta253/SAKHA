package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.data.Mapping;
import com.anychart.data.Set;
import com.anychart.enums.Anchor;
import com.anychart.enums.MarkerType;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class HistoryActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    private String currentUserId;
    private AnyChartView anyChartView;
    private Cartesian cartesian;
    private TextView mapping_text;

    // date maps
    DateFormat dateFormat = new SimpleDateFormat("dd MMM yy");
    private Map<Long, String> moodDateMap = new TreeMap<Long, String>();
    private Map<Long, String> sleepDateMap = new TreeMap<Long, String>();
    private Map<Long, String> socialmediaDateMap = new TreeMap<Long, String>();

    // integer to string maps
    Map<String, Integer> moodMap = new HashMap<String, Integer>();
    Map<String, Integer> sleepMap = new HashMap<String, Integer>();
    Map<String, Integer> socialmediaMap = new HashMap<String, Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
        currentUserId = firebaseAuth.getCurrentUser().getUid();

        // Go Back Button
        Button backButton = (Button) findViewById(R.id.go_back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to get the MHC LA HISTORY menu again
                mSendButton.performClick();

                // return to previous activity
                finish();
            }
        });

        // Spinner setup
        Spinner spinner = (Spinner) findViewById(R.id.history_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.history_parameters, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        // initialize mappings
        initMoodMap();
        initSleepMap();
        initSocialmediaMap();

        // mapping text box setup
        mapping_text = (TextView) findViewById(R.id.mapping_textbox);

        // charting setup
        anyChartView = findViewById(R.id.line_chart);
        cartesian = AnyChart.line();
        cartesian.yAxis(0).title("Value");
        cartesian.xAxis(0).title("Day");

        anyChartView.setChart(cartesian);

    }


    private class CustomDataEntry extends ValueDataEntry {

        CustomDataEntry(String x, Number value, String value2, Number value3) {
            super(x, value);
            setValue("value2", value2);
            setValue("value3", value3);
        }

    }

    private void moodLineChart(Map<Long, String> dateMap) {

        // update mood history data
        if (moodDateMap.isEmpty())
            moodDateMap = dateMap;

        // setup mapping labels
        mapping_text.setText("0 : Depressed, 1 : Sad, 2 : Normal, 3 : Content, 4 : Happy");

        // add data
        List<DataEntry> seriesData = new ArrayList<>();
        for (Map.Entry<Long, String> mapElement : moodDateMap.entrySet()) {
            Log.v("utk", "mood map first entry : " + dateFormat.format(mapElement.getKey()) + " - " + mapElement.getValue());
            seriesData.add(new ValueDataEntry(dateFormat.format(mapElement.getKey()), moodMap.get(mapElement.getValue())));
        }

//        Set set = Set.instantiate();
//        set.data(seriesData);
//        Mapping seriesMapping = set.mapAs("{ x: 'x', value: 'value' }");
//
//        Line series = cartesian.line(seriesMapping);
//        series.name("Mood");

        cartesian.title("Mood");
        cartesian.data(seriesData);


    }

    private void sleepLineChart(Map<Long, String> dateMap) {
        // update sleep history data
        if (sleepDateMap.isEmpty())
            sleepDateMap = dateMap;

        // setup mapping labels
        mapping_text.setText("0 : 2 to 3 hours, 1 : 4 to 6 hours, 2 : 7 to 9 hours, 3 : 7 to 9 hours");


        // add data
        List<DataEntry> seriesData = new ArrayList<>();
        for (Map.Entry<Long, String> mapElement : sleepDateMap.entrySet()) {
            Log.v("utk", "msleep map first entry : " + dateFormat.format(mapElement.getKey()) + " - " + sleepMap.get(mapElement.getValue()));
            seriesData.add(new ValueDataEntry(dateFormat.format(mapElement.getKey()), sleepMap.get(mapElement.getValue())));
        }


        cartesian.title("Sleep Duration");
        cartesian.data(seriesData);


    }

    private void socialmediaLineChart(Map<Long, String> dateMap) {
        // update socialmedia history data
        if (socialmediaDateMap.isEmpty())
            socialmediaDateMap = dateMap;

        // setup mapping labels
        mapping_text.setText("0 : 2 to 3 hours, 1 : 4 to 6 hours, 2 : 7 to 9 hours, 3 : 7 to 9 hours");


        // add data
        List<DataEntry> seriesData = new ArrayList<>();
        for (Map.Entry<Long, String> mapElement : socialmediaDateMap.entrySet()) {
            Log.v("utk", "msocial map first entry : " + dateFormat.format(mapElement.getKey()) + " - " + socialmediaMap.get(mapElement.getValue()));
            seriesData.add(new ValueDataEntry(dateFormat.format(mapElement.getKey()), socialmediaMap.get(mapElement.getValue())));
        }


        cartesian.title("Social Media Usage");
        cartesian.data(seriesData);


    }

    private void fetchFromDB(String parameter, boolean alreadyFetched) {
        Map<Long, String> dateMap = new TreeMap<Long, String>();

        if (alreadyFetched) {
            if (parameter.equalsIgnoreCase("mood"))
                moodLineChart(dateMap);
            else if (parameter.equalsIgnoreCase("sleep"))
                sleepLineChart(dateMap);
            else if(parameter.equalsIgnoreCase("socialmedia"))
                socialmediaLineChart(dateMap);

            return;
        }

        mMessageDatabaseReference.child(currentUserId).child("history").child(parameter).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Map<String, String> tdateMap = (Map<String, String>) snapshot.getValue();

                    for (Map.Entry<String, String> mapElement : tdateMap.entrySet()) {
                        try {
                            dateMap.put(dateFormat.parse(mapElement.getKey()).getTime(), mapElement.getValue());
                        } catch (ParseException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    if (parameter.equalsIgnoreCase("mood"))
                        moodLineChart(dateMap);
                    else if (parameter.equalsIgnoreCase("sleep"))
                        sleepLineChart(dateMap);
                    else if(parameter.equalsIgnoreCase("socialmedia"))
                        socialmediaLineChart(dateMap);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        Log.d("stats", "spinner position -> " + i + " long l-> " + l);
        switch (i) {
            case (1):
                Log.d("stats", "spin 1");
                fetchFromDB("mood", !moodDateMap.isEmpty());
                break;
            case (2):
                Log.d("stats", "spin 2");
                fetchFromDB("sleep", !sleepDateMap.isEmpty());
                break;
            case (3):
                Log.d("stats", "spin 3");
                fetchFromDB("socialmedia", !socialmediaDateMap.isEmpty());
                break;
            case (4):
                Log.d("stats", "spin 4");
//                stressPieChart();
                break;
            case (5):
//                crimePieChart();
                break;
            case (6):
//                therapyPieChart();
                break;
            default:
                Log.d("stats", "spin default");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    // init
    public void initMoodMap() {
        moodMap.put("depressed", 0);
        moodMap.put("sad", 1);
        moodMap.put("normal", 2);
        moodMap.put("content", 3);
        moodMap.put("happy", 4);
    }

    public void initSleepMap() {
        sleepMap.put("2", 0);
        sleepMap.put("4", 1);
        sleepMap.put("7", 2);
        sleepMap.put("9", 3);
    }

    public void initSocialmediaMap() {
        socialmediaMap.put("2", 0);
        socialmediaMap.put("4", 1);
        socialmediaMap.put("7", 2);
        socialmediaMap.put("9", 3);
    }
}
