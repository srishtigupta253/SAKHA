package com.google.firebase.quickstart.auth.java;

public class FriendlyMessage {
    private String text; // for user entered text
    private String name; // user name
    private String photoUrl; // for photo uploaded by user

// buttons text for mcq type questions
    private String opt1;
    private String opt2;
    private String opt3;
    private String opt4;
    private String opt5;
    private String opt6;
    private String opt7;
    private String opt8;

    public FriendlyMessage() {
        this.text = "empty_message";
        this.name = "SAKHA";
        this.photoUrl = null;
        this.opt1="null";
        this.opt2="null";
        this.opt3="null";
        this.opt4="null";
        this.opt5="null";
        this.opt6="null";
        this.opt7="null";
        this.opt8="null";
    }

    public FriendlyMessage(String text, String name, String photoUrl){
        this.text = text;
        this.name = name;
        this.photoUrl = photoUrl;
        this.opt1="null";
        this.opt2="null";
        this.opt3="null";
        this.opt4="null";
        this.opt5="null";
        this.opt6="null";
        this.opt7="null";
        this.opt8="null";
    }

//    public FriendlyMessage(String text, String name, String photoUrl,String opt1,String opt2,String opt3, String opt4) {
//        this.text = text;
//        this.name = name;
//        this.photoUrl = photoUrl;
//        this.opt1=opt1;
//        this.opt2=opt2;
//        this.opt3=opt3;
//        this.opt4=opt4;
//    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getOpt1() {
        return opt1;
    }

    public String getOpt2() {
        return opt2;
    }

    public String getOpt3() {
        return opt3;
    }

    public String getOpt4() {
        return opt4;
    }

    public void setOpt1(String opt1) {
        this.opt1 = opt1;
    }

    public void setOpt2(String opt2) {
        this.opt2 = opt2;
    }

    public void setOpt3(String opt3) {
        this.opt3 = opt3;
    }

    public void setOpt4(String opt4) {
        this.opt4 = opt4;
    }

    public String getOpt5() {
        return opt5;
    }

    public void setOpt5(String opt5) {
        this.opt5 = opt5;
    }

    public void setOpt6(String opt6) {
        this.opt6 = opt6;
    }

    public void setOpt7(String opt7) {
        this.opt7 = opt7;
    }

    public void setOpt8(String opt8) {
        this.opt8 = opt8;
    }

    public String getOpt6() {
        return opt6;
    }

    public String getOpt7() {
        return opt7;
    }

    public String getOpt8() {
        return opt8;
    }
}
