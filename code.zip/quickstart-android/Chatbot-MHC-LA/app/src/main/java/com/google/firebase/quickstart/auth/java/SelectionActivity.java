package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;

import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.newDebugMessage;

public class  SelectionActivity extends AppCompatActivity {
    public static Dictionary slangList = new Hashtable();
    public static MessageAdapter mMessageAdapter;
    public static int usersWriteFlag = 1;

    public static boolean isLifeStyleExists = false;
    public static UserInfo infoMap = new UserInfo();

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    static ValueEventListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference();

        Button button1 = findViewById(R.id.b1);
        Button button2 = findViewById(R.id.b2);
        try {
            funSlang();
        } catch (IOException e) {
            e.printStackTrace();
        }


        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                verifyIntroExistence();
                (new Handler()).postDelayed(this::startMentalHealth,5000);
            }

            public void startMentalHealth() {
                Log.d("SelectionActivity:", "intro= " + introMap.toString());
                Intent i = new Intent(getApplicationContext(), MentalHealthActivity.class);
                startActivity(i);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                verifyIntroExistence();
                Intent i = new Intent(getApplicationContext(), LegalAid.class);
                startActivity(i);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent i;
        switch (id) {
            case R.id.update_info:
                verifyInfoExistence();
                break;
            case R.id.update_intro:
                verifyIntroExistence2();
                break;
        }
        return true;
    }

    private void verifyInfoExistence() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("info").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("uid").exists())) {
                    infoMap = dataSnapshot.getValue(UserInfo.class);
                    Toast.makeText(getApplicationContext(), "info exists", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), UpdateInfoActivity.class);
                    startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyIntroExistence2() {
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("age").exists())) {
                    introMap = dataSnapshot.getValue(UserIntro.class);
                    Toast.makeText(getApplicationContext(), "intro exists", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), UpdateIntroActivity.class);
                    startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "info doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyIntroExistence() {
        Log.d("SelectionActivity:", "verifyIntroExistence: fetching intro...");
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("age").exists())) {
                    // newDebugMessage("verifyIntroExistence: Intro exists");
                    //sentToResturentsActivity();
                    introMap = dataSnapshot.getValue(UserIntro.class);
                    // int age=introMap.getAge();
                    Toast.makeText(getApplicationContext(), "intro exists", Toast.LENGTH_SHORT).show();

                    verifyLifestyleExistence();
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                } else {
                    // sentToSettingActivity();
                    Toast.makeText(getApplicationContext(), "intro doesn't exist", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), IntroActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void verifyLifestyleExistence() {
        Log.d("SelectionActivity:", "verifyLifestyleExistence: fetching lifestyle...");
        // newDebugMessage("inside verifyLifestyleExistence()");
        String currentUserId = firebaseAuth.getUid();
        //UserUniqueId=currentUserId;
        mMessageDatabaseReference.child("Database").child(database_no).child("Users").child(currentUserId).child("lifestyle").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if ((dataSnapshot.child("physical_activity").exists())) {
                    // newDebugMessage("verifyLifestyleExistence: Lifestyle Information exists");
                    //sentToResturentsActivity();
                    lifeMap = dataSnapshot.getValue(UserLifestyle.class);
                    // String physical_activity=lifeMap.getPhysical_activity();
                    Toast.makeText(getApplicationContext(), "lifestyle exists", Toast.LENGTH_SHORT).show();
                    isLifeStyleExists = true;
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // Intent i =new Intent(getApplicationContext(),RootCauseActivity.class);
                    // startActivity(i);
                } else {
                    // sentToSettingActivity();
                    // newDebugMessage("verifyLifestyleExistence: Lifestyle Information doesn't exist");
                    Toast.makeText(getApplicationContext(), "lifestyle doesn't exist", Toast.LENGTH_SHORT).show();
                    isLifeStyleExists = false;
                    // Intent i =new Intent(getApplicationContext(),LifeStyleActivity.class);
                    // startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void funSlang() throws IOException {
        String string = "";
        StringBuilder stringBuilder = new StringBuilder();
        InputStream is = this.getResources().openRawResource(R.raw.sample);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        while (true) {
            try {
                if ((string = reader.readLine()) == null) break;
            } catch (IOException e) {
                e.printStackTrace();
            }

            stringBuilder.append(string).append("\n");
            changeStr(string);
            // textView.setText(stringBuilder);
        }
        is.close();
//        Toast.makeText(getBaseContext(), stringBuilder.toString(),
//                Toast.LENGTH_LONG).show();


    }

    public void changeStr(String s) {
        String[] splited = s.split(":");
        slangList.put(splited[0], splited[1]);

    }
}