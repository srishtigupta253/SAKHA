package com.google.firebase.quickstart.auth.java;

import org.jetbrains.annotations.NotNull;

public class Contact {
    private double lat = 0;
    private double lon = 0;
    private String phone = "911234567890";
    private String name = "name";
    private int state = 0;

    // public Contact() {}

    public Contact() {
        this.lat = 0;
        this.lon = 0;
        this.phone = "911234567890";
        this.name = "name";
        this.state = 0;
    }

    public Contact(double lat, double lon, String name, String phone, int state) {
        this.lat = lat;
        this.lon = lon;
        this.phone = phone;
        this.name = name;
        this.state = state;
    }

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public int getState() {
        return state;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setState(int state) {
        this.state = state;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double Distance(double lat, double lon) {
        double lat1 = this.lat;
        double lon1 = this.lon;

        double R = 6371; // Radius of the earth in km
        double dLat = deg2rad(lat -lat1);
        double dLon = deg2rad(lon -lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat)) *
                        Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    private double deg2rad(double deg) {
        return deg * (Math.PI/180);
    }

    @NotNull
    @Override
    public String toString() {
        return name + ": +" + phone;
    }


}
