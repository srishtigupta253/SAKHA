package com.google.firebase.quickstart.auth.java;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isCounsellor;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isLegal;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.mCounsellorContactAdapter;
import static com.google.firebase.quickstart.auth.java.ManageLegalAidContactsActivity.mLegalContactAdapter;

public class AddContactActivity extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_contact);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();

        String key = "CounsellorContacts";
        if (isLegal) key = "LegalContacts";
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child(key);

        Button addToDatabaseButton = (Button) findViewById(R.id.addToDatabaseButton);
        addToDatabaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText username  = (EditText) findViewById(R.id.userNameEditText);
                EditText phoneno = (EditText) findViewById(R.id.phoneNumberEditText);

                String Username = username.getText().toString();
                String PhoneNo = phoneno.getText().toString();


                if (TextUtils.isEmpty(Username)) {
                    Toast.makeText(getApplicationContext(), "Please provide Contact Name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(PhoneNo)) {
                    Toast.makeText(getApplicationContext(), "Please provide Phone Number", Toast.LENGTH_SHORT).show();
                } else {
                    Contact c = new Contact();
                    c.setName(Username);
                    c.setPhone(PhoneNo);
                    mMessageDatabaseReference.push().setValue(c).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "Contact Added", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                String Error = task.getException().toString();
                                Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    if (isCounsellor) {
                        mCounsellorContactAdapter.add(c);
                        mCounsellorContactAdapter.notifyDataSetChanged();
                    }
                    if (isLegal) {
                        mLegalContactAdapter.add(c);
                        mLegalContactAdapter.notifyDataSetChanged();
                    }
                }
            }
        });
    }




}