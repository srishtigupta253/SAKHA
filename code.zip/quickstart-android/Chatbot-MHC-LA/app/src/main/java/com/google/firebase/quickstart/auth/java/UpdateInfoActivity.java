package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.infoMap;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

public class UpdateInfoActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    TextView username;
    EditText firstname;
    EditText lastname;
    EditText phoneno;
    EditText address;

    String Username = infoMap.getUid();
    String PhoneNo = infoMap.getPhone_number();
    String Firstname = infoMap.getFirstname();
    String Lastname = infoMap.getLastname();
    String Address = infoMap.getAddress();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_info);

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Users");

        username = (TextView) findViewById(R.id.username);
        firstname = (EditText) findViewById(R.id.firstname);
        lastname = (EditText) findViewById(R.id.lastname);
        phoneno = (EditText) findViewById(R.id.phonenumber);
        address = (EditText) findViewById(R.id.address_user);

        //***************
        username.setText(Username);
        firstname.setText(Firstname);
        lastname.setText(Lastname);
        phoneno.setText(PhoneNo);
        address.setText(Address);

        // verifyInfoExistence();
        Log.d("UpdateInfoActivity:", "infoMap:" + infoMap.toString());

        Button update_info_button = (Button) findViewById(R.id.update_info_button);
        update_info_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhoneNo = phoneno.getText().toString();
                Firstname = firstname.getText().toString();
                Lastname = lastname.getText().toString();
                Address = address.getText().toString();

                if (TextUtils.isEmpty(Firstname)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your First Name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Lastname)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Last Name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(PhoneNo)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Phone Number", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Address)) {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Address", Toast.LENGTH_SHORT).show();
                } else {
                    String currentUserId = firebaseAuth.getCurrentUser().getUid();
                    UserInfo profileMap = new UserInfo(currentUserId, Username, Firstname, Lastname, PhoneNo, Address);
                    mMessageDatabaseReference.child("Database").child(database_no).child(currentUserId).child("info").setValue(profileMap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getApplicationContext(), "Info Updated", Toast.LENGTH_SHORT).show();
                                        Intent i = new Intent(getApplicationContext(), SelectionActivity.class);
                                        startActivity(i);
                                    } else {
                                        String Error = task.getException().toString();
                                        Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }
            }
        });
    }


}