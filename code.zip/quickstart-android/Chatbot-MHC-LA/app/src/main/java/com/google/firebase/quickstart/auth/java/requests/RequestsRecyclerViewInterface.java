package com.google.firebase.quickstart.auth.java.requests;

public interface RequestsRecyclerViewInterface {
    void onItemClick(int position);
}
