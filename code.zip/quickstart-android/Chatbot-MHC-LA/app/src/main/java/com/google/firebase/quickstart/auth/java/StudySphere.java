package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.RootCauseActivity.isSentiment;

public class StudySphere {

//    public int sphereDetected; // to check whether the sphere was detected or not by api
//    public String totalSentCheck; // total string that has to be sent to api for sentiment analysis
//    public String finalCause; // final cause answer for summary
//    private int someVar; // flag variable


    public int sphereDetected;
    public String totalSentCheck;
    public String finalCause;
    private int someVar;

    StudySphere()
    {
        this.sphereDetected=0;
        this.totalSentCheck="";
        this.finalCause="null";
        this.someVar=0;
    }

    //    i // selecting question no. to be asked
//  		uinput // user input
    public String funStudy(int i, String uinput)
    {
        String temp="null"; // string that contains next question to be asked

        switch(i)
        {
            case 0:

                temp="Study environment can be stressful but it should be comfortable but that doesn’t sound like your case. I hope I understood it right!";
                break;

            case 1:

                if(!funYes(uinput))
                {
                    temp="doneNotFound";
                }
                else
                temp="What are you currently studying? ";
                break;
            case 2:
                temp="Not having friends is an issue various people face these days. Do you?";
                break;
            case 3:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"Not having friends is an issue for me. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"I have friends. ";
                }
                temp="Trying to have fun by teasing a girl about her appearance has become very common. Eve teasing should not be a part of study environment. I hope you are safe from this!";
                break;
            case 4:
                if(uinput.equals("yes"))
                {
                    totalSentCheck=totalSentCheck+"I have safe environment. ";
                }
                else
                {
                    totalSentCheck=totalSentCheck+"My study environment is bad. ";
                }
                temp="Harassment from any one should never be tolerated. Do you see anyone around you that has done something to make you uncomfortable?Please Explain";
                break;
            case 5:
              totalSentCheck=totalSentCheck+uinput;
                temp="checksentiment";
                break;
            case 6:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default Work";

        }

        return temp;
    }
// return final quewstion for the sphere
    public String finalQues()
    {
        return "Studying should have only one stress and that is EXAMS! No other type of tensions should be around you but you sound like you have been facing other problems. Care to share? ";
    }
    // return 1 if yes found else 0
    public boolean funYes(String uinput)
    {
        uinput=uinput.toLowerCase();
        String[] splited= uinput.split(" ");
        for(int i=0;i<splited.length;i++)
        {
            if(splited[i].equals("yes"))
                return true;
        }
        return false;

    }

}
