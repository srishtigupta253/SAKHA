package com.google.firebase.quickstart.auth.java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.google.firebase.quickstart.auth.R;

public class CompletedcounsellingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completedcounselling);
    }
}