package com.google.firebase.quickstart.auth.java.requests;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;
import com.google.firebase.quickstart.auth.java.IntroActivity;
import com.google.firebase.quickstart.auth.java.UserInfo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

public class RequestsActivity extends AppCompatActivity implements RequestsRecyclerViewInterface{

    // firebase variables
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;


    // Recycler view variables
    RecyclerView requestsRecyclerView;
    RequestsRecyclerViewAdapter requestsRecyclerViewAdapter;
    ArrayList<RequestModel> requests;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);


        // init firebase variables
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no);

        // set up the Requests
        requestsRecyclerView = findViewById(R.id.recycler_view_requests);
        fetchActiveRequests(this,this);


    }

    /**
     * Fetches request list from database, sorted by timestamp, adds it to arraylist and sets up recycler view
     * @param context needed for setting up recyclerviewadapter
     * @param requestsRecyclerViewInterface needed for setting up recyclerviewadapter onClick
     */
    private void fetchActiveRequests(Context context, RequestsRecyclerViewInterface requestsRecyclerViewInterface) {

        Query myDBQuery   = mMessageDatabaseReference.child("Requests").orderByChild("timestamp");
        myDBQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    requests= new ArrayList<>();
                    for(DataSnapshot postSnapshot : snapshot.getChildren())
                    {
                        requests.add(postSnapshot.getValue(RequestModel.class));
                    }
                    Collections.reverse(requests); // descending order of date
                    requestsRecyclerViewAdapter = new RequestsRecyclerViewAdapter(context, requests, requestsRecyclerViewInterface);
                    requestsRecyclerView.setAdapter(requestsRecyclerViewAdapter);
                    requestsRecyclerView.setLayoutManager(new LinearLayoutManager(context));


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    /**
     * Describes what happens on clicking on an item in recycler view -> go to SingleRequestActivity
     * @param position : position of item clicked on
     */
    @Override
    public void onItemClick(int position) {
        Intent i = new Intent(getApplicationContext(), SingleRequestActivity.class);

        //pass on the data
        i.putExtra("request",requests.get(position));
        startActivity(i);

    }
}
