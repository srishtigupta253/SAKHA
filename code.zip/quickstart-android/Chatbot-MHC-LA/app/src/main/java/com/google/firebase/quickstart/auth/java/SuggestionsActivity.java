package com.google.firebase.quickstart.auth.java;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

import static com.google.firebase.quickstart.auth.java.CyberCrimeNew.CyberCrimesDetected;
import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.mainRootCause;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.isLifeStyleExists;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.dass21.af;
import static com.google.firebase.quickstart.auth.java.dass21.anxiety_result;
import static com.google.firebase.quickstart.auth.java.dass21.depression_result;
import static com.google.firebase.quickstart.auth.java.dass21.df;
import static com.google.firebase.quickstart.auth.java.dass21.isFromLA;
import static com.google.firebase.quickstart.auth.java.dass21.isFromMHC;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.cyberList;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.CyberLabels;
import static com.google.firebase.quickstart.auth.java.dass21.sf;
import static com.google.firebase.quickstart.auth.java.dass21.stress_result;

public class SuggestionsActivity extends AppCompatActivity {

    private static final String TAG = "LifeStyleActivity";
    public static final int MY_SOCKET_TIMEOUT_MS = 30000;

    private ListView mMessageListView;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    public int introVar = 0;

    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    public int wrtGui = 1;

    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<String>(Arrays.asList("Yes", "No"));
    String platform = "";

    public int platSugState = 0, basicSugState = 0, rootPlatSugState = 0;
    public int cyberCrimeID = 0;

    public Hashtable<Integer, Integer> nextCrime = new Hashtable<Integer, Integer>() {{
        put(0, 1);
        put(1, 2);
        put(2, 3);
        put(3, 5);
        put(5, 6);
        put(6, 7);
        put(7, 8);
        put(8, 9);
        put(9, 10);
        put(10, 11);
        put(11, 12);
        put(12, 13);
        put(13, 14);
        put(14, 15);
        put(15, 16);
        put(16, 17);
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestions);

        //Initialise Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Send messages on click

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                // introVar += 1;
                temp = slangCheck(temp);

                introFun(temp);

            }
        });

        showCyberLabels();
        introStart();
    }

    // @Override
    // public boolean onCreateOptionsMenu(Menu menu) {
    //     MenuInflater inflater = getMenuInflater();
    //     inflater.inflate(R.menu.main_menu, menu);
    //     return true;
    // }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public void showCyberLabels() {
        Set<String> keys = cyberList.keySet();
        String[] array = keys.toArray(new String[0]);
        StringBuilder temp = new StringBuilder();
        for (String s : array) {
            temp.append(s).append("=").append(CyberLabels[Integer.parseInt(Objects.requireNonNull(cyberList.get(s)))]).append("\n");
        }
        Log.d("CyberLabels:", temp.toString());
    }

    public void introStart() {
        // newDebugMessage("introStart-before: "+"introVar="+introVar);
        String temp = "Do you wish to see the legal options you have or do you want to see other options?";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        if (!isFromLA)
            friendlyMessage.setOpt1("Legal Options");
        friendlyMessage.setOpt2("Other Options");
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        introVar++;
        // newDebugMessage("introStart-after: "+"introVar="+introVar);
    }

    public void introFun(String uinput) {
        Log.d("introFun:", "introVar=" + introVar + ", uinput=" + uinput);
        // newDebugMessage("introFun-before: "+"introVar="+introVar+", uinput="+uinput);
        // String temp = "empty";
        // FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        ArrayList<String> options;

        // newDebugMessage("introFun("+uinput+"), case: "+introVar+", uinput: "+uinput);
        switch (introVar) {
            case 1:
                if (uinput.equalsIgnoreCase("legal options")) {
                    wrtGui = 0;
                    startLegalAid();
                } else {
                    newChatbotMessage("One could raise a complaint on the corresponding platform where the offense was committed. You must make sure that you report such activities in the very initial stages of its occurrence.", new ArrayList<>());

                    options = new ArrayList<>();
                    options.add("Facebook");
                    options.add("Instagram");
                    options.add("Twitter");
                    options.add("Snapchat");
                    options.add("YouTube");
                    options.add("WhatsApp");
                    options.add("LinkedIn");
                    options.add("Tinder");
                    newChatbotMessage("Could you select which platform has been causing you grievances?", options);
                    // go to case 2
                }
                introVar++;
                // newDebugMessage("introFun-case1: "+"introVar="+introVar+", uinput="+uinput);
                break;
            case 2:
                platform = uinput;

                options = new ArrayList<>();
                options.add("Yes");
                options.add("No");
                newChatbotMessage("Do you want to explore how to complain on " + platform + "?", options);
                introVar++;
                // newDebugMessage("introFun-case2: "+"introVar="+introVar+", uinput="+uinput);
                break;
            case 3:
                if (funYes(uinput)) {
                    // show platform suggestions
                    // Log.d("introFun:","introVar: "+introVar);
                    platformSuggestions(platform, uinput);
                } else {
                    newChatbotMessage("Hey! Do not panic and have the courage to fight for yourself. I would recommend you to at least take a look at your legal options. ", noOptions);
                    newChatbotMessage("Anyone can lodge a complaint on the victim’s behalf and the victim does not have to necessarily be present in the police station.", noOptions);
                    newChatbotMessage("Another thing to note is though the law does not mandate it; the victim can ask a female police officer to lodge a complaint.", noOptions);
                }
                introVar++;
                // newDebugMessage("introFun-case3: "+"introVar="+introVar+", uinput="+uinput);
                break;
            case 4:
                platformSuggestions(platform, uinput);
                // introVar++;
                // newDebugMessage("introVar = "+introVar);
                // introFun("null");
                break;
            case 5:
                rootPlatformSuggestions(platform, uinput);
                // introVar++;
                break;
            // case 6:
            //     rootPlatformSuggestions(platform, uinput);
            //     introVar++;
            //     // newDebugMessage("introVar = "+introVar);
            //     introFun("null");
            //     break;
            case 6:
                options = new ArrayList<>();
                if (!isFromLA)
                    options.add("Legal Aid");
                options.add("Basic Suggestions");
                newChatbotMessage("Do you now want to go see the Legal Aid or just some basic suggestions?", options);
                introVar++;
                Log.d("introFun-case6:", "introVar=" + introVar);
                // newDebugMessage("introFun-case6: introVar="+introVar);
                break;
            case 7:
                if (uinput.equalsIgnoreCase("legal aid")) {
                    wrtGui = 0;
                    startLegalAid();
                } else {

                    // **PAID FEATURE** : Basic suggestion
                    Log.v("utk","database_no : "+database_no);
                    if (database_no.equalsIgnoreCase("licfree")) //free user
                    {
                        showPaidFeatureAlert();
                        introVar = 5; // go to case 6 again
                    } else {

                        // basic suggestions
                        basicSuggestions(uinput);
                        introVar++;
                    }
                }
                break;
            case 8:
                if (database_no.equalsIgnoreCase("licfree")) //free user
                {
                    showPaidFeatureAlert();
                    introVar = 5; // go to case 6 again
                    break;
                }
                basicSuggestions(uinput);
                break;
            default:
                wrtGui = 0;
                startLegalAid();
        }
    }

    void startLegalAid() {
        isFromMHC = true;
        Intent iii = new Intent(getApplicationContext(), LegalAid.class);
        startActivity(iii);
    }

    void platformSuggestions(String platform, String uinput) {
        // newDebugMessage("platformSuggestions-before: "+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
        ArrayList<String> options;
        if (platSugState == 0) {
            newChatbotMessage("Here are some suggestions for " + platform, noOptions);
        }
        switch (platform) {
            case "Facebook":
                if (platSugState == 0) {
                    options = new ArrayList<>(Arrays.asList(
                            "Someone is threatening to share something private",
                            "Someone shared your intimate photo",
                            "Report an abusive photo",
                            "Report other types of content",
                            "Report a post",
                            "Form for reporting intimate images or related threats/blackmail",
                            "Report anything"
                    ));
                    newChatbotMessage("We have suggestions for the following. Select one to see the relevant suggestions:", options);
                    platSugState++;
                } else if (platSugState == 1) {
                    uinput = uinput.toLowerCase();
                    switch (uinput) {
                        case "someone is threatening to share something private":
                            newChatbotMessage("What to do if someone is threatening to share something I want to keep <a href=\"https://www.facebook.com/help/561743407175049\">private</a>?", noOptions);
                            break;
                        case "someone shared your intimate photo":
                            newChatbotMessage("What should I do if someone <a href=\"https://www.facebook.com/help/1381617785483471?sr=1&query=revenge&sid=173BNFUFP9x1F8GiZ\">shares an intimate photo of me</a> ?", noOptions);
                            break;
                        case "report an abusive photo":
                            newChatbotMessage("How do I <a href=\"https://www.facebook.com/help/189722821075378\">report an abusive photo</a> ?", noOptions);
                            break;
                        case "report other types of content":
                            newChatbotMessage("How do I report <a href=\"https://www.facebook.com/help/181495968648557\">other types of content</a>?", noOptions);
                            break;
                        case "report a post":
                            newChatbotMessage("Do you want to report a post ?\n" +
                                    "1.Click the photo or video you want to report\n" +
                                    "2.Hover over the photo and click Options in the bottom right\n" +
                                    "3.Select Report Photo or Report Video\n" +
                                    "4.Select I think it shouldn't be on Facebook\n" +
                                    "5.Click on Submit to Facebook for Review\n" +
                                    "6.You can track the status of your report in the <a href=\"https://www.facebook.com/support/\">Support Dashboard</a>\n", noOptions);
                            break;
                        case "form for reporting intimate images or related threats/blackmail":
                            newChatbotMessage("Click here to open the <a href=\"https://www.facebook.com/help/contact/144059062408922\">form for reporting intimate images, threats to post intimate images, or blackmail</a>", noOptions);
                            break;
                        default:
                            newChatbotMessage("To report anything, check <a href=\"https://www.facebook.com/help/1380418588640631?helpref=hc_fnav\">this link</a>", noOptions);
                            break;
                    }
                    // newDebugMessage("introVar = "+introVar);
                    platSugState = 0;
                    introVar++;
                    Log.d("platformSuggestions:", "introVar=" + introVar);
                    // newDebugMessage("platformSuggestions-case1:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                    introFun("null-platformSug-" + platform);
                }
                break;

            case "Instagram":
                if (platSugState == 0) {
                    options = new ArrayList<>();
                    options.add("Report a comment");
                    options.add("Report a profile");
                    options.add("Report a Post");
                    options.add("Report a message");
                    options.add("Report someone (if you don't have Instagram)");
                    options.add("Never mind, I will use the Help Center");
                    newChatbotMessage("Here are the various things you could report. Select one to see the relevant suggestions:", options);
                    platSugState++;
                } else if (platSugState == 1) {
                    uinput = uinput.toLowerCase();
                    if (uinput.contains("comment")) {
                        newChatbotMessage("Do you want to <a href=\"https://help.instagram.com/198034803689028\">report a comment</a> ?", noOptions);
                    } else if (uinput.contains("profile")) {
                        newChatbotMessage("Do you want to report a profile ? Here are the steps to do so:\n" +
                                "1. Tap  •••(iOS and Windows Phone)or(Android) in the top right of the profile\n" +
                                "2. Tap Report (iOS and Android)or Report for Spam(Windows Phone) and select It’s Inappropriate\n" +
                                "3. Follow the on - screen instructions\n", noOptions);
                    } else if (uinput.contains("post")) {
                        newChatbotMessage("Do you want to report a post ? Here are the steps to do so:\n" +
                                "1. Tap  •••(iOS and Windows Phone)or(Android) above or below the post\n" +
                                "2. Tap Report\n" +
                                "3. Tap It’s inappropriate\n" +
                                "4. Follow the on - screen instructions", noOptions);
                    } else if (uinput.contains("message")) {
                        newChatbotMessage("Do you want to report a message ? Here are the steps to do so:\n" +
                                "1. Open the conversation in the Instagram app.\n" +
                                "2. Tap and hold the individual message you 'd like to report.\n" +
                                "3. Tap Report.\n" +
                                "4. Select a reason for why you're reporting the message and then tap Submit Report.", noOptions);
                    } else if (uinput.contains("someone")) {
                        newChatbotMessage("If you don’t have an Instagram account, you can report someone using <a href=\"https://help.instagram.com/contact/383679321740945\">this form</a>", noOptions);
                    } else {
                        newChatbotMessage("<a href=\"https://help.instagram.com/192435014247952\">Help center</a>", noOptions);
                    }
                    platSugState = 0;
                    introVar++;
                    // newDebugMessage("platformSuggestions-case1:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                    introFun("null-platformSug-" + platform);
                    // newDebugMessage("introVar = "+introVar);
                }
                break;

            case "Twitter":
                newChatbotMessage("Reporting a Tweet:\n" +
                        "1. Navigate to the offending Tweet.\n" +
                        "2. Click the More icon(••• icon on web and iOS; icon on Android).\n" +
                        "3. Select Report.\n" +
                        "4. Select It’s abusive or harmful.\n" +
                        "5. Give more information if prompted.\n" +
                        "6. Follow instructions in confirmation email you receive.\n", noOptions);
                newChatbotMessage("<a href=\"https://help.twitter.com/en/safety-and-security/report-abusive-behavior\">Help center</a>", noOptions);
                newChatbotMessage("<a href=\"https://help.twitter.com/forms\">File a ticket when encountering a problem or witnessing a violation</a>", noOptions);
                newChatbotMessage("<a href=\"https://support.twitter.com/forms/private_information\">To report exposed private information</a>", noOptions);
                newChatbotMessage("<a href=\"https://help.twitter.com/en/safety-and-security/report-a-tweet\">Report a Direct Message or conversation</a>", noOptions);
                introVar += 2;
                // newDebugMessage("platformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-platformSug-" + platform);
                break;

            case "Snapchat":
                if (platSugState == 0) {
                    newChatbotMessage("Snapchat’s <a href=\"https://support.snapchat.com/en-GB/a/guidelines\">Community Guidelines</a> and <a href=\"https://www.snap.com/en-GB/terms/\">Terms of Service</a> have a zero-tolerance policy for harassment of any kind.", noOptions);
                    options = new ArrayList<>((Arrays.asList(
                            "Report a Story or Snap",
                            "Report a Snapchat account",
                            "Change who can contact you",
                            "Report an issue (if you don't have an account)",
                            "Report an issue (if you can't do it from the app)",
                            "Never mind, I will use the Snapchat Sharing Center"
                    )));
                    newChatbotMessage("We have suggestions for the following. Select one to see relevant suggestions", options);
                    platSugState++;
                } else if (platSugState == 1) {
                    if (uinput.equalsIgnoreCase("report a story or snap")) {
                        newChatbotMessage("To report a Story or a Snap someone sent you:\n" +
                                "1. Press and hold on the Snap until a 🏳️button appears in the bottom - left corner\n" +
                                "2. Tap ‘🏳️Report’\n" +
                                "3. Select the appropriate reporting option\n" +
                                "4. A comment box is available if you’d like to give more information\n" +
                                "5. Submit your report", noOptions);
                    } else if (uinput.equalsIgnoreCase("report a snapchat account")) {
                        newChatbotMessage("To report a Snapchat account:\n" +
                                "1. Press and hold on a Snapchatter’s name\n" +
                                "2. Tap the ⚙button\n" +
                                "3. Tap ‘Report’\n" +
                                "4. Select the appropriate reporting option\n" +
                                "5. Submit your report", noOptions);
                    } else if (uinput.equalsIgnoreCase("change who can contact you")) {
                        newChatbotMessage("To change who can contact you:\n" +
                                "1. Tap the ⚙️button in the Profile screen to open Settings\n" +
                                "2. Scroll down to the ‘Who Can…‘section and tap an option\n" +
                                "3. Select an option, then tap the back button to save your choice\n" +
                                "4. By default,only ‘Friends’you’ve added on Snapchat can contact you directly or view your Story.", noOptions);
                    } else if (uinput.equalsIgnoreCase("report an issue (if you don't have an account)") || uinput.equalsIgnoreCase("report an issue (if you can't do it from the app)")) {
                        newChatbotMessage("If you don’t have a Snapchat account or are unable to report a safety concern in-app, you can report any issue on the <a href=\"https://support.snapchat.com/i-need-help?start=5153567363039232\">Snapchat Support</a> site.", noOptions);
                    } else {
                        newChatbotMessage("<a href=\"https://www.snap.com/en-US/safety/safety-center/\">Snapchat Safety Center</a>", noOptions);
                    }
                    platSugState = 0;
                    introVar++;
                    // newDebugMessage("platformSuggestions-case1:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                    introFun("null-platformSug-" + platform);
                }
                break;

            case "YouTube":
                newChatbotMessage("Take a look at YouTube's <a href=\"https://www.youtube.com/yt/about/policies/#community-guidelines\">Policies and Safety</a>", noOptions);
                newChatbotMessage("<a href=\"https://www.youtube.com/reportabuse\">Report an abusive user</a> via YouTube’s reporting tool", noOptions);
                introVar += 2;
                // newDebugMessage("platformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-platformSug-" + platform);
                break;

            case "WhatsApp":
                newChatbotMessage("When you report abusive content, WhatsApp advises users to \"provide as much information as possible.\"", noOptions);
                newChatbotMessage("You can take a look at Whatsapp's <a href=\"https://faq.whatsapp.com/general/security-and-privacy/staying-safe-on-whatsapp/?lang=en\">Security and Policy</a> page", noOptions);
                newChatbotMessage("You can “Report”, “Report and Block” an individual account, or “Report and Exit” a group.", noOptions);
                newChatbotMessage("If you “Report” an abuser, they can still send you texts, messages, or voice notes.", noOptions);
                newChatbotMessage("If you “Report and Block,” your chats with the abuser will be deleted.", noOptions);
                newChatbotMessage("<b>TIP</b>: You might want to take a screenshot before reporting and blocking in order to document your harassment.", noOptions);
                introVar += 2;
                // newDebugMessage("platformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-platformSug-" + platform);
                break;

            case "LinkedIn":
                newChatbotMessage("<a href=\"https://www.linkedin.com/help/linkedin\">Help center</a>", noOptions);
                newChatbotMessage("<a href=\"https://www.linkedin.com/help/linkedin/answer/37822/recognizing-and-reporting-spam-inappropriate-and-abusive-content?lang=en\">Recognize and Report Spam, Inappropriate, and Abusive Content</a>", noOptions);
                introVar += 2;
                // newDebugMessage("platformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-platformSug-" + platform);
                break;

            case "Tinder":
                newChatbotMessage("<a href=\"https://www.help.tinder.com/hc/en-us/articles/115003822043-Reporting-something-that-happened-on-the-app\">Help center</a>", noOptions);
                newChatbotMessage("<a href=\"https://www.help.tinder.com/hc/requests/new?ticket_form_id=360000234472\">Directly report</a> using: You might have to include the reason for the report; the exact name, age, bio, and photos that appear on the profile that you are reporting (screenshots are best); the user 's location, phone number or email address (if known);", noOptions);
                newChatbotMessage("To report in the app:\n" +
                        "1. While swiping: open the user's profile > scroll down and tap Report\n" +
                        "2. From your match list: select the user to open the message screen > tap the user’s photo to open their profile >scroll down and select Report", noOptions);
                introVar += 2;
                // newDebugMessage("platformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-platformSug-" + platform);
                break;
        }
    }

    void rootPlatformSuggestions(String platform, String uinput) {

        Log.d("UTK", "rootPlatformSuggestions function called");

        switch (platform) {
            case "Facebook":
                switch (mainRootCause) {
                    case "social media account hacked":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("If you believe your account has been compromised by another person or a virus, please click the \"My account is compromised\" button below. Facebook will help you to log back into your account so that you can regain control if you open <a href=\"https://www.facebook.com/hacked\">this link</a>", noOptions);
                        }
                        break;
                    case "blackmailing":
                    case "sending obscene content":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("If someone sends you a message on Facebook that makes you uncomfortable, you can see <a href=\"https://www.facebook.com/help/1709360766019559\">this link</a>", noOptions);
                            newChatbotMessage("For more ways to do so, you can see <a href=\"https://www.facebook.com/help/263149623790594/\">this link</a>", noOptions);
                        }
                        break;
                    case "faking my profile":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("You can report an impersonating Facebook account by <a href=\"https://www.facebook.com/help/contact/295309487309948\">filling in a form</a>.", noOptions);
                            newChatbotMessage("Note: You can also report impersonating accounts in Messenger. Learn how to <a href=\"https://www.facebook.com/help/messenger-app/desktop/1770700349678682\">report someone that's pretending to be you or someone else</a> in Messenger.", noOptions);
                            newChatbotMessage("For further queries: visit <a href=\"https://www.facebook.com/help/1216349518398524?helpref=hc_fnav\">this link</a>.", noOptions);
                        }
                        break;
                    default:
                        // newDebugMessage("No rootPlatformSuggestions");
                        break;
                }
                introVar++;
                Log.d("rootPlatformSuggestions", "introVar=" + introVar);
                // newDebugMessage("rootPlatformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                introFun("null-rootPlatformSug-" + platform);
                break;

            case "Instagram":
                switch (mainRootCause) {
                    case "social media account hacked":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("If you think your account has been hacked or an attempt to hack your account has been made, I want to know: \n" + "Are you still able to login to your account?", YesNoOptions);
                            rootPlatSugState++;
                        } else if (rootPlatSugState == 1) {
                            if (funYes(uinput)) {
                                newChatbotMessage("There are things you can do to help keep your account secure: \n" +
                                        "1. <a href=\"https://instagram.com/accounts/password/change/\">Change your password</a> or send yourself a <a href=\"https://instagram.com/accounts/password/reset/\">password reset email</a>. \n" +
                                        "2. Turn on <a href=\"https://help.instagram.com/566810106808145\">two-factor authentication</a> for additional security. \n" +
                                        "3. <a href=\"https://help.instagram.com/131112217071354\">Confirm your phone number and email address in account settings</a> are correct. \n" +
                                        "4. <a href=\"https://help.instagram.com/1731078377046291\">Check Accounts Center</a> and remove any linked accounts you don’t recognize. \n" +
                                        "5. <a href=\"https://instagram.com/accounts/manage_access\">Revoke access</a> to any suspicious third-party apps. ", noOptions);

                                introVar++;
                                // newDebugMessage("rootPlatformSuggestions-case1:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                                introFun("null-rootPlatformSug-" + platform);
                            } else {
                                newChatbotMessage("Please head over to <a href=\"https://help.instagram.com/149494825257596\">this link</a> to see what other options are available for you.", noOptions);

                                introVar++;
                                // newDebugMessage("rootPlatformSuggestions-case2:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                                introFun("null-rootPlatformSug-" + platform);
                            }
                            rootPlatSugState = 0;
                        }
                        break;
                    case "blackmailing":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("Your private content is your own. It is against <a href=\"https://www.facebook.com/help/instagram/1443273235892548\">Instagram's rules</a> for someone to share or threaten to share your intimate images, videos or messages without your consent.", noOptions);
                            newChatbotMessage("You should also consider reporting it legally. Would you like to see how?", YesNoOptions);
                            rootPlatSugState++;
                        } else if (rootPlatSugState == 1) {
                            rootPlatSugState = 0;
                            if (funYes(uinput)) {
                                wrtGui = 0;
                                startLegalAid();
                            } else {
                                introVar++;
                                // newDebugMessage("rootPlatformSuggestions-case1:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                                introFun("null-rootPlatformSug-" + platform);
                            }
                        }
                        break;
                    case "faking my profile":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("Instagram only responds to reports sent from the person who's being impersonated or a representative of the person who's being impersonated.", noOptions);
                            newChatbotMessage("If you have an account, you can start by filling out <a href=\"https://help.instagram.com/contact/636276399721841\">this form</a> or if you don't, you can fill <a href=\"https://help.instagram.com/contact/636276399721841\">this form</a>.", noOptions);
                            newChatbotMessage("You could also visit this <a href=\"https://help.instagram.com/370054663112398\">link</a>", noOptions);
                        }
                        introVar++;
                        // newDebugMessage("rootPlatformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                        introFun("null-rootPlatformSug-" + platform);
                        break;
                    case "sending obscene content":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("You can report abusive photos, videos and messages that are sent to you on Instagram by: \n" +
                                    "1. Open the conversation in the Instagram app. \n" +
                                    "2. Tap and hold the individual message you'd like to report. \n" +
                                    "3. Tap Report. \n" +
                                    "4. Select a reason for why you're reporting the message and then tap Submit Report.", noOptions);
                        }
                        introVar++;
                        // newDebugMessage("rootPlatformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                        introFun("null-rootPlatformSug-" + platform);
                        break;
                    case "online harassment":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("To Report harassment or bullying on Instagram, <a href=\"https://help.instagram.com/547601325292351\">use this link</a> to find out more.", noOptions);
                        }
                        introVar++;
                        // newDebugMessage("rootPlatformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                        introFun("null-rootPlatformSug-" + platform);
                        break;
                    default:
                        introVar++;
                        // newDebugMessage("rootPlatformSuggestions-case0:"+"platform="+platform+",introVar="+introVar+", uinput="+uinput);
                        introFun("null-rootPlatformSug-" + platform);
                        break;
                }
                break;

            case "Twitter":
                switch (mainRootCause) {
                    case "social media account hacked":
                        newChatbotMessage("If you think you've been hacked and you're unable to log in with your username and password, please take the following two steps: \n" +
                                "1. Reset your password by requesting an email from the password reset form. \n" +
                                "2. If you're able to log in after the password reset, please check if your account has been compromised and re-secure your account. \n" +
                                "3. If you still can't log in, contact Support by submitting a Support Request. ", noOptions);
                        introVar++;
                        introFun("null");
                        break;
                    case "sending obscene content":
                        newChatbotMessage("Understanding the context often diffuses a negative or confusing interaction, but, there are times when further action, like <a href=\"https://help.twitter.com/en/using-twitter/how-to-unfollow-on-twitter\">unfollowing</a> or <a href=\"https://help.twitter.com/en/using-twitter/blocking-and-unblocking-accounts\">blocking</a> someone, may be more effective.", noOptions);
                        newChatbotMessage("There are also many <a href=\"https://about.twitter.com/en_us/safety/safety-partners.html\">online safety resources</a> that can help.", noOptions);
                        introVar++;
                        introFun("null");
                        break;
                    case "blackmailing":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("If someone has Tweeted or messaged a violent threat that you feel is credible or you fear for your own or someone else’s physical safety, you may want to see some legal help.", noOptions);
                            newChatbotMessage("If contacted by law enforcement directly, we can work with them and provide the necessary information for their investigation of the threat.", noOptions);
                            newChatbotMessage("Would you like to see your options?", YesNoOptions);
                            rootPlatSugState++;
                        } else if (rootPlatSugState == 1) {
                            rootPlatSugState = 0;
                            if (funYes(uinput)) {
                                wrtGui = 0;
                                startLegalAid();
                            } else {
                                newChatbotMessage("Check <a href=\"\"https://help.twitter.com/en/safety-and-security/report-abusive-behavior \">this page</a> to learn more about reporting abusing behavior \n", noOptions);
                                introVar++;
                                introFun("null");
                            }
                        }
                        break;
                    case "faking my profile":
                        newChatbotMessage("You do not need a Twitter account to report impersonation on Twitter. ", noOptions);
                        newChatbotMessage("You can report an account for impersonation directly from that account’s profile.", noOptions);
                        newChatbotMessage("Find instructions on <a href=\"https://help.twitter.com/en/rules-and-policies/twitter-report-violation\">how to report impersonation directly from a profile</a>.", noOptions);
                        newChatbotMessage("You can also file an <a href=\"https://help.twitter.com/forms/impersonation\">impersonation report</a>.", noOptions);
                        introVar++;
                        introFun("null");
                        break;
                    default:
                        introVar++;
                        introFun("null");
                        break;
                }
                break;

            case "Snapchat":
                switch (mainRootCause) {
                    case "social media account hacked":
                        newChatbotMessage("If your account has been hacked and you can no longer access it, please use <a href=\"\"https://support.snapchat.com/en-US/i-need-help?start=5145405817880576\">this</a> for fastest resolution of query.", noOptions);
                        newChatbotMessage("You could also visit <a href=\"https://support.snapchat.com/en-US/a/hacked-howto\">this link</a> for more tips", noOptions);
                        break;
                    case "faking my profile":
                        newChatbotMessage("The only way out of it is to report the account.\n" +
                                "1. To report a Snapchat account, press and hold on that Snapchatter's name and tap the ⚙ button.  \n" +
                                "2. Tap 'Report' to report the account and let them know what's going on. ", noOptions);
                        break;
                    case "blackmailing":
                    case "online harassment":
                    case "sending obscene content":
                        newChatbotMessage("You can report abuse on Snapchat, including harassment, bullying, or other safety concerns. https://support.snapchat.com/en-US/a/report-abuse-in-app ", noOptions);
                        newChatbotMessage("In case you do not have the app, you could also use: https://support.snapchat.com/i-need-help ", noOptions);
                        newChatbotMessage("You could also remove or block friends. When you remove a friend from your friends list, they won’t be able to view any of your private Stories but they’ll still be able to view any content you have set to public. \n" +
                                "Find out how, over here: https://support.snapchat.com/en-US/a/remove-block-friends ", noOptions);
                        break;
                    default:
                        introVar++;
                        introFun("null-rootPlatformSug-" + platform);
                        break;
                }
//                introVar++;
//                introFun("null-rootPlatformSug-"+platform);
                break;

            case "YouTube":
                introVar++;
                introFun("null");
                break;

            case "WhatsApp":
                switch (mainRootCause) {
                    case "social media account hacked":
                        if (rootPlatSugState == 0) {
                            newChatbotMessage("Open WhatsApp > Tap <b>⋮</b> at the top right > Tap on <b>WhatsApp web</b> > <b>Log out of all devices</b> ", noOptions);
                            newChatbotMessage("If you find out that no device is linked and you still continue to experience same thing, there are a few steps to follow. Would you like to see how?", YesNoOptions);
                            rootPlatSugState++;
                        } else if (rootPlatSugState == 1) {
                            if (funYes(uinput)) {
                                newChatbotMessage("Please follow the steps below to recover a hacked WhatsApp account. \n" +
                                        "1. <b>Log out of your WhatsApp</b> messenger and login again using your phone number \n" +
                                        "2. A six-digit code will be sent to your phone number via sms. <b>Enter the code</b>. \n" +
                                        "3. This logs you into your account immediately, and <b>automatically logs out the hacker</b>. \n" +
                                        "4. If you are asked to provide a two-step verification code, even though you did not set up one, it means the individual using your account must have activated a two-step verification code. Since you do not have the code, it means you have to <b>wait 7 days again</b> before you can sign in without the two-step verification code. \n" +
                                        "5. Remember that the hacker had been logged out immediately you were logged in with the 6-digit SMS code? So no worries. The hacker cannot continue any chat with your contacts and they cannot even get access to your WhatsApp account during this period. ", noOptions);
                            }
                            rootPlatSugState = 0;
                            introVar++;
                            introFun("null");
                        }
                        break;
                    default:
                        introVar++;
                        introFun("null");
                        break;
                }
                break;

            case "LinkedIn":
                switch (mainRootCause) {
                    case "social media account hacked":
                        newChatbotMessage("If you can't access your account with your login information and notice changes being made to your account or if you suspect that someone else has access to your account, fill the <a href=\"https://www.linkedin.com/help/linkedin/ask/TS-RHA\">Report Your Hacked Account</a> form as soon as possible.", noOptions);
                        newChatbotMessage("For more information about this, please visit <a href=\"https://www.linkedin.com/help/linkedin/answer/56363/reporting-a-compromised-account?lang=en\">this link</a>.", noOptions);
                        break;
                    case "faking my profile":
                        newChatbotMessage("In order to Report Fake Profiles, please visit <a href=\"https://www.linkedin.com/help/linkedin/answer/61664/reporting-fake-profiles?lang=en\">this link</a>", noOptions);
                        break;
                    case "blackmailing":
                        newChatbotMessage("If someone is contacting you in a threatening or abusive way, <a href=\"https://www.linkedin.com/help/linkedin/ask/rhsc\">please report the behavior</a> here.", noOptions);
                        break;
                    case "online harassment":
                    case "sending obscene content":
                        newChatbotMessage("Please follow these steps to report harassment, and inappropriate or offensive posts, comments, messages, or accounts:" +
                                "Click the More icon in the upper right corner of the message or post, or on the right side of the comment.\n" +
                                "Click Report this post or Report.\n" +
                                "When prompted with Why are you reporting this? Select Harassment.", noOptions);
                        newChatbotMessage("After you complete your report, they will review the content and/or account and take the appropriate next steps.", noOptions);
                        newChatbotMessage("To Report Harassment, use LinkedIn's <a href=\"https://www.linkedin.com/help/linkedin/ask/rhsc\">Safety Concern Form</a>", noOptions);
                        break;
                    default:
                        introVar++;
                        introFun("null");
                        break;
                }
//                introVar++;
//                introFun("null");
                break;

            case "Tinder":
                if (rootPlatSugState == 0) {
                    switch (mainRootCause) {
                        case "social media account hacked":
                            newChatbotMessage("If you notice suspicious activity on your account, such as messages you didn’t send or photos you haven't uploaded, there are <a href=\"https://www.help.tinder.com/hc/en-us/articles/115005149706-I-think-my-account-has-been-compromised\">some things you can do to ensure your account is secure</a>.", noOptions);
                            break;
                        default:
                            newChatbotMessage("<a href=\"https://www.help.tinder.com/hc/requests/new\">Click Here</a> and describe your situation in as much detail as possible, so they can get you the help you need, right away.", noOptions);
                    }
                    introVar++;
                    introFun("null");
                }
                break;
        }
    }

    void basicSuggestions(String uinput) {
        if (cyberCrimeID < cyberList.size()) {
            Log.d("basicSuggestions:", "CyberLabels[" + cyberCrimeID + "]=" + CyberLabels[cyberCrimeID]);
            while (true) {
                if (CyberLabels[cyberCrimeID] == 3) break;

                cyberCrimeID = nextCrime.get(cyberCrimeID);
                basicSugState = 0;

                // basicSuggestions("null");

                if (cyberCrimeID >= cyberList.size()) {
                    break;
                }

                if (CyberLabels[cyberCrimeID] == 3) {
                    break;
                }
            }
        }

        ArrayList<String> options;
        // newDebugMessage("Basic Suggestions for "+cyberCrimeID);
        switch (cyberCrimeID) {
            case 0:
                // newDebugMessage("Basic Suggestions "+cyberCrimeID);
                // cyber stalking
                if (basicSugState == 0) {
                    newChatbotMessage("You could contact the National Commission for Women by calling on either <a href=\"tel:1091\">1091</a> for women in distress and <a href=\"tel:011-26942369\">011-26942369</a> or <a href=\"tel:011-26944754\">011-26944754</a> to contact the NCW.", noOptions);
                    newChatbotMessage("Is the offender someone you know?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    uinput = uinput.toLowerCase();
                    if (funYes(uinput)) {
                        newChatbotMessage("You may send the stalker a clear written warning saying the contact is unwanted.", noOptions);
                    }
                    newChatbotMessage("BLOCK them immediately.", noOptions);
                    newChatbotMessage("Consider changing your email address and ISP; use encryption software or privacy protection programs on your computer and mobile devices. (Consult with law enforcement before changing your email account.)", noOptions);
                    newChatbotMessage("Have you saved copies of all communication from the stalker (e.g., emails, threatening messages, messages via social media)?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 2) {
                    uinput = uinput.toLowerCase();
                    if (funYes(uinput)) {
                        newChatbotMessage("You have enough evidence to file a complaint against him. I would encourage you to at least have a look at the options you have.", noOptions);
                    }

                    options = new ArrayList<>();
                    options.add("Yes");
                    options.add("No");
                    newChatbotMessage("Would you like to take a glance at your legal options?", options);

                    basicSugState++;
                } else if (basicSugState == 3) {
                    uinput = uinput.toLowerCase();
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("<b>Here are a few suggestions to prevent it in the future:</b>\n" +
                                "1. Be careful about your passwords. Unique and strong passwords, secret questions which are hard to answer highly are recommended. It is also recommended to keep changing all your passwords on yearly basis.", noOptions);
                        newChatbotMessage("2. Always log out of your computer programs when you step away from the computer. The use of a screensaver with a password is a good practice.", noOptions);
                        newChatbotMessage("3. If you post photos online via social networks or other methods, do turn off the location services metadata in the photo. You can turn this off by disabling GPS on your phone.", noOptions);
                        newChatbotMessage("4. Only accept friend requests from people you have actually met in person. Set your social networks to accept friend requests only from friends of friends.", noOptions);
                        newChatbotMessage("5. Don't let social networks post your address or phone number publicly. If you need to share your phone number or other private information with a friend, do so in a private message - not in a public post.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 1:
                // newDebugMessage("Basic Suggestions for "+cyberCrimeID);
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("Someone seems to have wrongfully obtained and used your personal data. You could place a Fraud Alert with a National Credit Reporting Agency and currently, in India, the leading credit bureaus are – TransUnion CIBIL, Equifax, Experian.", noOptions);
                    newChatbotMessage("Would you like to see how to place a fraud alert?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. Exercise caution when clicking on links and opening email attachments. If the link/attachment is from someone you don’t recognize, don’t open it.\n" +
                                "2. There have been instances where criminals have used offline techniques to replicate one’s identity. It is advised to destroy any physical private records and statements that include any personal and/or financial data.\n" +
                                "3. Be wary of public WiFi and think twice before joining an unsecured network.\n" +
                                "4. Change your passwords. Make sure they do not resemble your old passwords.\n" +
                                "5. Check computer for virus. If you think your computer might be infected, run an updated antivirus program or seek expert help to get the viruses removed.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 2:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("Someone has taken your money by an abuse of a position of trust. There is only one way to get your money back legally and that is to complain to different entities.", noOptions);
                    newChatbotMessage("Would you like to see how?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. Remember there are no get-rich-quick schemes: if it sounds too good to be true it probably is a trap.\n" +
                                "2. Do not chat with strangers over net. Fraudsters and scammers prowl on the internet looking for victims.\n" +
                                "3. Never send money or give credit card details, online account details or copies of personal documents to anyone you don’t know or trust and never by email.\n" +
                                "4. Avoid any arrangement with a stranger who asks for up-front payment via money order, wire transfer, international funds transfer, pre-loaded card or electronic currency. \n" +
                                "5. Verify the identity of the contact by calling the relevant organization directly Do an internet search using the names or exact wording of the letter/email to check for any references to a scam – many scams can be identified this way.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 3:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("For many women, their first instincts are to get the content removed from the internet immediately.", noOptions);
                    newChatbotMessage("However, before you do that, consider if you want to document or capture any evidence, so you have a record of what was posted and by whom.", noOptions);
                    newChatbotMessage("Do you want to check some tips for documenting evidence?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        newChatbotMessage("1. Capture the URL of where the image was posted. If the URL doesn't include it, identify which website it was posted on.", noOptions);
                        newChatbotMessage("2. If the website shows who posted the image, also capture the name of the person who posted it and any other profile information available about them.", noOptions);
                        newChatbotMessage("3. Try to capture the date/time the image was posted if possible and always record the date the evidence was collected.", noOptions);
                        newChatbotMessage("4. If there is any other related harassment, such as emails or texts, be sure to keep those as well.", noOptions);
                        newChatbotMessage("5. If the abusive person made any statements about posting your intimate image, record that in your documentation log.", noOptions);

                        cyberCrimeID = 5;
                        basicSugState = 0;

                        basicSuggestions("null");
                    } else {
                        newChatbotMessage("Here are some tips that may be helpful:\n" +
                                "1. If your photos and videos are automatically uploaded to an online cloud service, check to make sure that those accounts are secure and someone else doesn’t know the password.", noOptions);
                        newChatbotMessage("2. If there is anyone you don’t want to see your information, you may unfriend them or remove them as a follower of your account.", noOptions);
                        newChatbotMessage("3. Put passcodes on your devices, particularly devices that has photos and videos of you.", noOptions);
                        newChatbotMessage("4. If you feel comfortable, consider creating a Google Alert for your name so that if anything is posted online with your name, you will get an alert.", noOptions);
                        newChatbotMessage("Would you like to see how?", YesNoOptions);

                        basicSugState++;
                    }
                } else if (basicSugState == 2) {
                    if (funYes(uinput)) {
                        newChatbotMessage("Head over to the link: <a href=\"https://support.google.com/websearch/answer/4815696?hl=en\">https://support.google.com/websearch/answer/4815696?hl=en</a>", noOptions);

                        cyberCrimeID = 5;
                        basicSugState = 0;

                        basicSuggestions("null");
                    } else {
                        newChatbotMessage("It would be helpful if you complain this either online or physically. Would you like to atleast have a look at your options?", YesNoOptions);

                        basicSugState++;
                    }
                } else if (basicSugState == 3) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        cyberCrimeID = 5;
                        basicSugState = 0;

                        basicSuggestions("null");
                    }
                }
                break;
            // case 4:
            //     uinput = uinput.toLowerCase();
            //     if(basicSugState == 0) {
            //         // suggestions for NCP are not there
            //
            //         cyberCrimeID++;
            //         basicSugState = 0;
            //
            //         basicSuggestions("null");
            //     }
            //     break;
            case 5:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("In case somebody has misused your card details or any other kind of bank fraud, you better complain about them. It would be the most helpful.", noOptions);
                    newChatbotMessage("Would you like to see now?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. Always log out of your online banking account or banking app when you have finished using it. Closing the app or web page or turning off your device may not be sufficient. \n" +
                                "2. Do not use publicly available Wi-Fi networks for banking. It is very difficult to tell if a hotspot is secure or not, so it is always best not to use it.\n" +
                                "3. Always monitor your bank statements regularly, to ensure that payments have not been taken from your account without your knowledge or permission. \n" +
                                "4. If your contactless payment card or contactless enabled smart phone is lost or stolen, report this to your bank immediately and you should be covered for any subsequent losses.\n" +
                                "5. Shield your PIN from criminal cameras or prying eyes. Stand close to the cash machine and cover the keypad with your purse, wallet or spare hand.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 6:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("In case somebody has misused your potential in the lieu of a fake job, you better complain about them. It would be the most helpful.", noOptions);
                    newChatbotMessage("Would you like to see how?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. Look up the name of the company or the person who’s hiring you, plus the words “scam,” “review,” or “complaint.” You might find out they’ve scammed other people.\n" +
                                "2. With services such as Truecaller, you can find out the exact details of who is calling, unless a fake number is being used. Then, LinkedIn is the place to track down professionals and see if he actually belongs to his mentioned company.\n" +
                                "3. Talk to someone you trust. Describe the offer to them. What do they think? This also helps give you vital time to think about the offer. Check twice if the offer’s ‘too good’  \n" +
                                "4. Don't pay for the promise of a job. No job offer requires ‘pre-payment’  \n" +
                                "5. Telephonic interviews should ideally be followed up with a face-to-face interview as it gives the aspirant a clear view of the company.", noOptions);
                        newChatbotMessage("You could also check if the company is legal or not. Do you want to see how?", YesNoOptions);
                    }

                    basicSugState++;
                } else if (basicSugState == 2) {
                    if (funYes(uinput)) {
                        newChatbotMessage("Any registered job consultancy will have a CIN certificate ideally put up inside, usually at the reception in the form of a photo frame.", noOptions);
                        newChatbotMessage("The certificate will have a CIN number. Note it down it can be checked against CIN database on MCA government website.", noOptions);
                        newChatbotMessage("Check if the company exists on the website of <a href=\"http://www.mca.gov.in/mcafoportal/findCIN.do\">Ministry Of Corporate Affairs</a>", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 7:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("In case somebody has conned you in the name of love, you better complain about them. It would be the most helpful.", noOptions);
                    newChatbotMessage("Would you like to see how?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. We suggest you create a new email ID when you make your profile on a matrimony platform.\n" +
                                "2. Ask frequent questions, it will help you to find out that if the person is hiding something or catch lies if any.\n" +
                                "3. In case you meet anyone online starts enquiring about your money or property and starts demanding money, cut off all the communication with them immediately.\n" +
                                "4. Please commit to marriage only after face-to-face meetings, especially after meeting prospective groom or bride's parents/relatives. \n" +
                                "5. While meeting prospects, it is recommended that you meet in safe public places. This way you can avoid getting into any kind of trouble. Always keep your family or friends informed of your meetings with prospects.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 8:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("In case somebody has fooled you by fake offers and coupons, you better complain about them. It would be the most helpful.", noOptions);
                    newChatbotMessage("Would you like to see how?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. It's the only website with that great deal. If most websites offer a code for 10% off, a 75% off offer is likely a scam.\n" +
                                "2. Be wary of all high value offers. A promo for a Rs. 50000 gift card is nearly always fake.\n" +
                                "3. Look for legal language and expiration dates. Online coupons need to match manufacturer requirements. \n" +
                                "4. Never pay for coupons. Don't be tricked into paying for something that's actually free.\n" +
                                "5. Watch for \"bait and switch\" tactics. This scam offers you online coupon codes and, once you agree, requires you fill in a form with personal information.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 9:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newDebugMessage("Basic Suggestions for Ordering Product are COMING SOON");

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 10:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("It looks like your photo has been morphed. Do you want to see how to request the removal of the photo from a website?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        newChatbotMessage("Step 1: Find the contact details of the site where the photo has been uploaded. ", noOptions);

                        options = new ArrayList<String>(Arrays.asList("I know how to do that", "Please guide me"));
                        newChatbotMessage("Do you know how to do that or do you want us to guide you how to obtain that?", options);

                        basicSugState++;
                    } else {
                        newChatbotMessage("Here are some suggestions about how to avoid these situations in the future.\n" +
                                "1. Define strict privacy for your profile. Make your account private by changing the settings.\n" +
                                "2. Don’t add strangers to your profile. If we don’t know someone personally, we should not have any interaction neither in reality nor in the virtual world.\n" +
                                "3. When you access social media from any device, ensure that you turn off the location. The apps sometimes access your device location and when you share an update it fetches the data and might show up on the app. \n" +
                                "4. Avoid using hash tags. If you too use hash tags on your post you will be visible on the internet. If you avoid using hash tags, it will make you less prone to the attacks that could destroy your reputation.", noOptions);

                        cyberCrimeID++;
                        basicSugState = 0;

                        basicSuggestions("null");
                    }
                } else if (basicSugState == 2) {
                    if (uinput.equals("please guide me")) {
                        newChatbotMessage("There are three ways to find the contact details.", noOptions);
                        newChatbotMessage("<b>First</b>, have a look in the menu or in the page’s footer (the bottom of the page) for a ‘Contact Us’ link.\n" +
                                "<b>Second</b>, try Googling “Website Address” Contact Email – *make sure to use the quotation marks too*\n" +
                                "<b>Third</b>, open an <a href=\"https://www.whois.com/whois/\">IP and Domain Search</a> and type in the website address. It’ll spit out all of the details of who registered that website and if you’re lucky, you’ll now have their telephone number, email address and even registered address.", noOptions);
                    }
                    // else if(uinput.equals("i know how to do that")) {
                    //
                    // }
                    newChatbotMessage("Step 2: Make sure you take screenshots or photos of the unauthorized use. This way you have the evidence should they take your photo down after you make contact.", noOptions);
                    newChatbotMessage("Did you get a chance to record it?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 3) {
                    if (funYes(uinput)) {
                        newChatbotMessage("Step 3: Now you can make contact! Write them an email. You need to show you mean business and explain the matter to them.", noOptions);
                    } else {
                        newChatbotMessage("You can also view cached (old) versions of web pages with Google should the photo already be offline. Here is how to do that:\n" +
                                "a. On your computer, do a Google search for the page you want to find.\n" +
                                "b. In search results, next to the site's URL, click down arrow Down arrow or More and then Cached.", noOptions);
                        newChatbotMessage("Once you record it, Step 3: Now you can make contact! Write them an email. You need to show you mean business and explain the matter to them.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 11:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("Your past seems to be meddling with your present. Do you want to see what to do if the photo has been shared or threatened to be shared?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        options = new ArrayList<>(Arrays.asList("Already Shared", "Just Threatened"));
                        newChatbotMessage("Has the content already been shared yet, or it has just been threatened?", options);

                        basicSugState++;
                    } else {
                        newChatbotMessage("Here are some suggestions about how to avoid these situations in the future.\n" +
                                "1. Do not delete the message. These messages are a very important source of evidence. By deleting these messages, you are destroying evidence.\n" +
                                "2. Take a screen shot. Often the accused uses fake accounts to blackmail the victim. It is best to take a screenshot as soon as you receive such messages. These screenshots are also helpful when filing complaints or gathering preliminary data for investigation. \n" +
                                "3. Do not give in to the blackmailer’s demand. No matter what the blackmailer says, do not give in to his demands because there is no assurance that he will stop.", noOptions);

                        cyberCrimeID++;
                        basicSugState = 0;

                        basicSuggestions("null");
                    }
                } else if (basicSugState == 2) {
                    if (uinput.equals("already shared")) {
                        newChatbotMessage("These are the following there are things that you can do. \n" +
                                "1. If you have a copy of the content - then you may be able to block it being shared on some platforms by working with them in advance. \n" +
                                "2. Review your social media privacy settings and friends lists - remove any ‘friends’ who you do not know well and could be the perpetrator.\n" +
                                "3. <a href=\"https://support.google.com/websearch/answer/4815696?hl=en\">Setting up monitoring</a> - setting up Google Alerts with your name may be a good way to spot if the content is shared online.", noOptions);
                    } else {
                        newChatbotMessage("Remember something. While the information is online, please try not to monitor the comments and feedback. This will cause more distress.  You could try the following:\n" +
                                "1. Keep a copy of the evidence - It is important to document what was shared, where it was shared, when it was shared and who shared it (from what accounts or username). \n" +
                                "2. Don’t engage with the suspect - If you know who is likely to have shared the content it is best not to engage with them directly and try to get them to remove the content. This can escalate the issue. \n" +
                                "3. Review your online security and privacy settings. Go to privacy settings and set your privacy as high as you can. ", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 12:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("Things escalate quickly from kiss blowing emojis to conversations that are more intimate while texting. ", noOptions);
                    newChatbotMessage("Have you been receiving abusive/offensive/vulgar WhatsApp messages?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        newChatbotMessage("Please send screenshots of the message along with the mobile numbers at <a href=\"mailto:ccaddn-dot@nic.in\">ccaddn-dot@nic.in</a>", noOptions);
                    } else {
                        newChatbotMessage("Here are some suggestions about how to avoid these situations in the future.\n" +
                                "1. The no-face rule. It's best to avoid sending a picture even to your husband. But if you have to, make sure you crop the face. In case of a photo leak, your identity will not be revealed.\n" +
                                "2. Use Snapchat. This app sets a timer to your pictures so they exist only for a few seconds.\n" +
                                "3. Stranger is danger. Casually flirting with the guy is okay but think thrice before sending any pics!\n" +
                                "4. Hit delete. You never know who is snooping around, so delete all kinds of intimate communication between you and your partner, and advise him to do so as well.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 13:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("In case somebody has misused your potential in the lieu of a fake travel offer, you better complain about them. It would be the most helpful.", noOptions);
                    newChatbotMessage("Would you like to see how?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. Where possible pay for holidays and travel using either a credit card or the third-party payment to give you additional financial protection.\n" +
                                "2. Research any property before you book, look if it is advertised elsewhere or has its own website. Be extremely cautious if the prices are significantly different.\n" +
                                "3. Don’t be convinced by photos, they may have been taken from somewhere else on the internet. You can check photos using a reverse image search on the sites like <a href=\"https://www.tineye.com/\">TinEye</a> or <a href=\"https://reverse.photos/\">Reverse Image Search by Google</a>\n" +
                                "4. Be suspicious of requests to pay by bank transfer\n" +
                                "5. Be wary of paying for tickets where you are told someone will meet you at the event with your tickets, they may not arrive", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 14:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("If you’re being bullied via a website, chances are that the bully is going against the website’s terms of use. Reporting bullies may be an option you could explore.", noOptions);
                    newChatbotMessage("Would you like to explore them?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions that might help: \n" +
                                "1. Don’t respond or retaliate. Sometimes a reaction is exactly what aggressors are looking for because they think it gives them power over you. \n" +
                                "2. Save the evidence. The only good news about bullying online or on phones is that it can usually be captured and saved. \n" +
                                "3. Use the available technology and whether the harassment’s in an app, texting, comments or tagged photos, do yourself a favor and block the person. \n" +
                                "4. DO NOT Forward bullying content or messages. It only expands the problem. You never know how far an email chain can go.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 15:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newDebugMessage("Basic Suggestions for Trolling and dissing are COMING SOON");

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            case 16:
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("The latest step to stop the spreading of abusive messages and threats, WhatsApp has joined hands with the Department of Telecom (DoT).", noOptions);
                    newChatbotMessage("Do you have screenshots of the messages or can you take them now for record?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        newChatbotMessage("The victim just needs to furnish a screenshot of the message along with the mobile number and <a href=\"mailto:ccaddn-dot@nic.in\">e-mail it to ccaddn-dot@nic.in</a>", noOptions);
                    }

                    newChatbotMessage("Ideally, you should also explore all your other options in our Legal Aid section. Do you want to explore?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 2) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        newChatbotMessage("Here are a few suggestions to prevent it in the future:\n" +
                                "1. You may want to document the harassment because sometimes you may be the only person to have access to it, because depending on how the harassing messages occur or the technology platform in which it took place, the messages may be deleted and not retrievable later on like on SnapChat.\n" +
                                "2. Block the abusive person from contacting you. One of the strategies can be to block the abusive person from contacting you. Test the blocking feature with someone you trust to see how it works.\n" +
                                "3. In some cases, you may decide to just get a new phone number or social media account. This option is best if you want to cut off all ties and want no communication with the abusive person, and you don’t think the abusive person will learn about the new phone number or social media account.", noOptions);
                    }

                    cyberCrimeID++;
                    basicSugState = 0;

                    basicSuggestions("null");
                }
                break;
            default:
                // should we really start legal aid here?
                uinput = uinput.toLowerCase();
                if (basicSugState == 0) {
                    newChatbotMessage("Do you want to get Legal Aid?", YesNoOptions);

                    basicSugState++;
                } else if (basicSugState == 1) {
                    if (funYes(uinput)) {
                        wrtGui = 0;
                        startLegalAid();
                    } else {
                        FriendlyMessage friendlyMessage1 = new FriendlyMessage("Pursuing the case legally is upto you. But I recommend you to take a look at the Legal Aid section. You could take a look at the support I provide.", "SAKHA", null);
                        mMessageAdapter.add(friendlyMessage1);
                        mMessageAdapter.notifyDataSetChanged();
                    }

                    // cyberCrimeID++;
                    basicSugState = 0;

                    // basicSuggestions("null");
                }
                break;
        }

    }

    void newChatbotMessage(String message, ArrayList<String> options) {
        if (wrtGui == 1) {
            while (options.size() < 8) {
                options.add("null");
            }

            FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
            chatbotMsg.setOpt1(options.get(0));
            chatbotMsg.setOpt2(options.get(1));
            chatbotMsg.setOpt3(options.get(2));
            chatbotMsg.setOpt4(options.get(3));
            chatbotMsg.setOpt5(options.get(4));
            chatbotMsg.setOpt6(options.get(5));
            chatbotMsg.setOpt7(options.get(6));
            chatbotMsg.setOpt8(options.get(7));

            wrtGui = 1;

            mMessageAdapter.add(chatbotMsg);
            mMessageAdapter.notifyDataSetChanged();
        }
    }

    static void newDebugMessage(String message) {
        FriendlyMessage debugMsg = new FriendlyMessage(message, "debug", null);
        mMessageAdapter.add(debugMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    public boolean funYes(String temp) {
        String[] list_yes = {
                "yes",
                "yup",
                "yes i think so",
                "i think so",
                "fairly certain",
                "affirmative",
                "amen",
                "fine",
                "good",
                "okay",
                "true",
                "yea",
                "all right",
                "alright",
                "by all means",
                "aye",
                "beyond a doubt",
                "by all means",
                "certainly",
                "definitely",
                "sure",
                "exactly",
                "gladly",
                "good enough",
                "granted",
                "indubitably",
                "just so",
                "most assuredly",
                "naturally",
                "of course",
                "positively",
                "precisely",
                "sure thing",
                "surely",
                "undoubtedly",
                "unquestionably",
                "very well",
                "willingly",
                "without fail",
                "yep",
                "yeah"
        };

        String[] list_no = {
                "no",
                "no i dont think so",
                "certainly not",
                "by no means",
                "of course not",
                "not really",
                "on no account",
                "not on any account",
                "not likely",
                "hardly",
                "no way",
                "not"
        };

        temp = temp.toLowerCase();
        String temp_new = "";
        for (int i = 0; i < temp.length(); i++) {
            Character ch = temp.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == ' ') {
                temp_new += ch;
            } else {
                temp_new += " ";
            }
        }

        temp_new = temp_new.toLowerCase();
        for (String str : list_yes) {
            if (temp_new.contains(str)) {
                return true;
            }
        }

        for (String str : list_no) {
            if (temp_new.contains(str)) {
                return false;
            }
        }
        return false;
    }

    private void showPaidFeatureAlert() {

        AlertDialog premiumFeatDialog = new AlertDialog.Builder(this).create();

        premiumFeatDialog.setTitle("Purchase Licence");
        premiumFeatDialog.setMessage("Sorry, this is a premium feature. Please purchase a license to use this feature");
        premiumFeatDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Okay", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.v("utk", "alert button onclicklistener");
                mSendButton.performClick();
            }
        });

        premiumFeatDialog.show();
    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}