package com.google.firebase.quickstart.auth.java;

public class UserInfo {
    //    profileMap.put("device_token",deviceToken);
//                    profileMap.put("uid",currentUserId);
//                    profileMap.put("name",Username);
//                    profileMap.put("phone_number",PhoneNo);
//                    profileMap.put("address",Address);
    // private String device_token;
    private String uid;
    private String username;
    private String phone_number;
    private String address;
    private String firstname;
    private String lastname;
//    private String religion;

    public UserInfo() {
        // this.device_token="NULL";
        this.uid = "NULL";
        this.username = "abc";
        this.phone_number = "00";
        this.address = "NULL";
        this.firstname = "NULL";
        this.lastname = "NULL";
//        this.religion="NULL";
    }

    public UserInfo(String uid, String username, String firstname, String lastname, String phone_number, String address) {
        // this.device_token=device_token;
        this.uid = uid;
        this.username = username;
        this.phone_number = phone_number;
        this.address = address;
        this.firstname = firstname;
        this.lastname = lastname;
//        this.religion=religion;
    }

    public String getUid() {
        return uid;
    }

    public String getAddress() {
        return address;
    }

    // public String getDevice_token() {
    //     return device_token;
    // }

    public String getName() {
        return username;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setAddress(String address) {
        this.address = address;
    }

//    public void setDevice_token(String device_token) {
//        this.device_token = device_token;
//    }

    public void setName(String name) {
        this.username = name;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

//    public String getReligion() {
//        return religion;
//    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

//    public void setReligion(String religion) {
//        this.religion = religion;
//    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "uid='" + uid + '\'' +
                ", username='" + username + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", address='" + address + '\'' +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                '}';
    }
}