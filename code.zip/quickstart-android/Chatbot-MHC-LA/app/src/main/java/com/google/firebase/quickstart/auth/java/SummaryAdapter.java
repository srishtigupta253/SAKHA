package com.google.firebase.quickstart.auth.java;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SummaryAdapter extends ArrayAdapter<Summary> {
    private Context context;

    public SummaryAdapter(Context context, int resource, List<Summary> objects) {
        super(context, resource, objects);
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.item_summary, parent, false);
        }

        LinearLayout summItemLayout = convertView.findViewById(R.id.summItemLayout);
        TextView useridTextView = convertView.findViewById(R.id.useridTextView);
        TextView dassTextView = convertView.findViewById(R.id.dassTextView);
        TextView summaryTextview = convertView.findViewById(R.id.summaryTextview);
        // ImageButton openSummaryButton = convertView.findViewById(R.id.openSummaryButton);

        Summary summary = getItem(position);
        // uid,age,dass,cybercrimes
        useridTextView.setText(Html.fromHtml("<b>UID</b>: "+summary.getInfo().getUid().substring(0,4)+"..., "+summary.getIntro().getAge()+" years"));
        dassTextView.setText(Html.fromHtml("<b>DASS</b>: "+summary.getDassScreeningResult().getDepression_result()+", "+summary.getDassScreeningResult().getAnxiety_result()+", "+summary.getDassScreeningResult().getStress_result()));
        summaryTextview.setText(Html.fromHtml("<b>Cybercrimes</b>: "+summary.getCybercrimes_detected()));

        AlertDialog diaBox = AskOption(summary);

        // AdminSummaryDisplay.summary = getItem(position);
        summItemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("SummaryAdapter:","Summary = "+summary.getHealth_Councelling_Summary());

                Intent intent = new Intent(context, AdminSummaryDisplay.class);
                intent.putExtra("uid_str",summary.getInfo().getUid());
                intent.putExtra("age_str", summary.getIntro().getAge());
                intent.putExtra("address_str", summary.getInfo().getAddress());
                intent.putExtra("depression_str", summary.getDassScreeningResult().getDepression_result());
                intent.putExtra("anxiety_str", summary.getDassScreeningResult().getAnxiety_result());
                intent.putExtra("stress_str", summary.getDassScreeningResult().getStress_result());
                intent.putExtra("cybercrimes_str", summary.getCybercrimes_detected());
                intent.putExtra("summary_str", summary.getHealth_Councelling_Summary());
                // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                v.getContext().startActivity(intent);

                // Toast.makeText(getContext(),"opening summary: "+summary.getInfo().getUid(),Toast.LENGTH_SHORT).show();
                // diaBox.show();
            }
        });

        return convertView;
    }

    private AlertDialog AskOption(Summary summary) {
        AlertDialog alertDialog = null;
        alertDialog = new AlertDialog.Builder(this.getContext())
            // set message, title, and icon
            .setTitle("Summary of User "+summary.getInfo().getUid())
            .setMessage(
                    Html.fromHtml(
                            "<b>Age:</b> "+summary.getIntro().getAge()
                                    +"<br><b>Address:</b> "+summary.getInfo().getAddress()
                                    +"<br><b>Depression:</b> "+summary.getDassScreeningResult().getDepression_result()
                                    +"<br><b>Anxiety:</b> "+summary.getDassScreeningResult().getAnxiety_result()+
                                    "<br><b>Stress:</b> "+summary.getDassScreeningResult().getStress_result()+
                                    "<br><b>Cybercrimes:</b> "+summary.getCybercrimes_detected()
                    )
            )
            // .setIcon(android.R.drawable.menu_frame)
            .setNegativeButton("BACK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            })
            .create();

        return alertDialog;
    }
}
