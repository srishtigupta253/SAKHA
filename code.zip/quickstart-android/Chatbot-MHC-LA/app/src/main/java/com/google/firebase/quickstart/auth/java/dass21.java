
package com.google.firebase.quickstart.auth.java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
//import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.MY_SOCKET_TIMEOUT_MS;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.emotionApiRes;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.LifeStyleActivity.newDebugMessage;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.isFromOptionalQues;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.ObjCyber;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.ObjFamily;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.ObjSociety;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.ObjStudy;
import static com.google.firebase.quickstart.auth.java.RootCauseActivity.ObjWork;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.LegalAid.intentAPI;
// import static com.google.firebase.quickstart.auth.java.SuspectActivity.getNumSummaries;
import static com.google.firebase.quickstart.auth.java.SuspectActivity.numSummaries;

public class dass21 extends AppCompatActivity {

    private static final String TAG = "Dass21";

    // public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mMessageListView;
    //public static MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    //private EditText mMessageEditText;
    // private Button mSendButton;
    // public static String mUsername=ANONYMOUS;
    public String mUsername = "null";
    public int depression_score, anxiety_score, stress_score;
    public static String depression_result, anxiety_result, stress_result;
    public static int df = 0, af = 0, sf = 0;
    public char ch = '0';

    //flag variables
    public int introVar = 0;
    public int endActivity = 0;
    public int endQues = 0;
    public int wrtGui = 1;

    //creating class objects for storing data as firebase json object
    public static UserDass21 dassmap = new UserDass21();
    public static UserRootCause rootmap = new UserRootCause();

    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<String>(Arrays.asList("Yes", "No"));

    public static boolean isSummary = false;
    public static boolean isLegalAid = false;
    public static boolean isSendSummary = false;
    public static boolean isFromMHC = false;
    public static boolean isFromLA = false;
    public static boolean isSecondVisit = false;
    public static boolean isSecondDassVisit = false;

    FirebaseAuth firebaseAuth; // for firebase authentication
    private FirebaseDatabase mFirebaseDatabase; // for firebase realtime database access
    private DatabaseReference mMessageDatabaseReference; // firebase reference for reaching the desired position in database


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dass21);
        depression_score = 0;
        anxiety_score = 0;
        stress_score = 0;
        depression_result = anxiety_result = stress_result = "null";
        if (isSecondDassVisit) {
            endActivity = 2; //skip to summary
            depression_result = SecondVisitActivity.dassmap.getDepression_result();
            anxiety_result = SecondVisitActivity.dassmap.getAnxiety_result();
            stress_result = SecondVisitActivity.dassmap.getStress_result();
            introVar = 21;
            Log.d("UTK","This should only appear if this is second Dass visit");
        }


        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");

        mUsername = isSecondVisit ? SecondVisitActivity.uName : IntroActivity.mUsername;

        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
        //    mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                introVar += 1;
                ch = temp.charAt(0);
                if (ch == '0' || ch == '1' || ch == '2' || ch == '3') {
                    introFun(Character.toString(ch));

                } else {
                    temp = slangCheck(temp);

                    introFun(temp);
                }


            }
        });

//        Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//        startActivity(ii);

        // numSummaries = getNumSummaries();

        Log.d("UTK", "dass scores before dass activity : " + depression_result + stress_result + anxiety_result);

        if (isSecondDassVisit)
            intromid();
        else
            introStart();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }


    // functions for printing rules for dass 21 questions
    public void introStart() {
        String temp;
        temp = mUsername + ", Please read each statement and select a number 0, 1, 2 or 3 which indicates how much the statement applied to you over the past week.( There are no right or wrong answers. Do not spend too much time on any statement.)";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        temp = "!!!!! Lets Start !!!!!!";
        FriendlyMessage friendlyMessage6 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage6);
        mMessageAdapter.notifyDataSetChanged();
        temp = "I found it hard to wind down.";
        FriendlyMessage friendlyMessage5 = new FriendlyMessage(temp, "SAKHA", null);
        friendlyMessage5.setOpt1("0 : Did not apply to me at all ");
        friendlyMessage5.setOpt2("1 : Applied to me to some degree or some of the time ");
        friendlyMessage5.setOpt3("2 : Applied to me to a considerable or a good part of the time");
        friendlyMessage5.setOpt4("3 : Applied to me very much or most of the time");
        mMessageAdapter.add(friendlyMessage5);
        mMessageAdapter.notifyDataSetChanged();

    }

    public void intromid() {
        String mm = "So far, we have found out a few details about you. Would you like to see a summary of it? ";
        FriendlyMessage friendlyMessageq = new FriendlyMessage(mm, "SAKHA", null);
        friendlyMessageq.setOpt1("Yes, I want to see Summary");
        friendlyMessageq.setOpt2("No, Summary is not necessary");
        mMessageAdapter.add(friendlyMessageq);
        mMessageAdapter.notifyDataSetChanged();
    }

    // functions for asking questions for dass 21
    public void introFun(String uinput) {
        String temp = "empty";

        switch (introVar) {
            case 1:
                stress_score = stress_score + retInt(uinput);//s1
                temp = "I was aware of dryness of my mouth.";
                break;
            case 2:
                anxiety_score = anxiety_score + retInt(uinput);//a1
                temp = "I could not seem to experience any positive feeling at all.";
                break;
            case 3:
                depression_score = depression_score + retInt(uinput);//d1
                temp = "I experienced breathing difficulty (eg, excessively rapid breathing, breathlessness in the absence of physical exertion)";
                break;
            case 4:
                anxiety_score = anxiety_score + retInt(uinput);//a2
                temp = "I found it difficult to work up the initiative to do things";
                break;
            case 5:
                depression_score = depression_score + retInt(uinput);//d2
                temp = "I tended to over-react to situations";
                break;
            case 6:
                stress_score = stress_score + retInt(uinput);//s2
                temp = "I experienced trembling (eg, in the hands)";
                break;
            case 7:
                anxiety_score = anxiety_score + retInt(uinput);//a3
                temp = "I felt that I was using a lot of nervous energy";
                break;
            case 8:
                stress_score = stress_score + retInt(uinput);//s3
                temp = "I was worried about situations in which I might panic and make a fool of myself";
                break;
            case 9:
                anxiety_score = anxiety_score + retInt(uinput);//a4
                temp = "I felt that I had nothing to look forward to";
                break;
            case 10:
                depression_score = depression_score + retInt(uinput);//d3
                temp = "I found myself getting agitated";
                break;
            case 11:
                stress_score = stress_score + retInt(uinput);//s4
                temp = "I found it difficult to relax";
                break;
            case 12:
                stress_score = stress_score + retInt(uinput);//s5
                temp = "I felt down-hearted and blue";
                break;
            case 13:
                depression_score = depression_score + retInt(uinput);//d4
                temp = "I was intolerant of anything that kept me from getting on with what I was doing";
                break;
            case 14:
                stress_score = stress_score + retInt(uinput);//s6
                temp = "I felt I was close to panic";
                break;
            case 15:
                anxiety_score = anxiety_score + retInt(uinput);//a5
                temp = "I was unable to become enthusiastic about anything";
                break;
            case 16:
                depression_score = depression_score + retInt(uinput);//d5
                temp = "I felt I wasn’t worth much as a person";
                break;
            case 17:
                depression_score = depression_score + retInt(uinput);//d6
                temp = "I felt that I was rather touchy";
                break;
            case 18:
                stress_score = stress_score + retInt(uinput);//s7
                temp = "I was aware of the action of my heart in the absence of physical exertion (e.g. sense of heart rate increase, heart missing a beat)";
                break;
            case 19:
                anxiety_score = anxiety_score + retInt(uinput);//a6
                temp = "I felt scared without any good reason";
                break;
            case 20:
                anxiety_score = anxiety_score + retInt(uinput);//a7
                temp = "I felt that life was meaningless";
                break;
            case 21:
                depression_score = depression_score + retInt(uinput);//d7
                temp = "done";
                endActivity = 1;
                if (isSecondVisit)
                    endActivity = 3;
                break;
            case 22:
                endActivity = 2;
                if (isSecondVisit) {
                    if (funYes(uinput)) {
                        // call MentalHealthActivity
                        Log.d("UTK", "dass scores before 2nd second time: " + depression_result + stress_result + anxiety_result);


                        isSecondVisit = true;
                        isSecondDassVisit = true;
                        SecondVisitActivity.dassmap.setAnxiety_result(anxiety_result);
                        SecondVisitActivity.dassmap.setDepression_result(depression_result);
                        SecondVisitActivity.dassmap.setStress_result(stress_result);

                        IntroActivity.introMap = SecondVisitActivity.introMap;
                        Intent i = new Intent(getApplicationContext(), MentalHealthActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        FriendlyMessage friendlyMessage1 = new FriendlyMessage("Thank for using this app. I hope I served you well. For pursuing this case legally, you could take a look at the Legal Aid section.", "SAKHA", null);
                        mMessageAdapter.add(friendlyMessage1);
                        mMessageAdapter.notifyDataSetChanged();
                    }
                    return;
                }
                break;
            default:
                temp = "dassSwitchdefault";

        }

        if (endActivity != 1 && endActivity != 2 && endActivity != 3) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
            friendlyMessage.setOpt1("0 : Did not apply to me at all ");
            friendlyMessage.setOpt2("1 : Applied to me to some degree or some of the time ");
            friendlyMessage.setOpt3("2 : Applied to me to a considerable or a good part of the time");
            friendlyMessage.setOpt4("3 : Applied to me very much or most of the time");
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        } else if (endActivity == 3) {//second visit
            evaluation();
            secondVisitFinish();

        } else if (endActivity == 1) {
            evaluation();
            Log.d("UTK", "dass scores summary : " + depression_result + stress_result + anxiety_result);

            intromid();

        } else {


            // funRootCauseSummaryUpdate();
            // dassmap.setAnxiety_result(anxiety_result);
            // dassmap.setDepression_result(depression_result);
            // dassmap.setStress_result(stress_result);
            //
            // newDebugMessage("add dass21 to summary");
            // Summary+="Dass 21 results are "+anxiety_result+" anxiety, "+depression_result+" depression, "+stress_result+" stress.";
            // rootmap.setFinal_cause(ObjCyber.finalCause);
            // rootmap.setSphere_detected("cyber");
            //
            //
            // updateToFirebase();
            // updateToFirebase2();
            // updateToFirebase3();
//            if(df==0 || sf==0 || af==0)
//            {
//                String temp2="Your condition is completely normal";
//                FriendlyMessage friendlyMessage = new FriendlyMessage(temp2, "SAKHA", null);
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
//            }
//            else if(df==2 || sf==2 || af==2)
//            {
//                String temp1="You condition looks severe please consult a doctor";
//                FriendlyMessage friendlyMessage = new FriendlyMessage(temp1, "SAKHA", null);
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
//            }
//            else
//            {
//                if(df==1)
//                    depression_suggestion();
//                if(af==1)
//                    anxiety_suggestion();
//                if(sf==1)
//                    stress_suggestion();
//            }

            // if (isSummary) {
            //     Intent ii = new Intent(getApplicationContext(), SummaryDisplay.class);
            //     startActivity(ii);
            // }
            //temp = "Error !!!";

            String question = "null";
            FriendlyMessage friendlyMessageq = new FriendlyMessage(question, "SAKHA", null);
            switch (endQues) {
                case 0:
                    funRootCauseSummaryUpdate();
                    dassmap.setAnxiety_result(anxiety_result);
                    dassmap.setDepression_result(depression_result);
                    dassmap.setStress_result(stress_result);

                    // newDebugMessage("add dass21 to summary");
                    Summary += "Dass21 results are " + anxiety_result + " anxiety, " + depression_result + " depression, " + stress_result + " stress. ";
//                    Summary += "Dass21 scores are: depression=" + df + ", anxiety=" + af + ", stress=" + sf + ". ";
                    rootmap.setFinal_cause(ObjCyber.finalCause);
                    rootmap.setSphere_detected("cyber");

                    updateToFirebase();
                    updateToFirebase2();
                    updateToFirebase3();

                    if (isSummary) {
                        isSummary = false;
                        Intent ii = new Intent(getApplicationContext(), SummaryDisplay.class);
                        startActivity(ii);
                    }
                    // ask user to permit sending summary
                    friendlyMessageq.setText("Do you wish to share your info with a nearby legal/mental help via WhatsApp?");
                    friendlyMessageq.setOpt1("Yes, I am fine with sharing my info.");
                    friendlyMessageq.setOpt2("No, I don't want to share my info.");
                    mMessageAdapter.add(friendlyMessageq);
                    mMessageAdapter.notifyDataSetChanged();
                    endQues++;
                    break;
                case 1:
                    if (isSendSummary) {
                        //reset the variable
                        isSendSummary = false;

                        // send the summary via whatsapp
                        sendSummary();
                    }

                    // friendlyMessageq.setText("Do you wish to get Legal Aid as well?");
                    // friendlyMessageq.setOpt1("Yes, I would like to get a Legal Aid as well.");
                    // friendlyMessageq.setOpt2("No, I don't need a Legal Aid now.");

                    newChatbotMessage("<b>For your mental well-being, you could do the following:</b>", noOptions);
                    dass_suggestions();
                    emotionSuggestions();

                    // if ((df == 0 && sf == 0 && af == 0) || depression_result.equalsIgnoreCase("mild")) {
                    //     String temp3 = "Your condition is completely normal. ";
                    //     if(funYes(lifeMap.getPhysical_activity())) {
                    //         if(lifeMap.getPhysical_activity_regular().equalsIgnoreCase("everyday")) {
                    //             temp3 += "But continue doing "+lifeMap.getPhysical_activity_type()+". ";
                    //         } else {
                    //             temp3 += "I would advise you to do "+lifeMap.getPhysical_activity_type()+" more frequently.";
                    //         }
                    //     }
                    //     newChatbotMessage(temp3,noOptions);
                    // } else {//if (df == 2 || sf == 2 || af == 2) {
                    //     if (depression_result.equalsIgnoreCase("Extremely Severe") || anxiety_result.equalsIgnoreCase("Extremely Severe") || stress_result.equalsIgnoreCase("Extremely Severe")) {
                    //         String temp1 = "You condition is Extremely Severe. PLEASE VISIT A COUNSELLOR AS SOON AS POSSIBLE";
                    //         FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp1, "SAKHA", null);
                    //         mMessageAdapter.add(friendlyMessage2);
                    //         mMessageAdapter.notifyDataSetChanged();
                    //     } else {
                    //         // if (depression_result.equalsIgnoreCase("severe")) {
                    //         //     String temp3 = "1. Set goals. When you're depressed, you may feel like you can't accomplish anything. That makes you feel worse about yourself. To push back, set daily goals for yourself.\n" +
                    //         //             "2. Do something new. When you’re depressed, you’re in a rut. Push yourself to do something different. Go to a museum. Pick up a used book and read it on a park bench. Take a language class.";
                    //         //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
                    //         //     mMessageAdapter.add(friendlyMessage2);
                    //         //     mMessageAdapter.notifyDataSetChanged();
                    //         // }
                    //         // if (anxiety_result.equalsIgnoreCase("severe")) {
                    //         //     String temp3 = "1. Stop or limit how much caffeine you consume, including coffee, tea, cola and chocolate\n" +
                    //         //             "2. Join support groups. These groups are available in-person and online. They encourage people with anxiety disorders to share their experiences and coping strategies.";
                    //         //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
                    //         //     mMessageAdapter.add(friendlyMessage2);
                    //         //     mMessageAdapter.notifyDataSetChanged();
                    //         // }
                    //         // if (stress_result.equalsIgnoreCase("severe")) {
                    //         //     String temp3 = "1. Lightening up can help diffuse tension. Use humor to help you face what's making you angry and, possibly, any unrealistic expectations you have for how things should go.\n" +
                    //         //             "2. When your temper flares, put relaxation skills to work. Practice deep-breathing exercises, imagine a relaxing scene, or repeat a calming word or phrase, such as \"Take it easy.\"";
                    //         //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
                    //         //     mMessageAdapter.add(friendlyMessage2);
                    //         //     mMessageAdapter.notifyDataSetChanged();
                    //         // }
                    //
                    //         if ( depression_result.equalsIgnoreCase("severe") || depression_result.equalsIgnoreCase("moderate") || anxiety_result.equalsIgnoreCase("severe") || anxiety_result.equalsIgnoreCase("moderate") || stress_result.equalsIgnoreCase("severe") || stress_result.equalsIgnoreCase("moderate") ) {
                    //             newChatbotMessage("I hear your pain and am sorry that you are having a tough time. You're not alone. I care and others do, too. Please know you've been heard. \n" +                           "How about focussing on relaxing you first",noOptions);
                    //             newChatbotMessage("Try taking 5 deep breath. Just inhale till 5 counts, hold your breath for 4 counts and exhale till 5 counts.",noOptions);
                    //             newChatbotMessage("Hope you are feeling bit relaxed now. You can practice this exercise daily for 5-10 minutes in the morning. This will help you relax.",noOptions);
                    //             newChatbotMessage("If you feel like crying, then cry. I won't judge you.",noOptions);
                    //             newChatbotMessage("You can't keep your true emotions hidden forever. Coke bottle theory. Write down the impeding doom and burn it. Literally. Burn it up in the fireplace. Or flush it down the toilet. Then turn on some music and sing as loud and as badly as you can. Or look up cute pictures. Funny youtube videos. Take a bath. Squeeze a pillow as hard as you can. Squeeze a ballon until it pops. True, these won't make it go away, but it will help you get through this. And this won't last forever.",noOptions);
                    //             newChatbotMessage("These problems are treatable, Getting the right medicines and enough sleep may help you a lot. Also take time off if you can to find something enjoyable that you can look forward to. Feel better!",noOptions);
                    //             newChatbotMessage("Things will be fine, just take care of yourself and focus on all the positive things in life. Take care.", noOptions);
                    //         }
                    //     }
                    // }
                    // else {
                    //     if (df == 1)
                    //         depression_suggestion();
                    //     if (af == 1)
                    //         anxiety_suggestion();
                    //     if (sf == 1)
                    //         stress_suggestion();
                    // }


                    friendlyMessageq.setText("Would you like to know some suggestions that I might have to help you?");
                    friendlyMessageq.setOpt1("Yes");
                    friendlyMessageq.setOpt2("No");

                    mMessageAdapter.add(friendlyMessageq);
                    mMessageAdapter.notifyDataSetChanged();
                    endQues++;
                    break;
                case 2:
                    // open SuggestionsActivity.java
                    if (funYes(uinput)) {
                        endActivity++;

                        // should I call a new Intent?
                        isFromMHC = true;
                        Intent iii = new Intent(getApplicationContext(), SuggestionsActivity.class);
                        startActivity(iii);
                    } else {
                        FriendlyMessage friendlyMessage1 = new FriendlyMessage("Thank for using this app. I hope I served you well. For pursuing this case legally, you could take a look at the Legal Aid section.", "SAKHA", null);
                        mMessageAdapter.add(friendlyMessage1);
                        mMessageAdapter.notifyDataSetChanged();
                    }

                    // if (isLegalAid) {
                    //     // these 2 lines do not work
                    //     endActivity++;
                    //     isLegalAid = false;
                    //
                    //     // should I call a new Intent?
                    //     isFromMHC = true;
                    //     Intent iii = new Intent(getApplicationContext(), LegalAid.class);
                    //     startActivity(iii);
                    // }

                    endQues++;
                    break;
            }
        }
    }

    void newChatbotMessage(String message, ArrayList<String> options) {
        if (wrtGui == 1) {
            while (options.size() < 8) {
                options.add("null");
            }

            FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
            chatbotMsg.setOpt1(options.get(0));
            chatbotMsg.setOpt2(options.get(1));
            chatbotMsg.setOpt3(options.get(2));
            chatbotMsg.setOpt4(options.get(3));
            chatbotMsg.setOpt5(options.get(4));
            chatbotMsg.setOpt6(options.get(5));
            chatbotMsg.setOpt7(options.get(6));
            chatbotMsg.setOpt8(options.get(7));

            wrtGui = 1;

            mMessageAdapter.add(chatbotMsg);
            mMessageAdapter.notifyDataSetChanged();
        }
    }

    void dass_suggestions() {
        int dep_index = 0, anx_index = 0, str_index = 0;
        switch (depression_result.toLowerCase()) {
            case "normal":
            case "mild":
                dep_index = 0;
                break;
            case "moderate":
            case "severe":
                dep_index = 1;
                break;
            case "extremely severe":
                dep_index = 2;
                break;
        }

        switch (anxiety_result.toLowerCase()) {
            case "normal":
            case "mild":
                anx_index = 0;
                break;
            case "moderate":
            case "severe":
                anx_index = 1;
                break;
            case "extremely severe":
                anx_index = 2;
                break;
        }

        switch (stress_result.toLowerCase()) {
            case "normal":
            case "mild":
                str_index = 0;
                break;
            case "moderate":
            case "severe":
                str_index = 1;
                break;
            case "extremely severe":
                str_index = 2;
                break;
        }

        int max_index = Math.max(dep_index, Math.max(anx_index, str_index));
        if (max_index == 0) {
            String temp3 = "Your condition is completely normal. ";
            if (funYes(lifeMap.getPhysical_activity())) {
                if (lifeMap.getPhysical_activity_regular().equalsIgnoreCase("everyday")) {
                    temp3 += "But continue doing " + lifeMap.getPhysical_activity_type() + ". ";
                } else {
                    temp3 += "I would advise you to do " + lifeMap.getPhysical_activity_type() + " more frequently.";
                }
            }
            newChatbotMessage(temp3, noOptions);
        } else if (max_index == 1) {
            // if (depression_result.equalsIgnoreCase("severe")) {
            //     String temp3 = "1. Set goals. When you're depressed, you may feel like you can't accomplish anything. That makes you feel worse about yourself. To push back, set daily goals for yourself.\n" +
            //             "2. Do something new. When you’re depressed, you’re in a rut. Push yourself to do something different. Go to a museum. Pick up a used book and read it on a park bench. Take a language class.";
            //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
            //     mMessageAdapter.add(friendlyMessage2);
            //     mMessageAdapter.notifyDataSetChanged();
            // }
            // if (anxiety_result.equalsIgnoreCase("severe")) {
            //     String temp3 = "1. Stop or limit how much caffeine you consume, including coffee, tea, cola and chocolate\n" +
            //             "2. Join support groups. These groups are available in-person and online. They encourage people with anxiety disorders to share their experiences and coping strategies.";
            //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
            //     mMessageAdapter.add(friendlyMessage2);
            //     mMessageAdapter.notifyDataSetChanged();
            // }
            // if (stress_result.equalsIgnoreCase("severe")) {
            //     String temp3 = "1. Lightening up can help diffuse tension. Use humor to help you face what's making you angry and, possibly, any unrealistic expectations you have for how things should go.\n" +
            //             "2. When your temper flares, put relaxation skills to work. Practice deep-breathing exercises, imagine a relaxing scene, or repeat a calming word or phrase, such as \"Take it easy.\"";
            //     FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp3, "SAKHA", null);
            //     mMessageAdapter.add(friendlyMessage2);
            //     mMessageAdapter.notifyDataSetChanged();
            // }
            newChatbotMessage("I hear your pain and am sorry that you are having a tough time. You're not alone. I care and others do, too. Please know you've been heard. \n" + "How about focussing on relaxing you first", noOptions);
            newChatbotMessage("Try taking 5 deep breath. Just inhale till 5 counts, hold your breath for 4 counts and exhale till 5 counts.", noOptions);
            newChatbotMessage("Hope you are feeling bit relaxed now. You can practice this exercise daily for 5-10 minutes in the morning. This will help you relax.", noOptions);
            newChatbotMessage("If you feel like crying, then cry. I won't judge you.", noOptions);
            newChatbotMessage("You can't keep your true emotions hidden forever. Coke bottle theory. Write down the impeding doom and burn it. Literally. Burn it up in the fireplace. Or flush it down the toilet. Then turn on some music and sing as loud and as badly as you can. Or look up cute pictures. Funny youtube videos. Take a bath. Squeeze a pillow as hard as you can. Squeeze a ballon until it pops. True, these won't make it go away, but it will help you get through this. And this won't last forever.", noOptions);
            newChatbotMessage("These problems are treatable, Getting the right medicines and enough sleep may help you a lot. Also take time off if you can to find something enjoyable that you can look forward to. Feel better!", noOptions);
            newChatbotMessage("Things will be fine, just take care of yourself and focus on all the positive things in life. Take care.", noOptions);
        } else {
            String temp1 = "You condition is Extremely Severe. PLEASE VISIT A COUNSELLOR AS SOON AS POSSIBLE";
            FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp1, "SAKHA", null);
            mMessageAdapter.add(friendlyMessage2);
            mMessageAdapter.notifyDataSetChanged();
        }
    }

    void emotionSuggestions() {
        // Emotion Suggestions [START]
        String nom = emotionApiRes.replace("\"", "");
        nom = nom.replace("[", "");
        nom = nom.replace("]", "");
        nom = nom.replace("\n", "");
        String[] emolist = nom.split(",", 0);

        for (String i : emolist) {
            if (i.equalsIgnoreCase("Posemo") || i.equalsIgnoreCase("Netspeak") || i.equalsIgnoreCase("Risk") || i.equalsIgnoreCase("Informal") || i.equalsIgnoreCase("Sexual")) {
                continue;
            }

            if (i.equalsIgnoreCase("Death")) {
                newChatbotMessage("<b>Your choice of words is making me worried for you! Try this and see if you feel better:</b>", noOptions);
                newChatbotMessage("1. It is important to speak to someone you trust about how you feel. Sometimes just talking about how you feel can help. It is important to be open about all of your thoughts.", noOptions);
                newChatbotMessage("2. Identify your triggers and see if you can find a way to subside them", noOptions);
            }

            if (i.equalsIgnoreCase("Sad")) {
                newChatbotMessage("<b>You sound sad and i hope this isnt your mood for the day! maybe these will help</b>:", noOptions);
                newChatbotMessage("1. Spend time in nature. Rockmore recommends experiencing the outdoors with all five of your senses, which she calls behavioral activation. Pay attention to what you see, feel, hear, smell and possibly taste in nature, and it may help you out of your slump.", noOptions);
                newChatbotMessage("2. Move: Working out and taking walks can boost a low point. Many studies show that people who exercise regularly benefit with a positive boost in mood and reduced stress levels.", noOptions);
            }

            if (i.equalsIgnoreCase("Anger") || i.equalsIgnoreCase("Swear")) {
                // newChatbotMessage("Your anger levels seem to be high! That is not a good sign for your mental peace. Please try these:", noOptions);
                // newChatbotMessage("1. Lightening up can help diffuse tension. Use humor to help you face what's making you angry and, possibly, any unrealistic expectations you have for how things should go.", noOptions);
                // newChatbotMessage("2. When your temper flares, put relaxation skills to work. Practice deep-breathing exercises, imagine a relaxing scene, or repeat a calming word or phrase, such as Take it easy.", noOptions);
                newChatbotMessage("I hear that you are feeling angry at the moment.\n" +
                        "It’s normal to feel angry in such situations. When people try to take advantage we do feel angry.\n" +
                        "You can follow some simple techniques which will help in managing your anger.\n" +
                        "How about focussing on relaxing you first\n" +
                        "Try taking 5 deep breath. Just inhale till 5 counts, hold your breath for 4 counts and exhale till 5 counts \n" +
                        "Other things that you could do- you can count backwords like 100, 99, 98, 97…. OR you can drink water slowly. This will help you in manging your anger\n" +
                        "These problems are treatable, Getting the right medicines and enough sleep may help you a lot. \n" +
                        "Things will be fine, just take care of yourself and focus on all the positive things in life. Take care.", noOptions);
            }

            if (i.equalsIgnoreCase("Anx")) {
                newChatbotMessage("<b>The anxious feelings you have can be toned down with these:</b>", noOptions);
                newChatbotMessage("1. Check your eating habits. Stay hydrated, eliminate processed foods, and eat a balanced diet rich in complex carbohydrates, fruits and vegetables, and lean proteins.", noOptions);
                newChatbotMessage("2. Deep breathing exercises — the deliberate process of taking slow, even, deep breaths — can help restore normal breathing patterns and reduce anxiety", noOptions);
            }

            if (i.equalsIgnoreCase("Negemo")) {
                newChatbotMessage("<b>Your negative thoughts seem to be high! Please try these:</b>", noOptions);
                newChatbotMessage("1. Share your feelings with someone close to you. Everyone has negative thoughts from time to time. Talking about it with someone else helps you keep those thoughts in perspective.", noOptions);
                newChatbotMessage("2. Do something nice for yourself. Enjoy a little ME time. Or you could find something that makes you laugh.", noOptions);
            }
        }
        // Emotion Suggestions [END]
    }

    private void sendSummary() {
        // Intent spinner = new Intent(getApplicationContext(), SpinnerTest.class);
        // startActivity(spinner);

        // String toNumber = "+91 63092 87475"; // contains spaces.
        // toNumber = toNumber.replace("+", "").replace(" ", "");

        ArrayList<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact(16.49, 80.65, "Maheeth", "918470039109", 2));
        contacts.add(new Contact(25.54, 84.85, "Maheeth2", "91470039109", 5));
        contacts.add(new Contact(16.99, 79.96, "Nitesh", "91470039109", 17));
        contacts.add(new Contact(17.45, 78.39, "Srishti", "91470039109", 32));
        contacts.add(new Contact(22.61, 88.34, "Tama", "91470039109", 36));

        double lat = 13.08, lon = 80.26;

        int nearestIndex = findNearestContact(contacts, lat, lon);

        // String toNumber = "918985974910";
        // newDebugMessage("nearestIndex = "+nearestIndex);
        // try {
        //     toNumber = contacts.get(nearestIndex).getPhone();
        // } catch (Exception e) {
        //     toNumber = "918985974910";
        // }
        String toNumber = contacts.get(nearestIndex).getPhone();
        // newDebugMessage("WhatsApp number: "+toNumber);

        if (contacts.size() > 0) {
            // newDebugMessage("These are the contacts");
            String temp = "";
            for (int i = 0; i < contacts.size(); i++) {
                Contact c = contacts.get(i);
                // newDebugMessage(c.getName()+": "+c.getPhone());
            }
        }
        // else {
        //      newDebugMessage("There are no contacts in the list");
        // }

        Intent sendIntent = new Intent("android.intent.action.MAIN");
        sendIntent.putExtra("jid", toNumber + "@s.whatsapp.net");
        sendIntent.putExtra(Intent.EXTRA_TEXT, Summary);
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.setPackage("com.whatsapp");
        sendIntent.setType("text/plain");
        startActivity(sendIntent);
    }

    int findNearestContact(ArrayList<Contact> contacts, double lat, double lon) {
        // find nearest contact
        int nearestIndex = 0;
        double nearestDistance = Double.MAX_VALUE;
        for (int i = 0; i < contacts.size(); i++) {
            double curDistance = contacts.get(i).Distance(lat, lon);
            // newDebugMessage("Comparing with "+contacts.get(i).getName()+": "+curDistance);
            if (curDistance < nearestDistance) {
                nearestDistance = curDistance;
                nearestIndex = i;
            }
        }
        return nearestIndex;
    }

    public void funSentiment(String uinput) {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://vaibhavasdf.pythonanywhere.com/";

        StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
//                output.setText(response.toUpperCase());
                Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                //String str1=response.toString();
//                sphereInPriority=response;

//                FriendlyMessage friendlyMessage = new FriendlyMessage(sphereInPriority, "SAKHA", null);
//                mMessageAdapter.add(friendlyMessage);
//                mMessageAdapter.notifyDataSetChanged();
                intentAPI = response;
                Intent ii = new Intent(getApplicationContext(), LegalAid2.class);
                startActivity(ii);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                String temp = "apierror";
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text", uinput);
                return new JSONObject(params2).toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        sr.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(sr);


    }

    void depression_suggestion() {
        String temp = "empty";
        temp = "* Take a short walk outdoors, have your coffee outside if you can stay warm enough. Even 10 minutes a day can help.";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        temp = "* Increase the amount of natural light in your home and workplace by opening blinds and drapes and sitting near windows.";
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage2);
        mMessageAdapter.notifyDataSetChanged();
        temp = "* Some people find that painting walls in lighter colors or using daylight simulation bulbs helps to combat depression";
        FriendlyMessage friendlyMessage3 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage3);
        mMessageAdapter.notifyDataSetChanged();
    }

    void anxiety_suggestion() {
        String temp = "empty";
        temp = "* Breathe deeply.Follow these steps to take a break during your day to just breathe: Lie down on a flat surface. Place one hand on your stomach, just above your navel. Place the other hand on your chest. Breathe in slowly and try to make your stomach rise a little. Hold your breath for a second. Breathe out slowly and let your stomach go back down.";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        temp = "* Relax your muscles.Start by choosing a muscle and holding it tight for a few seconds. Then relax the muscle. Do this with all of your muscles, one part of your body at a time. Try starting with your feet muscles and working your way up your body.";
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage2);
        mMessageAdapter.notifyDataSetChanged();
        temp = "* Get plenty of sleep.";
        FriendlyMessage friendlyMessage3 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage3);
        mMessageAdapter.notifyDataSetChanged();
    }

    void stress_suggestion() {
        String temp = "empty";
        temp = "* Using essential oils or burning a scented candle may help reduce your feelings of stress";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        temp = "* Reduce your caffeine intake. If you notice that caffeine makes you jittery or anxious, consider cutting back.";
        FriendlyMessage friendlyMessage2 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage2);
        mMessageAdapter.notifyDataSetChanged();
        temp = "*  It’s hard to feel stressed when you’re laughing";
        FriendlyMessage friendlyMessage3 = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage3);
        mMessageAdapter.notifyDataSetChanged();
    }


    // finds and returns integer out of string
    public int retInt(String str) {

        String[] splited = str.split("\\s+");
        for (String s : splited) {
            int n = s.length();

            if (onlyDigits(s, n)) {
                return Integer.parseInt(s);
            }
        }

        return 0;
    }

    //returns true if string is digit
    public static boolean
    onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if (!((str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i) == '.')) {
                return false;
            }
        }
        return true;
    }


    //updating dass21 result to firebase
    void updateToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);


        mMessageDatabaseReference.child(currentUserId).child("dassScreeningResult").setValue(dassmap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    //updating rootcause result to firebase
    void updateToFirebase2() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);


        mMessageDatabaseReference.child(currentUserId).child("root_cause_result").setValue(rootmap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    //storing final summary to  firebase
    void updateToFirebase3() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();

//            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
//            //HashMap<String ,String> profileMap = new HashMap<>();
////                    profileMap.put("device_token",deviceToken);
////                    profileMap.put("uid",currentUserId);
////                    profileMap.put("name",Username);
////                    profileMap.put("phone_number",PhoneNo);
////                    profileMap.put("address",Address);
//            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);


        UserSummary summaryMap = new UserSummary();
        summaryMap.setSummary(Summary);
        Log.d("dass21:summary_update:", "number of summaries before = " + numSummaries);
        mMessageDatabaseReference.child(currentUserId).child("summary").child("Health_Councelling_Summary" + (numSummaries + 1)).setValue(Summary)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // function for calculating depression,anxiety,strees score
    public void evaluation() {


        if (depression_score >= 0 && depression_score < 10)
            depression_result = "Normal";
        else if (depression_score >= 10 && depression_score < 14) {
            depression_result = "Mild";
            df = 1;
        } else if (depression_score >= 14 && depression_score < 21) {
            depression_result = "Moderate";
            df = 1;
        } else if (depression_score >= 21 && depression_score < 28) {
            depression_result = "Severe";
            df = 2;
        } else {
            depression_result = "Extremely Severe";
            df = 2;
        }


        if (anxiety_score >= 0 && anxiety_score < 8)
            anxiety_result = "Normal";
        else if (anxiety_score >= 8 && anxiety_score < 10) {
            anxiety_result = "Mild";
            af = 1;
        } else if (anxiety_score >= 10 && anxiety_score < 15) {
            anxiety_result = "Moderate";
            af = 1;
        } else if (anxiety_score >= 15 && anxiety_score < 20) {
            anxiety_result = "Severe";
            af = 2;
        } else {
            anxiety_result = "Extremely Severe";
            af = 2;
        }


        if (stress_score >= 0 && stress_score < 15)
            stress_result = "Normal";
        else if (stress_score >= 15 && stress_score < 19) {
            sf = 1;
            anxiety_result = "Mild";
        } else if (stress_score >= 19 && stress_score < 26) {
            sf = 1;
            anxiety_result = "Moderate";
        } else if (stress_score >= 26 && stress_score < 34) {
            sf = 2;
            stress_result = "Severe";
        } else {
            sf = 2;
            stress_result = "Extremely Severe";
        }

        // String temp="Suggestions:";
        // FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        // mMessageAdapter.add(friendlyMessage);
        // mMessageAdapter.notifyDataSetChanged();


    }

    //updating rootcause information to the final summary.
    void funRootCauseSummaryUpdate() {
        if (ObjCyber.sphereDetected == 1) {
            Summary += "Problem in cyber sphere is detected.Details of problem in cyber sphere : ";
            Summary += ObjCyber.finalCause + " ";
        }
        if (ObjFamily.sphereDetected == 1) {
            Summary += "Problem in family sphere is detected.Details of problem in cyber sphere : ";
            Summary += ObjFamily.finalCause + " ";
        }
        if (ObjSociety.sphereDetected == 1) {
            Summary += "Problem in society sphere is detected.Details of problem in cyber sphere : ";
            Summary += ObjSociety.finalCause + " ";
        }
        if (ObjWork.sphereDetected == 1) {
            Summary += "Problem in work sphere is detected.Details of problem in cyber sphere : ";
            Summary += ObjWork.finalCause + " ";
        }
        if (ObjStudy.sphereDetected == 1) {
            Summary += "Problem in study sphere is detected.Details of problem in cyber sphere : ";
            Summary += ObjStudy.finalCause + " ";
        }


    }

    public int getfactor(String result)
    {
        if(result.equalsIgnoreCase("Normal"))
            return 0;
        else if(result.equalsIgnoreCase("Mild") || result.equalsIgnoreCase("Moderate"))
            return 1;
        else
            return 2;
    }

    public void secondVisitFinish() {

        int prevdf = getfactor(SecondVisitActivity.dassmap.getDepression_result());
        int prevaf = getfactor(SecondVisitActivity.dassmap.getAnxiety_result());
        int prevsf = getfactor(SecondVisitActivity.dassmap.getStress_result());

//        if (df == 0 && af == 0 && sf == 0) {
//            newChatbotMessage("Good job! You really seem to be improving your mental condition. Keep trying the following to see more improvement.", noOptions);
//        } else if (df == 1 || sf == 1 || af == 1) {
//            newChatbotMessage("You have done a good job by not letting your condition get worse. Please keep trying to do these and also visit a therapist of possible! ", noOptions);
//        } else {
//            newChatbotMessage("Your situation doesn’t seem right! Please try these and also visit a therapist to see better results.", noOptions);
//        }

        if ((prevdf+prevaf+prevsf > df + af + sf)) {
            newChatbotMessage("Good job! You really seem to be improving your mental condition. Keep trying the following to see more improvement.", noOptions);
        } else if (prevdf+prevaf+prevsf == df + af + sf) {
            newChatbotMessage("You have done a good job by not letting your condition get worse. Please keep trying to do these and also visit a therapist of possible! ", noOptions);
        } else {
            newChatbotMessage("Your situation doesn’t seem right! Please try these and also visit a therapist to see better results.", noOptions);
        }


        if (prevdf < df) depression_suggestion();
        if (prevaf < af) anxiety_suggestion();
        if (prevsf < sf) stress_suggestion();

        newChatbotMessage("Would you like to discuss any other cyber crime that could be happening with you?", YesNoOptions);
    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }

    public boolean funYes(String temp) {
        String[] list_yes = {
                "yes",
                "yup",
                "yes i think so",
                "i think so",
                "fairly certain",
                "affirmative",
                "amen",
                "fine",
                "good",
                "okay",
                "true",
                "yea",
                "all right",
                "alright",
                "by all means",
                "aye",
                "beyond a doubt",
                "by all means",
                "certainly",
                "definitely",
                "sure",
                "exactly",
                "gladly",
                "good enough",
                "granted",
                "indubitably",
                "just so",
                "most assuredly",
                "naturally",
                "of course",
                "positively",
                "precisely",
                "sure thing",
                "surely",
                "undoubtedly",
                "unquestionably",
                "very well",
                "willingly",
                "without fail",
                "yep",
                "yeah"
        };

        String[] list_no = {
                "no",
                "no i dont think so",
                "certainly not",
                "by no means",
                "of course not",
                "not really",
                "on no account",
                "not on any account",
                "not likely",
                "hardly",
                "no way",
                "not"
        };

        temp = temp.toLowerCase();
        String temp_new = "";
        for (int i = 0; i < temp.length(); i++) {
            Character ch = temp.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == ' ') {
                temp_new += ch;
            } else {
                temp_new += " ";
            }
        }

        temp_new = temp_new.toLowerCase();
        for (String str : list_yes) {
            if (temp_new.contains(str)) {
                return true;
            }
        }

        for (String str : list_no) {
            if (temp_new.contains(str)) {
                return false;
            }
        }
        return false;
    }


}

//package com.google.firebase.quickstart.auth.java;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.os.Bundle;
//
//import com.google.firebase.quickstart.auth.R;
//
//public class dass21 extends AppCompatActivity {
//
//    public int depression_score,anxiety_score,stress_score;
//    public String depression_result,anxiety_result,stress_result;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_dass21);
//        depression_score=0;
//        anxiety_score=0;
//        stress_score=0;
//        depression_result=anxiety_result=stress_result="null";
//
//    }
//
//

//
//    public String
//}