package com.google.firebase.quickstart.auth.java.requests;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class SingleRequestActivity extends AppCompatActivity {

    // firebase variables
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_request);

        // init firebase variables
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference();

        // fetch the passed data
        RequestModel request = (RequestModel) getIntent().getSerializableExtra("request");

        TextView tname = findViewById(R.id.name_holder);
        TextView tempid = findViewById(R.id.empid_holder);
        TextView tphoneno = findViewById(R.id.phoneno_holder);
        TextView ttime = findViewById(R.id.time_holder);

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy hh:mm aaa");
        tname.setText(request.getName());
        tempid.setText(request.getEmpId());
        tphoneno.setText(request.getPhoneNo());
        ttime.setText(dateFormat.format(new Date(request.getTimestamp())));

        Button accept_button = findViewById(R.id.button_accept);
        Button reject_button = findViewById(R.id.button_reject);

        accept_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO : increase count of reg users
                mMessageDatabaseReference.child("Database").child(database_no).child("Org").child("allowed_users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            Long allowedUsers = (Long) snapshot.getValue();

                            mMessageDatabaseReference.child("Database").child(database_no).child("Org").child("registered_users").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        Long regUsers = (Long) snapshot.getValue();

                                        if (regUsers >= allowedUsers) {
                                            //showalert that can't add user license limit reached
                                            showLimitReachedAlert(allowedUsers);
                                        } else {
                                            // update UserDBKey
                                            mMessageDatabaseReference.child("UserDBKey").child(request.getUid()).setValue(database_no).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {

                                                    if (task.isSuccessful()) {
                                                        Log.v("utk", "Updated UserDBKey");

                                                        //increase count of registered users
                                                        mMessageDatabaseReference.child("Database").child(database_no).child("Org").child("registered_users").setValue(regUsers + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {

                                                                if (task.isSuccessful()) {
                                                                    Log.v("utk", "Updated  registered users");


                                                                } else {
                                                                    Log.e("utk", "Error updating registered users: " + task.getException());
                                                                }
                                                            }
                                                        });


                                                        // delete request from database
                                                        mMessageDatabaseReference.child("Database").child(database_no).child("Requests").child(request.getUid()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void unused) {
                                                                Log.v("utk", "successfully deleted request");
                                                            }
                                                        });


                                                    } else {
                                                        Log.e("utk", "Error updateing UserDBKey: " + task.getException());
                                                    }
                                                }
                                            });
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });
        reject_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // delete request from database
                mMessageDatabaseReference.child("Database").child(database_no).child("Requests").child(request.getUid()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.v("utk", "successfully deleted request");
                        mMessageDatabaseReference.child("Database").child(database_no).child("Rejcted_Requests").child(request.getUid()).setValue(request.getEmpId()).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if (task.isSuccessful()) {
                                    Log.v("utk", "Updated  rejected_requests");


                                } else {
                                    Log.e("utk", "Error updateing rejected_requests: " + task.getException());
                                }
                            }
                        });

                    }
                });

            }
        });

    }

    private void showLimitReachedAlert(Long aUsers) {

        AlertDialog limitReachedDialog = new AlertDialog.Builder(this).create();

        limitReachedDialog.setTitle("License Limit Reached");
        limitReachedDialog.setMessage("Your current license limit of " + aUsers + " members has been reached. Please upgrade the license to add more members");
        limitReachedDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                limitReachedDialog.cancel();
            }
        });

        limitReachedDialog.show();
    }
}
