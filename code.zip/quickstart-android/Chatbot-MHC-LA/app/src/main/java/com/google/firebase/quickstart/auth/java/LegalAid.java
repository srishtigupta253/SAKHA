package com.google.firebase.quickstart.auth.java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.quickstart.auth.R;

import org.json.JSONObject;

import java.util.HashMap;


import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.MY_SOCKET_TIMEOUT_MS;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.dass21.isFromMHC;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;

public class LegalAid extends AppCompatActivity {

    private static final String TAG = "IntroActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 10000;

    public String married = isHusband(introMap.getMembers());
    public String working = introMap.getWorking();
    public String reply = "null";
    public int age;

    private ListView mMessageListView;
    // public static MessageAdapter mMessageAdapter2;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    // private EditText mMessageEditText;
    // private Button mSendButton;
    // public static String mUsername=ANONYMOUS;

    public static String intentAPI = "null";

    public int introVar = (isFromMHC) ? 1 : 0;

    // public static UserIntro introMap=new UserIntro();
    public int endActivity = 0;
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;
    int flagg = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legal_aid);


        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        //mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

//         Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter2 = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages - 1).setOpt1("null");
                mMessageAdapter.getItem(messages - 1).setOpt2("null");
                mMessageAdapter.getItem(messages - 1).setOpt3("null");
                mMessageAdapter.getItem(messages - 1).setOpt4("null");
                mMessageAdapter.getItem(messages - 1).setOpt5("null");
                mMessageAdapter.getItem(messages - 1).setOpt6("null");
                mMessageAdapter.getItem(messages - 1).setOpt7("null");
                mMessageAdapter.getItem(messages - 1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();

                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");
                introVar += 1;
                temp = slangCheck(temp);
                introFun(temp);


            }
        });

        // Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
        // startActivity(ii);

        if (introVar == 0) {
            introStart();
        } else {
            String age = introMap.getAge();
            introFun(lifeMap.getOpen_ended_answer());
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }


    public void introStart() {
        String temp;
        temp = "Hello again, " + mUsername + "! Welcome to our Legal Aid service. So, what brings you here today?";
        FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
        mMessageAdapter.add(friendlyMessage);
        mMessageAdapter.notifyDataSetChanged();
        // temp=mUsername+", how old are you ? ";
        // FriendlyMessage friendlyMessage1= new FriendlyMessage(temp,"SAKHA",null);
        // mMessageAdapter.add(friendlyMessage1);
        // mMessageAdapter.notifyDataSetChanged();
    }

    public void introFun(String uinput) {
        String temp = "empty";

        switch (introVar) {
            // case 1:
            //     age=Integer.parseInt(retInt(uinput));
            //     if(age>=18) {
            //         temp = "Are you married ?";
            //     } else {
            //         temp = "Do you do some kind of work for living?";
            //     }
            //     break;
            // case 2:
            //     if(age>=18)
            //     {
            //         if(funYes(uinput))
            //             married="yes";
            //         else
            //             married="no";
            //         temp="Do you do some kind of work for living?";
            //     }
            //     else
            //     {
            //         if(funYes(uinput))
            //             working="yes";
            //         else
            //             working="no";
            //         temp="What brings you here. How can I help you? ";
            //         flagg=1;
            //     }
            //     break;
            // case 3:
            //     if(age>=18)
            //     {
            //         if(funYes(uinput))
            //             working="yes";
            //         else
            //             working="no";
            //
            //         temp="What brings you here. How can I help you?";
            //         flagg=1;
            //     }
            //     else
            //     {
            //         reply=uinput;
            //         String s=working+","+married+","+reply;
            //         funSentiment(s);
            //         endActivity=1;
            //         //call api;
            //
            //     }
            //     break;
            // case 4:
            case 1:
                temp = "Thank you for taking a brave step and choosing the legal path. Remember that none of this is as insuperable as it seems and NONE of this is your fault.";
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();

                Log.d("IntroMap.age = ", introMap.getAge());
                age = Integer.parseInt(introMap.getAge());
                reply = (isFromMHC) ? lifeMap.getOpen_ended_answer() : uinput;
                lifeMap.setOpen_ended_answer(reply);
                String s = working + "," + married + "," + reply;
                // String s="no,no,"+reply;
                Log.d("UTK","legal aid s = "+s);
                funLegal(s);
                endActivity = 1;
                // call api;
                break;
            default:
                temp = "defaultLegalAid";
        }

        if (endActivity != 1) {
            FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
            if (flagg == 0) {
                friendlyMessage.setOpt1("Yes");
                friendlyMessage.setOpt2("No");
            }
            mMessageAdapter.add(friendlyMessage);
            mMessageAdapter.notifyDataSetChanged();
        }


    }

    public String isHusband(String members) {
        members = members.toLowerCase();
        String[] splited = members.split(",");
        for (String s : splited) {
            if (s.equals("husband") || s.equals("hubby"))
                return "yes";
        }
        return "no";

    }


    public String retInt(String str) {

        String[] splited = str.split("\\s+");
        for (String s : splited) {
            int n = s.length();

            if (onlyDigits(s, n)) {
                return s;
            }
        }

        return "null";
    }

    public static boolean onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {

            // Check if character is
            // digit from 0-9
            // then return true
            // else false
            if (!((str.charAt(i) >= '0' && str.charAt(i) <= '9') || str.charAt(i) == '.')) {
                return false;
            }
        }
        return true;
    }

//    void updateToFirebase()
//    {
//        String currentUserId=firebaseAuth.getCurrentUser().getUid();
//        // Toast.makeText(getApplicationContext(),currentUserId,Toast.LENGTH_SHORT).show();
//
////            //String deviceToken = FirebaseInstanceId.getInstance().getToken();
////            //HashMap<String ,String> profileMap = new HashMap<>();
//////                    profileMap.put("device_token",deviceToken);
//////                    profileMap.put("uid",currentUserId);
//////                    profileMap.put("name",Username);
//////                    profileMap.put("phone_number",PhoneNo);
//////                    profileMap.put("address",Address);
////            //UserInfo profileMap=new UserInfo(currentUserId,Username,Firstname,Lastname,PhoneNo,Address,Religion);
//        mMessageDatabaseReference.child(currentUserId).child("intro").setValue(introMap)
//                .addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//
//                        if(task.isSuccessful())
//                        {
//
//                            Toast.makeText(getApplicationContext(),"Profile Updated",Toast.LENGTH_SHORT).show();
//                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
//                            //startActivity(i);
//                        }
//                        else
//                        {
//                            String Error = task.getException().toString();
//                            Toast.makeText(getApplicationContext(),"Error "+Error,Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
//    }


    public boolean funYes(String uinput) {
        uinput = uinput.toLowerCase();
        String[] splited = uinput.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("yes"))
                return true;
        }
        return false;

    }

    public void funLegal(String uinput) {

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
//        String url = "https://imash.pythonanywhere.com/legal";
        String url = "https://sdandapat.pythonanywhere.com/legal";

        StringRequest sr = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // text.setText(String.format("%s : ", input.getText().toString().toUpperCase()));
                // output.setText(response.toUpperCase());
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                //  String str1=response.toString();
                // sphereInPriority=response;
                //
                // FriendlyMessage friendlyMessage = new FriendlyMessage(sphereInPriority, "SAKHA", null);
                // mMessageAdapter.add(friendlyMessage);
                // mMessageAdapter.notifyDataSetChanged();
                intentAPI = response;
                Log.d("intentAPI_LegalAid: ", intentAPI);
                Intent ii = new Intent(getApplicationContext(), LegalAid2.class);
                startActivity(ii);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                String temp = "legalapierror" + ": " + error.getMessage();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                HashMap<String, String> params2 = new HashMap<String, String>();
                params2.put("text", uinput);
                return new JSONObject(params2).toString().getBytes();
            }

            // @Override
            // public Map<String, String> getHeaders() throws AuthFailureError {
            //     HashMap<String,String> headers = new HashMap<>();
            //
            //     /*
            //     change content-type to "application/x-www-form-urlencoded" from
            //     "application/json"
            //     */
            //
            //     headers.put("Content-Type","application/x-www-form-urlencoded");
            //     return headers;
            // }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        sr.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(sr);


    }

    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }


}