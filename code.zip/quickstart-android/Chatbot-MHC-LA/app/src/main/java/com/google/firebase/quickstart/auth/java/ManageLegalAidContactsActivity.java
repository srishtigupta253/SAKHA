package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isCounsellor;
import static com.google.firebase.quickstart.auth.java.ManageCounsellorContactsActivity.isLegal;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.List;

public class ManageLegalAidContactsActivity extends AppCompatActivity {

    private static final String TAG = "ManageLegalAidContactsActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;


    private ListView mLegalListView;
    private ProgressBar mProgressBar;
    private TextView mTitleTextView;
    // private ImageButton mPhotoPickerButton;
    // public static EditText mMessageEditText;
    // public static Button mSendButton;
    private Button mAddLegalContactButton;
    public static String mUsername=ANONYMOUS;

    public static ArrayList<Contact> contacts = new ArrayList<>();

    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    FirebaseDatabase mFirebaseDatabase;
    public static DatabaseReference mLegalDatabaseReference;

    public static ContactAdapter mLegalContactAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counsellor_contacts);

        isCounsellor = false;
        isLegal = true;

        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mLegalDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("LegalContacts");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mTitleTextView = (TextView) findViewById(R.id.titleTextView);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mLegalListView = (ListView) findViewById(R.id.counsellorListView);
        mAddLegalContactButton = (Button) findViewById(R.id.addCounsellorContactButton);

        // mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        // mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        // mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        mTitleTextView.setText(R.string.legal_aid_title);
        mTitleTextView.setTextSize(43);
        
        // Initialize message ListView and its adapter
        List<Contact> contacts = new ArrayList<>();
        mLegalContactAdapter = new ContactAdapter(this, R.layout.item_contact, contacts);
        mLegalListView.setAdapter(mLegalContactAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

           // Send button sends a message and clears the EditText
        mAddLegalContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), AddContactActivity.class);
                startActivity(i);
                // mContactAdapter.notifyDataSetChanged();
            }
        });

//        Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
//        startActivity(ii);

        initializeContacts();
        // newDebugContact("after contacts fetch, "+contacts.size()+contacts);
        // for (Contact c : contacts) {
        //     mContactAdapter.add(c);
        //     mContactAdapter.notifyDataSetChanged();
        // }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    // greetings and first question
    public void initializeContacts() {
        // contacts.add(new Contact(22.61,88.34,"Mahesh","917980664155",36));

        // newDebugContact("before contacts fetch, "+contacts.size()+contacts);
        for (Contact c : contacts) {
            mLegalContactAdapter.add(c);
            mLegalContactAdapter.notifyDataSetChanged();
        }

        getContacts();
        // (new Handler()).postDelayed(this::getContacts,1000);

        // newDebugContact("after contacts fetch, "+contacts.size()+contacts);
        // for (Contact c : contacts) {
        //     mContactAdapter.add(c);
        //     mContactAdapter.notifyDataSetChanged();
        // }
    }

    void getContacts() { //, double lat, double lon) {
        // mMessageDatabaseReference.addValueEventListener(new ValueEventListener() {
        mLegalDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // int count = (int) dataSnapshot.getChildrenCount();
                // newDebugContact("count = "+count);
                // (new Handler()).postDelayed(this::pass, 20000);

                if (dataSnapshot.exists()) {
                    // newDebugContact("contacts exist");

                    for (DataSnapshot phoneSnapshot: dataSnapshot.getChildren()) {
                        Contact c = phoneSnapshot.getValue(Contact.class);
                        contacts.add(c);
                    }

                    // newDebugContact("during contacts fetch, "+contacts.size()+contacts);
                    for (Contact c : contacts) {
                        mLegalContactAdapter.add(c);
                        mLegalContactAdapter.notifyDataSetChanged();
                    }
                } else {
                    // newDebugContact("contacts don't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    void newDebugContact(String message) {
        Contact contact = new Contact(16.49,80.65,message,"91abcdefghi",2);
        mLegalContactAdapter.add(contact);
        mLegalContactAdapter.notifyDataSetChanged();
    }

    @Override
    public void finish() {
        contacts.clear();
        mLegalContactAdapter.clear();
        mLegalContactAdapter.notifyDataSetChanged();
        super.finish();
    }
}
