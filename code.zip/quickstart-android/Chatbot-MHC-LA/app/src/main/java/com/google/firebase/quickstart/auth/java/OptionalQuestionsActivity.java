package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.DEFAULT_MSG_LENGTH_LIMIT;
import static com.google.firebase.quickstart.auth.java.IntroActivity.askedStudent;
import static com.google.firebase.quickstart.auth.java.IntroActivity.askedWorking;
import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.IntroActivity.introMap;
import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mMessageEditText;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mSendButton;
import static com.google.firebase.quickstart.auth.java.IntroActivity.mUsername;
import static com.google.firebase.quickstart.auth.java.IntroActivity.husbandCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.childCnt;
import static com.google.firebase.quickstart.auth.java.IntroActivity.childrenCnt;
import static com.google.firebase.quickstart.auth.java.MentalHealthActivity.lifeMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.infoMap;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.isLifeStyleExists;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.mMessageAdapter;
import static com.google.firebase.quickstart.auth.java.SelectionActivity.slangList;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.Arrays;

public class OptionalQuestionsActivity extends AppCompatActivity {

    private static final String TAG = "OptionalQuestionsActivity";
    private ListView mMessageListView;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;

    public int introVar = 0; // var for pointing question to be asked
    public int endActivity = 0; //flag

    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessageDatabaseReference;

    //flags
    public int ww = 0;
    public int checkprof = 0;

    // options
    ArrayList<String> noOptions = new ArrayList<>();
    ArrayList<String> YesNoOptions = new ArrayList<>(Arrays.asList("Yes","No"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

//        Summary = "";
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mMessageDatabaseReference = mFirebaseDatabase.getReference();
        mMessageDatabaseReference = mMessageDatabaseReference.child("Database").child(database_no).child("Users");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mMessageListView = (ListView) findViewById(R.id.messageListView);
        mPhotoPickerButton = (ImageButton) findViewById(R.id.photoPickerButton);
        mMessageEditText = (EditText) findViewById(R.id.messageEditText);
        mSendButton = (Button) findViewById(R.id.sendButton);

        //Initialise Firebase


        // mMessagesDatabaseReference= mFirebaseDatabase.getReference().child("messages");

        // Initialize message ListView and its adapter
//        List<FriendlyMessage> friendlyMessages = new ArrayList<>();
//        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, friendlyMessages);
        mMessageListView.setAdapter(mMessageAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Fire an intent to show an image picker
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                // TODO: Send messages on click
//                String temp=mMessageEditText.getText().toString();
//                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
//
//
//                   FriendlyMessage friendlyMessage;
//                   if (up % 2 == 0)
//                       friendlyMessage = new FriendlyMessage(temp, mUsername, null);
//                   else
//                       friendlyMessage = new FriendlyMessage(temp, "SAKHA", null);
//
////                mMessagesDatabaseReference.push().setValue(friendlyMessage);
////                // Clear input box
//
////                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
////                startActivity(i);
//
//                   mMessageAdapter.add(friendlyMessage);
//                   mMessageAdapter.notifyDataSetChanged();
//                   mMessageEditText.setText("");
//
//                up+=1;

                int messages = mMessageAdapter.getCount();
                mMessageAdapter.getItem(messages-1).setOpt1("null");
                mMessageAdapter.getItem(messages-1).setOpt2("null");
                mMessageAdapter.getItem(messages-1).setOpt3("null");
                mMessageAdapter.getItem(messages-1).setOpt4("null");
                mMessageAdapter.getItem(messages-1).setOpt5("null");
                mMessageAdapter.getItem(messages-1).setOpt6("null");
                mMessageAdapter.getItem(messages-1).setOpt7("null");
                mMessageAdapter.getItem(messages-1).setOpt8("null");
                mMessageAdapter.notifyDataSetChanged();

                String temp = mMessageEditText.getText().toString();
//                temp=slangCheck(temp);
                //Toast.makeText(getApplicationContext(),temp,Toast.LENGTH_SHORT).show();
                FriendlyMessage friendlyMessage = new FriendlyMessage(temp, mUsername, null);
                mMessageAdapter.add(friendlyMessage);
                mMessageAdapter.notifyDataSetChanged();
                mMessageEditText.setText("");

                introVar += 1;
                temp = slangCheck(temp);
                introFun(temp);
            }
        });

       // Intent ii=new Intent(getApplicationContext(),RootCauseActivity.class);
       // startActivity(ii);
        introStart();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void introStart() {
        newChatbotMessage("What is your weight (in kg)?", noOptions);
    }

    // introductory questions
    public void introFun(String uinput) {
        Log.d("OptionalQuestions:","introFun:introVar="+introVar);
        switch (introVar) {
            case 1:
                introMap.setWeight(retInt(uinput));
                Summary += "Her weight is " + retInt(uinput) + " kg and height is ";
                newChatbotMessage("What is your height(in metres)?",noOptions);
                break;
            case 2:
                introMap.setHeight(retInt(uinput));
                Summary += retInt(uinput) + " meters. ";
                newChatbotMessage("Do you mind telling us whom you live with? Please write relationship seperated by comma(,))",noOptions);
                break;
            case 3:
                introMap.setMembers(uinput);
                Summary += "She lives with " + uinput + ". ";
                funUpdateFamily(uinput);

            //     int age = Integer.parseInt(introMap.getAge());
            //     String student = introMap.getStudent();
            //     String working = introMap.getWorking();
            //
            //     if (age <= 25 && student.equals("null")) {
            //         temp = "Are you still doing your studies?";
            //         introVar = 6;
            //         // go to case 7 next
            //     }
            //     if (age > 25 && working.equals("null")) {
            //         temp = "Are you a working professional?";
            //         introVar = 10;
            //         // go to case 11 next
            //     }
            //     // temp=QProf();
            //     friendlyMessage.setOpt1("Yes");
            //     friendlyMessage.setOpt2("No");
            //     break;
            // case 7:
                Log.d("OptionalQuestions:","introFun:introMap.getAge()="+introMap.getAge());
                if (funYes(introMap.getStudent())) {
                    // introMap.setStudent("yes");
                    Summary += "She is a student. ";
                    newChatbotMessage("What are you currently studying?",noOptions);
                } else {
                    // introMap.setStudent("no");
                    Summary += "She is not a student. ";
                    newChatbotMessage("Are you a working professional?",YesNoOptions);
                    introVar = 6;   // go to case 7 next
                }
                break;
            case 4:
                introMap.setStudying(uinput.toLowerCase());
                Summary += "She is currently studying " + introMap.getStudying() + ". ";
                newChatbotMessage("Do you work as part time employee somewhere?",YesNoOptions);
                break;
            case 5:
                if (funYes(uinput)) {
                    introMap.setWorking("yes");
                    Summary += "She is doing a part time job. ";
                } else {
                    introMap.setWorking("no");
                    Summary += "She does not do any part time job. ";
                }
                introVar = 10;   // go to case 10
                introFun("null");
                break;
            case 6:
                introMap.setStudent(uinput.toLowerCase());
                if (funYes(uinput)) {
                    Summary += "She is enrolled in a course. ";
                } else {
                    Summary += "She is not enrolled in any course. ";
                }
                newChatbotMessage("Do you work as part time employee somewhere?",YesNoOptions);
                introVar = 4;   // go to case 5
                break;
            case 7:
                if (funYes(uinput)) {
                    introMap.setWorking("yes");
                    Summary += "She is a working professional. ";
                    newChatbotMessage("How long have you worked there?",noOptions);
                } else {
                    introMap.setWorking("no");
                    Summary += "She is not a working professional. ";
                    newChatbotMessage("Are you enrolled in any course?",YesNoOptions);
                    introVar = 5;   // go to case 6
                }
                break;
            case 8:
                introMap.setProfession(uinput);
                Summary += "She has been working for " + introMap.getProfession() + ". ";
                newChatbotMessage("Are your personal and professional life well balanced?",YesNoOptions);
                break;
            case 9:
                if (funYes(uinput)) {
                    introMap.setWorkLifeBalance("yes");
                    Summary += "She says her personal and professional life are well balanced. ";
                } else {
                    introMap.setWorkLifeBalance("no");
                    Summary += "She says her personal and professional life are not well balanced. ";
                }
                introVar = 10;
                introFun("null");
                break;
            case 10:
                newChatbotMessage("Are you having a healthy diet?",YesNoOptions);
                break;
            case 11:
                lifeMap.setHealthy_diet(uinput);
                if (funYes(uinput)) {
                    Summary += "She is having a healthy diet. ";
                } else {
                    Summary += "She is not having a healthy diet. ";
                }
                newChatbotMessage("Are you having meals in a timely manner?",YesNoOptions);
                break;
            case 12:
                lifeMap.setTimely_diet(uinput);
                if (funYes(uinput)) {
                    Summary += "She is having meals in a timely manner. ";
                } else {
                    Summary += "She is not having meals in a timely manner. ";
                }
                newChatbotMessage("Did you visit a therapist?",YesNoOptions);
                break;
            default:
                if (funYes(uinput)) {
                    lifeMap.setTherapist_visit("yes");
                    Summary += "She has visited a therapist. ";
                } else {
                    lifeMap.setTherapist_visit("no");
                    Summary += "She has not visited a therapist. ";
                }

                startMentalHealth();
                // updateToFirebase();
                // endActivity=1;
                // Intent iii=new Intent(getApplicationContext(),LifeStyleActivity.class);
                // startActivity(iii);

                // default:
                //     if(ww==0) {
                //         temp=QProf2(uinput);
                //     }
                //     else {
                //         temp=QProf3();
                //     }
                //
                //     if(temp.equals("ok1")) {
                //         updateToFirebase();
                //         endActivity=1;
                //         Intent ii=new Intent(getApplicationContext(),LifeStyleActivity.class);
                //         startActivity(ii);
                //         //temp = "Error !!!";
                //     }
                //     else if (temp.equals("ok")) {
                //         temp=QProf3();
                //     }

        }

        // if (endActivity != 1) {
        //     friendlyMessage.setText(temp);
        //     mMessageAdapter.add(friendlyMessage);
        //     mMessageAdapter.notifyDataSetChanged();
        // }
    }

    public void startLifeStyle() {
        updateToFirebase();
        endActivity = 1;
        Intent iii = new Intent(getApplicationContext(), LifeStyleActivity.class);
        startActivity(iii);
    }

    public void startMentalHealth() {
        updateToFirebase();
        endActivity = 1;
        Intent iii = new Intent(getApplicationContext(), MentalHealthActivity.class);
        startActivity(iii);
    }

    static void newChatbotMessage(String message, ArrayList<String> options) {
        while (options.size() < 8) {
            options.add("null");
        }

        FriendlyMessage chatbotMsg = new FriendlyMessage(message, "SAKHA", null);
        chatbotMsg.setOpt1(options.get(0));
        chatbotMsg.setOpt2(options.get(1));
        chatbotMsg.setOpt3(options.get(2));
        chatbotMsg.setOpt4(options.get(3));
        chatbotMsg.setOpt5(options.get(4));
        chatbotMsg.setOpt6(options.get(5));
        chatbotMsg.setOpt7(options.get(6));
        chatbotMsg.setOpt8(options.get(7));

        mMessageAdapter.add(chatbotMsg);
        mMessageAdapter.notifyDataSetChanged();
    }

    // function to find digits from input string
    public String retInt(String str) {
        String[] splited = str.split("\\s+");
        for (String s : splited) {
            int n = s.length();
            if (onlyDigits(s, n)) {
                return s;
            }
        }
        return "null";
    }

    // return true if input string is digit
    public static boolean onlyDigits(String str, int n) {
        // Traverse the string from
        // start to end
        for (int i = 0; i < n; i++) {
            // Check if character is a digit from 0-9
            // then return true
            // else false
            boolean flag =  (str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') || str.charAt(i) == '.';
            if(!flag) return false;
        }
        return true;
    }

    void updateToFirebase() {
        updateIntroToFirebase();
        updateLifestyleToFirebase();
    }

    // updating intro of user in firebase
    void updateIntroToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        mMessageDatabaseReference.child(currentUserId).child("intro").setValue(introMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // updating lifestyle of user in firebase
    void updateLifestyleToFirebase() {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        mMessageDatabaseReference.child(currentUserId).child("lifestyle").setValue(lifeMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(), "Profile Updated", Toast.LENGTH_SHORT).show();
                            // Intent i =new Intent(getApplicationContext(),IntroActivity.class);
                            //startActivity(i);
                        } else {
                            String Error = task.getException().toString();
                            Toast.makeText(getApplicationContext(), "Error " + Error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


// // primary question for checking profession
//     public String QProf()
//     {
//         int age=Integer.parseInt(introMap.getAge());
//
//         if(age<=25)
//         {
//             checkprof=1;
//             return "Are you still doing your studies? ";
//         }
//         else
//         {
//             checkprof=2;
//             return "Are you a working professional ?";
//         }
//     }
//
//
// // secondary questions for checking profession
//     public String QProf2(String str)
//     {
//
//         String y="yes";
//         if(checkprof==1)
//         {
//              //Toast.makeText(getApplicationContext(),str,Toast.LENGTH_SHORT).show();
//            if(funYes(str))
//            {
//                Summary+="She is currently studying. ";
//                introMap.setProfession("studying");
//                return "ok1";
//
//            }
//            else
//            {
//                checkprof=2;
//                return "Are you a working professional?";
//            }
//         }
//         else if(checkprof==2)
//         {
//            if(funYes(str))
//            {
//                Summary+="She is a working professional. ";
//                introMap.setProfession("working");
//                return "ok";
//            }
//            else
//            {
//               checkprof=3;
//               return "Is there any kind of course you are enrolled in? ";
//            }
//         }
//         else
//         {
//             if(funYes(str))
//             {
//                 Summary+="She is enrolled in a course. ";
//
//                 introMap.setProfession("course");
//             }
//             else {
//
//                 introMap.setProfession("none");
//             }
//
//             return "ok";
//         }
//
//
//
//
//     }
//
// // questions if profession working is found
//     String QProf3()
//     {
//         String temp;
//         ww+=1;
//         switch (ww)
//         {
//             case 1:
//                 temp="How long have you worked there? ";
//                 break;
//             case 2:
//                 temp="How well balanced is your personal and professional life?";
//                 break;
//             default:
//                 temp="ok1";
//
//         }
//
//         return temp;
//
//     }


    // updating family variables
    void funUpdateFamily(String uinput) {
        uinput = uinput.toLowerCase();

        String[] splited = uinput.split("\\\\s*,\\\\s*");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("husband"))
                husbandCnt = 1;
            if (splited[i].equals("child"))
                childCnt = 1;
            if (splited[i].equals("children"))
                childrenCnt = 1;
        }
    }

    // returns true if yes found else false
    public boolean funYes(String uinput) {
        uinput = uinput.toLowerCase();
        String[] splited = uinput.split(" ");
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equals("yes"))
                return true;
        }
        return false;

    }

    // function for checking slang words
    public String slangCheck(String uinput) {
        String[] splited = uinput.split(" ");
        String ans = "";
        for (int i = 0; i < splited.length; i++) {
            if (slangList.get(splited[i]) != null)
                ans = ans + slangList.get(splited[i]);
            else
                ans = ans + splited[i];

            if (i < splited.length - 1)
                ans = ans + " ";
        }
        //ans="vaibhav hi";
        //ans=slangList.get("agn").toString();
        return ans;
    }

    @Override
    public void finish() {
        mMessageAdapter.clear();
        mMessageAdapter.notifyDataSetChanged();
        super.finish();
    }
}