package com.google.firebase.quickstart.auth.java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.quickstart.auth.R;

import static com.google.firebase.quickstart.auth.java.IntroActivity.Summary;

public class SummaryDisplay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_display);

        TextView tt=findViewById(R.id.textView2);
        tt.setText(Summary);
    }
}