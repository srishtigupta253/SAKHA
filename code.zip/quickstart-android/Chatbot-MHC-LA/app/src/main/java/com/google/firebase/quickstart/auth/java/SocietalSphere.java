package com.google.firebase.quickstart.auth.java;


import static com.google.firebase.quickstart.auth.java.RootCauseActivity.isSentiment;


public class SocietalSphere {

//    public int sphereDetected; // to check whether the sphere was detected or not by api
//    public String totalSentCheck; // total string that has to be sent to api for sentiment analysis
//    public String finalCause; // final cause answer for summary

    public int sphereDetected;
    public String totalSentCheck;
    public String finalCause;

    SocietalSphere() {
        this.sphereDetected=0;
        this.totalSentCheck="";
        this.finalCause="null";
    }

    //    i // selecting question no. to be asked
//  		uinput // user input
    public String funSociety(int i, String uinput) {
        String temp = "null"; // return next question to be asked for the sphere
        switch (i) {
            case 0:
                temp = "Neighbourhood and people around you make an impact on how we lead our life!I think your society is not very safe. Am I right?";
                break;
            case 1:

                if(!funYes(uinput))
                temp="doneNotFound";
                else
                temp = "Grocery shopping must be a comfortable task for you, right? ";

                break;
            case 2:
                if(uinput.equals("yes"))
                    totalSentCheck=totalSentCheck+"Grocery shopping is a comfortable task. ";
                else
                    totalSentCheck=totalSentCheck+"Grocery shopping is not a comfortable task. ";
                temp="There are a lot of people in today’s world that can creep a woman out, at any place and at any time. Do you face such looks from your neighbours?";
                break;
            case 3:
                if(uinput.equals("yes"))
                    totalSentCheck=totalSentCheck+"Neighbours are bad. ";
                else
                    totalSentCheck=totalSentCheck+"Neighbours are good. ";

                temp="checksentiment";
                break;
            case 4:
                finalCause=uinput;sphereDetected=1;
                temp="doneFound";
                break;
            default:
                temp = "default Society";
        }

        return temp;
    }
// return final question for the sphere
    public String finalQues()
    {
        return "Your society does not sound like a good one! Is there any such situation in particular that has creeped you out?";
    }
// return 1 if yes else zero
    public boolean funYes(String uinput)
    {
        uinput=uinput.toLowerCase();
        String[] splited= uinput.split(" ");
        for(int i=0;i<splited.length;i++)
        {
            if(splited[i].equals("yes"))
                return true;
        }
        return false;

    }



}