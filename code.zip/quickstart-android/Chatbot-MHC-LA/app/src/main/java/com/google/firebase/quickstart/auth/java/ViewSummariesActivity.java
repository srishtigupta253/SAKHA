package com.google.firebase.quickstart.auth.java;

import static com.google.firebase.quickstart.auth.java.IntroActivity.database_no;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.age_filter;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.anxiety_filter;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.cybercrime_filter;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.depression_filter;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.stress_filter;
import static com.google.firebase.quickstart.auth.java.SummaryFilterActivity.usersList;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.quickstart.auth.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class ViewSummariesActivity extends AppCompatActivity {

    private static final String TAG = "ViewSummariesActivity";

    public static final String ANONYMOUS = "anonymous";
    public static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;

    private ListView mSummaryListView;
    private ProgressBar mProgressBar;
    private SearchView mSearchBar;
    private TextView mNoResultTextView;
    private Button mStatisticsButton, mStatisticsButton2;

    public static String mUsername = ANONYMOUS;

    public static ArrayList<Summary> summaries = new ArrayList<>();

    public static ArrayList<String> tempUsersList = new ArrayList<>();


    // firebase authentication and database variables
    FirebaseAuth firebaseAuth;
    FirebaseDatabase mFirebaseDatabase;
    public static DatabaseReference mUserDatabaseReference;
    public static DatabaseReference mUsersListDatabaseReference;

    public static SummaryAdapter mSummaryAdapter;

    public static boolean isCounsellor = false, isLegal = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_summaries);
        // this.setTitle(R.string.view_summaries_title);

        // Initialise Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mUserDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Users");
        mUsersListDatabaseReference = mFirebaseDatabase.getReference().child("Database").child(database_no).child("Role");

//        mUsername = ANONYMOUS;
        //getting username
//        mAuth = FirebaseAuth.getInstance();
//        database = FirebaseDatabase.getInstance();
//        String currentUserId = mAuth.getUid();
//        myRef = database.getReference().child("Users").child(currentUserId).child("info");
//
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                UserInfo post = dataSnapshot.getValue(UserInfo.class);
//                mUsername=post.getName();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                System.out.println("The read failed: " + databaseError.getCode());
//            }
//        });
//        mUsername = ANONYMOUS;


        // Initialize references to views
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mSummaryListView = (ListView) findViewById(R.id.summaryListView);
        mSearchBar = (SearchView) findViewById(R.id.searchBar);
        mNoResultTextView = (TextView) findViewById(R.id.noResultTextView);
        mStatisticsButton = (Button) findViewById(R.id.statisticsButton);
        mStatisticsButton2 = (Button) findViewById(R.id.statisticsButton2);

        // Initialize message ListView and its adapter
        // List<Summary> summaries = new ArrayList<>();
        mSummaryAdapter = new SummaryAdapter(this, R.layout.item_summary, summaries);
        mSummaryListView.setAdapter(mSummaryAdapter);

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        mSearchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // mSummaryAdapter.clear();
                // mSummaryAdapter.notifyDataSetChanged();
                // getSummaries(query);

                // if(mSummaryAdapter.isEmpty()) {
                //     mNoResultTextView.setVisibility(View.VISIBLE);
                // } else {
                //     mNoResultTextView.setVisibility(View.INVISIBLE);
                // }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mNoResultTextView.setVisibility(View.INVISIBLE);
                mSummaryAdapter.clear();
                mSummaryAdapter.notifyDataSetChanged();
                return false;
            }


        });

        mStatisticsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getStatistics();
            }
        });

        mStatisticsButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ViewOverallStatisticsActivity.class);
                startActivity(i);
            }
        });

        mSummaryAdapter.clear();
        mSummaryAdapter.notifyDataSetChanged();
        // getUsersList();
        getSummaries();
        // initializeSummaries();
        // newDebugContact("after contacts fetch, "+contacts.size()+contacts);
        // for (Contact c : contacts) {
        //     mContactAdapter.add(c);
        //     mContactAdapter.notifyDataSetChanged();
        // }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    void getSummaries() {
        Log.d("stats","size of userlist in summary filter : " + usersList.size());
        Log.d("getSummaries-filters:", "depression_filter=" + TextUtils.join(", ", depression_filter) + ", anxiety_filter=" + TextUtils.join(", ", anxiety_filter) + ", stress_filter=" + TextUtils.join(", ", stress_filter) + ", cybercrime_filter=" + TextUtils.join(", ", cybercrime_filter));


        for (String uid : usersList) {
            Summary s = new Summary();

            mUserDatabaseReference.child(uid).child("dassScreeningResult").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        UserDass21 dass_result = snapshot.getValue(UserDass21.class);
                        assert dass_result != null;
                        Log.d("getSummaries:", "uid=" + uid + ", depression=" + dass_result.getDepression_result() + ", anxiety=" + dass_result.getAnxiety_result() + ", stress=" + dass_result.getStress_result());

                        mUserDatabaseReference.child(uid).child("info").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot infoSnapshot) {
                                UserInfo userInfo = infoSnapshot.getValue(UserInfo.class);
                                s.setInfo(userInfo);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Log.d("getSummaries:NoInfo:", "User " + uid + " doesn't have info");
                            }
                        });

                        mUserDatabaseReference.child(uid).child("intro").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot introSnapshot) {
                                UserIntro userIntro = introSnapshot.getValue(UserIntro.class);
                                assert userIntro != null;
                                int age = Integer.parseInt(userIntro.getAge());
                                Log.d("ViewSummariesActivity:","userIntro.getAge()="+age);
                                if (age < 10) {
                                    userIntro.setAge("below 10");
                                } else if (age >= 60) {
                                    userIntro.setAge("above 60");
                                } else {
                                    int age_low_bound = 10 * (age / 10);
                                    int age_high_bound = 10 * (age / 10) + 10;
                                    String age_blur = age_low_bound + "-" + age_high_bound;
                                    Log.d("ViewSummariesActivity:","age_blur="+age_blur);
                                    userIntro.setAge(age_blur);
                                }
                                s.setIntro(userIntro);
                                Log.d("ViewSummariesActivity:","age_blur="+s.getIntro().getAge());
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Log.d("getSummaries:NoIntro:", "User " + uid + " doesn't have intro");
                            }
                        });

                        if (depression_filter.contains(dass_result.getDepression_result().toLowerCase()) && anxiety_filter.contains(dass_result.getAnxiety_result().toLowerCase()) && stress_filter.contains(dass_result.getStress_result().toLowerCase())) {
                            mUserDatabaseReference.child(uid).child("cybercrimes_detected").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        String cybercrimes = dataSnapshot.getValue(String.class);
                                        assert cybercrimes != null;
                                        Log.d("getSummaries:crimes:", "<user " + uid + ", cybercrimes_detected>: " + cybercrimes);
                                        boolean isFiltered = true;
                                        for (String crime : cybercrime_filter) {
                                            if (!cybercrimes.toLowerCase().contains(crime.toLowerCase())) {
                                                isFiltered = false;
                                                break;
                                            }
                                        }
                                        if (isFiltered && age_filter.contains(s.getIntro().getAge())) {
                                            Log.d("getSummaries:agefilter:", "user " + uid + "=> cybercrimes_detected: " + cybercrimes);

                                            s.setDassScreeningResult(dass_result);
                                            s.setCybercrimes_detected(cybercrimes);

                                            s.setHealth_Councelling_Summary(s.toString());
                                            // s.setSummaryNo(final_summaryNo);

                                            summaries.add(s);
                                            Log.d("getSummaries:","uid : "+ uid.substring(1,1)+ "summaries.size(): "+summaries.size());
                                            // mSummaryAdapter.add(s);
                                            mSummaryAdapter.notifyDataSetChanged();
                                        } else {
                                            Log.d("getSummaries:", "user " + uid + " doesn't have the cybercrimes in filter");
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                    } else {
                        String user_anxiety = "null";
                        Log.d("getSummaries:NoDass:", "User " + uid + " doesn't have dassScreeningResult");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

        // if(mSummaryAdapter.isEmpty()) {
        //     mNoResultTextView.setVisibility(View.VISIBLE);
        // } else {
        //     mNoResultTextView.setVisibility(View.INVISIBLE);
        // }
        Log.d("getSummaries:","summaries.size(): "+summaries.size());
    }

    void getStatistics() {
        HashMap<String, Integer> stats = new HashMap<>();
        for (String filter : depression_filter) {
            stats.put(filter+"_depression",0);
        }

        for (String filter : anxiety_filter) {
            stats.put(filter+"_anxiety",0);
        }

        for (String filter : stress_filter) {
            stats.put(filter+"_stress",0);
        }

        for (String filter : cybercrime_filter) {
            stats.put(filter,0);
        }

        for (String filter : age_filter) {
            stats.put(filter,0);
        }

        Log.d("getStatistics: ","getCount="+mSummaryAdapter.getCount());
        for (int i = 0; i < summaries.size(); i++) {
            Summary summary = summaries.get(i);

            String t_depression = summary.getDassScreeningResult().getDepression_result().toLowerCase();
            Log.d("getStatistics:","depression_filter: "+depression_filter.toString()+", t_depression: "+t_depression);
            if (depression_filter.contains(t_depression)) {
                int count = stats.get(t_depression+"_depression");
                stats.put(t_depression+"_depression",count+1);
            }

            String t_anxiety = summary.getDassScreeningResult().getAnxiety_result().toLowerCase();
            Log.d("getStatistics:","anxiety_filter: "+anxiety_filter.toString()+", t_anxiety: "+t_anxiety);
            if (anxiety_filter.contains(t_anxiety)) {
                int count = stats.get(t_anxiety+"_anxiety");
                stats.put(t_anxiety+"_anxiety",count+1);
            }

            String t_stress = summary.getDassScreeningResult().getStress_result().toLowerCase();
            Log.d("getStatistics:","stress_filter: "+stress_filter.toString()+", t_stress: "+t_stress);
            if (stress_filter.contains(t_stress)) {
                int count = stats.get(t_stress+"_stress");
                stats.put(t_stress+"_stress",count+1);
            }

            String t_cybercrimes = summary.getCybercrimes_detected().toLowerCase();

            for (String crime : cybercrime_filter) {
                if (t_cybercrimes.contains(crime.toLowerCase())) {
                    int count = stats.get(crime);
                    stats.put(crime,count+1);
                }
            }

            String t_age = summary.getIntro().getAge().toLowerCase();
            if (age_filter.contains(t_age)) {
                int count = stats.get(t_age);
                stats.put(t_age,count+1);
            }
        }

        // LinearLayout statisticsLinearLayout =  findViewById(R.id.statisticsLinearLayout);
        TextView valueTV = new TextView(this);
        String disp = "";
        for (HashMap.Entry<String,Integer> entry : stats.entrySet()) {
            disp += (entry.getKey() + ": <b>" + entry.getValue() + "</b><br>");
        }
        valueTV.setText(disp);
        valueTV.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        valueTV.setTextSize(18);

        // (statisticsLinearLayout).addView(valueTV);

        AlertDialog alertDialog = null;
        alertDialog = new AlertDialog.Builder(ViewSummariesActivity.this)
                // set message, title, and icon
                .setTitle("Statistics")
                .setMessage(Html.fromHtml(disp))
                .setNegativeButton("BACK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();

        alertDialog.show();
    }


    void getUsersList() {
        mUserDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot uidSnapshot : dataSnapshot.getChildren()) {
                        String uid = uidSnapshot.getKey();
                        usersList.add(uid);
                    }
                } else {
                    Log.d("getUsersList:", "users list doesn't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    void newDebugContact(String message) {
        Summary summary = new Summary();
        mSummaryAdapter.add(summary);
        mSummaryAdapter.notifyDataSetChanged();
    }

    @Override
    public void finish() {
        summaries.clear();


        depression_filter.clear();
        anxiety_filter.clear();
        stress_filter.clear();
        cybercrime_filter.clear();

        mSummaryAdapter.clear();
        mSummaryAdapter.notifyDataSetChanged();
        super.finish();
    }
}
